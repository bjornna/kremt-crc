(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
"use strict";

exports.__esModule = true;

var KirurgiAvPrim_rTumorRuleset_1 = require("./rules/KirurgiAvPrim\u00E6rTumorRuleset");

var ForbehandlingKirurgi_1 = require("./rules/ForbehandlingKirurgi");

var KirurgiAvMetastaser_1 = require("./rules/KirurgiAvMetastaser");

var kirurgiAvLokalResidiv_1 = require("./rules/kirurgiAvLokalResidiv");

var Oppf_lgningOgTiltak_1 = require("./rules/Oppf\u00F8lgningOgTiltak");

var tumorLocalisation_1 = require("./rules/tumorLocalisation");

var PatologiLab_1 = require("./rules/PatologiLab");

var FORMID_LOKALISASJON_PRIMÆRTUMOR = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/lokalisasjon_av_primaertumor/lokalisajon";
var BEHANDLINGEN_VAR_RETTET_MOT = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/behandlingen_var_rettet_mot";
var FORMID_HASTEGRAD = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/hastegrad/hastegrad";
var FORMID_HØYDE = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/kliniske_parametre/høyde_(cm)";
var FORMID_VEKT = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/kliniske_parametre/vekt_(kg)";
var FORMID_HØYDE_UKJENT = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/kliniske_parametre/høyde_ukjent";
var FORMID_VEKT_UKJENT = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/kliniske_parametre/vekt_ukjent";
var FORMID_BMI = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/kliniske_parametre/bmi";
var FORMID_BMI_UKJENT = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/kliniske_parametre/bmi_ukjent";
var FORMID_RESEKSJON_AV_TUMOR = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/reseksjon_av_tumor";
var FORMID_INNGREP_COLON = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/inngrep_colon/inngrep_colon";
var FORMID_INGNREP_RECTUM = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/inngrep_rectum/inngrep_rectum";
var FORMID_ANASTOMOSE = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/anastomose";
var FORMID_RESEKSJON_NABOORGAN = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/reseksjon_av_naboorgan/reseksjon_av_naboorgan";
var FORMID_LOKALISASJON_NABOORGAN = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/reseksjon_av_naboorgan/lokalisasjon";
var FORMID_VEKTS_I_NABOORGAN = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/intraoperative_funn/innvekst_i_naboorgan";
var FORMID_KOMPLIKASJONER = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/komplikasjoner/komplikasjoner";
var FORMID_KOMPLIKASJONER_REOPERASJON = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/komplikasjoner/reoperasjon";
var FORMID_INNGREP_LOKAL_RESIDIV = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_lokalt_residiv/inngrep_lokalt_residiv";
var FORMID_INNGREP_MOT_METASTER_I_SAMME_INNGREP_FRA_PRIMÆR = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/intraoperative_funn/er_det_i_samme_operasjon_gjort_inngrep_mot_metastaser";
var FORMID_INNGREP_MOT_METASTER_I_SAMME_INNGREP_FRA_RESIDIV = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_lokalt_residiv/er_det_i_samme_operasjon_gjort_inngrep_mot_metastase(r)";
var FORMID_LOKALISASJON_METASTASER = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_metastase(r)/lokalisasjon_av_behandlet_metastase";
var FORMID_VALGT_FORBEHANDLING = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/forbehandling/forbehandling";
var FORMID_ASA_SCORE = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/asa-score";
var FORMID_SURGERY_TYPE = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/type_kirurgi";
var FORMID_SURGERY_DATE = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/operasjonsdato";
var FORMID_KIRURGI_AV_METASTASER_INNGREP = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_metastase(r)/inngrep_metastase/inngrep_metastaser";
var FORMID_OPPFØLGNING_TILTAK = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/oppfølging_tiltak/oppfølging_tiltak";
var FORMID_OPPFØLGNING_TILTAK_PLANLAGT = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/oppfølging_tiltak/planlagt_etterbehandling";
var FORMID_OPPFØLGNING_TILTAK_PLANLAGT_INGEN_BEHANDLING_ÅRSAK = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/oppfølging_tiltak/årsak_ingen_behandling";
var FORMID_OPPFØLGNING_TILTAK_PLANLAGT_INGEN_BEHANDLING_ÅRSAK_SPESIFISERT = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/oppfølging_tiltak/spesifiser_årsak_til_ingen_behandling";
var FORMID_AVSTAND_1 = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/lokalisasjon_av_primaertumor/angir_avstand_fra_analåpning_til_nedre_kant_av_tumor_(målt_på_stivt_skop)";
var FORMID_AVSTAND_2 = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/lokalisasjon_av_primaertumor/avstand_fra_øvre_kant_av_m.puborektalis_til_nedre_kant_av_tumor_(målt_ved_mr)";
var FORMID_LABORATORIUM = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/patologilaboratorium/laboratorium";
var FORMID_IKKE_RELEVANT = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/patologilaboratorium/ikke_relevant";
var FORMID_SPSIFISER = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/patologilaboratorium/spesifiser";

function main(api) {
  console.log("Hei automatisasjon ingenør");
  KirurgiAvPrim_rTumorRuleset_1.BehandliungRettetMotPrimærTumor(api); //BehandlingRettetMotMetastaser(api);

  kirurgiAvLokalResidiv_1.BehandliungRettetMotLokalResidiv(api);
  ForbehandlingKirurgi_1.BehandlingRettetMotSiktemål(api);
  ForbehandlingKirurgi_1.BehandlingRettetMotForbehandling(api);
  KirurgiAvPrim_rTumorRuleset_1.ReseksjonNaboorgan(api);
  Oppf_lgningOgTiltak_1.planlagtEtterbehandling(api);
  KirurgiAvPrim_rTumorRuleset_1.validateUrgency(api);
  KirurgiAvPrim_rTumorRuleset_1.validateClinicalParameters(api);
  KirurgiAvPrim_rTumorRuleset_1.validateResectionTumor(api);
  KirurgiAvPrim_rTumorRuleset_1.validateColonSurgery(api);
  KirurgiAvPrim_rTumorRuleset_1.validateRectumSurgery(api);
  KirurgiAvPrim_rTumorRuleset_1.validateAnostemose(api);
  KirurgiAvPrim_rTumorRuleset_1.validateGrowthIntoNabouringOrgan(api);
  KirurgiAvPrim_rTumorRuleset_1.AnnetLokNaboorgan(api);
  tumorLocalisation_1.enableAvstand(api);
  KirurgiAvPrim_rTumorRuleset_1.validateComplications(api);
  KirurgiAvPrim_rTumorRuleset_1.validateReoperation(api);
  KirurgiAvMetastaser_1.KirurgiMotMetastaserBehandlingRettetMot(api);
  KirurgiAvMetastaser_1.ValidateSurgeryOtherMetastasis(api);
  kirurgiAvLokalResidiv_1.ValidateSurgeryLocalResidiv(api);
  tumorLocalisation_1.tumorLocalisation(api);
  PatologiLab_1.validateNonRelevant(api);
  PatologiLab_1.validateSpesified(api);
  PatologiLab_1.validatePrepNumber(api);
  api.addListener(BEHANDLINGEN_VAR_RETTET_MOT, "OnChanged", function () {
    KirurgiAvPrim_rTumorRuleset_1.BehandliungRettetMotPrimærTumor(api); // BehandlingRettetMotMetastaser(api);

    kirurgiAvLokalResidiv_1.BehandliungRettetMotLokalResidiv(api);
    ForbehandlingKirurgi_1.BehandlingRettetMotSiktemål(api);
    ForbehandlingKirurgi_1.BehandlingRettetMotForbehandling(api);
    KirurgiAvMetastaser_1.KirurgiMotMetastaserBehandlingRettetMot(api);
    tumorLocalisation_1.tumorLocalisation(api);
  });
  api.addListener(FORMID_VALGT_FORBEHANDLING, "OnChanged", function (id, value, parent) {
    ForbehandlingKirurgi_1.validateForbehandlingKirurgi(api, true);
  });
  api.addListener(FORMID_VALGT_FORBEHANDLING, "OnChildAdded", function (id, value, parent) {
    ForbehandlingKirurgi_1.validateForbehandlingKirurgi(api, true);
  });
  api.addListener(FORMID_LOKALISASJON_PRIMÆRTUMOR, "OnChanged", function (id, value, parent) {
    tumorLocalisation_1.tumorLocalisation(api);
  });
  api.addListener(FORMID_VALGT_FORBEHANDLING, "OnChildRemoved", function (id, value, parent) {
    ForbehandlingKirurgi_1.validateForbehandlingKirurgi(api, true);
  });
  api.addListener(FORMID_HASTEGRAD, "OnChanged", function () {
    KirurgiAvPrim_rTumorRuleset_1.validateUrgency(api);
    KirurgiAvPrim_rTumorRuleset_1.checkAndSetOccurrencyUrgency(true, api);
  });
  api.addListener(FORMID_ASA_SCORE, "OnChanged", function () {
    KirurgiAvPrim_rTumorRuleset_1.validateUrgency(api);
    KirurgiAvPrim_rTumorRuleset_1.checkAndSetOccurrencyASA(true, api);
  });
  api.addListener(FORMID_HØYDE, "OnChanged", function () {
    KirurgiAvPrim_rTumorRuleset_1.validateClinicalParameters(api);
  });
  api.addListener(FORMID_VEKT, "OnChanged", function () {
    KirurgiAvPrim_rTumorRuleset_1.validateClinicalParameters(api);
    KirurgiAvPrim_rTumorRuleset_1.checkAndSetOccurrencyWeight(true, api);
  });
  api.addListener(FORMID_HØYDE_UKJENT, "OnChanged", function () {
    KirurgiAvPrim_rTumorRuleset_1.validateClinicalParameters(api);
  });
  api.addListener(FORMID_VEKT_UKJENT, "OnChanged", function () {
    KirurgiAvPrim_rTumorRuleset_1.validateClinicalParameters(api);
    KirurgiAvPrim_rTumorRuleset_1.checkAndSetOccurrencyWeight(true, api);
  });
  api.addListener(FORMID_BMI, "OnChanged", function () {
    KirurgiAvPrim_rTumorRuleset_1.validateClinicalParameters(api);
  });
  api.addListener(FORMID_BMI_UKJENT, "OnChanged", function () {
    KirurgiAvPrim_rTumorRuleset_1.validateClinicalParameters(api);
  });
  api.addListener(FORMID_SURGERY_TYPE, "OnChanged", function () {
    KirurgiAvPrim_rTumorRuleset_1.checkAndSetOccurrencyTypeOfSurgery(true, api);
  }); //

  api.addListener(FORMID_SURGERY_DATE, "OnChanged", function () {
    KirurgiAvPrim_rTumorRuleset_1.checkAndSetOccurrencyDateOfSurgery(true, api);
  }); // 

  api.addListener(FORMID_RESEKSJON_AV_TUMOR, "OnChanged", function () {
    KirurgiAvPrim_rTumorRuleset_1.validateResectionTumor(api);
    KirurgiAvPrim_rTumorRuleset_1.validateColonSurgery(api);
    KirurgiAvPrim_rTumorRuleset_1.validateRectumSurgery(api);
    KirurgiAvPrim_rTumorRuleset_1.checkAndSetOccurrencyTumorResection(true, api);
  });
  api.addListener(FORMID_INGNREP_RECTUM, "OnChanged", function () {
    KirurgiAvPrim_rTumorRuleset_1.validateRectumSurgery(api);
    KirurgiAvPrim_rTumorRuleset_1.checkAndSetOccurrencySurgeryColonOrRectum(true, api);
  });
  api.addListener(FORMID_INNGREP_COLON, "OnChanged", function () {
    KirurgiAvPrim_rTumorRuleset_1.validateColonSurgery(api);
    KirurgiAvPrim_rTumorRuleset_1.checkAndSetOccurrencySurgeryColonOrRectum(true, api);
  });
  api.addListener(FORMID_ANASTOMOSE, "OnChanged", function () {
    KirurgiAvPrim_rTumorRuleset_1.validateAnostemose(api);
  });
  api.addListener(FORMID_RESEKSJON_NABOORGAN, "OnChanged", function () {
    KirurgiAvPrim_rTumorRuleset_1.ReseksjonNaboorgan(api);
  });
  api.addListener(FORMID_LOKALISASJON_NABOORGAN, "OnChanged", function () {
    KirurgiAvPrim_rTumorRuleset_1.AnnetLokNaboorgan(api);
  });
  api.addListener(FORMID_LOKALISASJON_NABOORGAN, "OnChildRemoved", function () {
    KirurgiAvPrim_rTumorRuleset_1.AnnetLokNaboorgan(api);
  });
  api.addListener(FORMID_VEKTS_I_NABOORGAN, "OnChanged", function () {
    KirurgiAvPrim_rTumorRuleset_1.validateGrowthIntoNabouringOrgan(api);
  });
  api.addListener(FORMID_KOMPLIKASJONER, "OnChanged", function () {
    console.log("OnChanged");
    KirurgiAvPrim_rTumorRuleset_1.validateComplications(api);
  });
  api.addListener(FORMID_KOMPLIKASJONER, "OnChildAdded", function () {
    console.log("OnChildAdded");
    KirurgiAvPrim_rTumorRuleset_1.validateComplications(api);
  });
  api.addListener(FORMID_KOMPLIKASJONER, "OnChildRemoved", function () {
    console.log("OnChildRemoved");
    KirurgiAvPrim_rTumorRuleset_1.validateComplications(api);
  });
  api.addListener(FORMID_KOMPLIKASJONER_REOPERASJON, "OnChanged", function () {
    KirurgiAvPrim_rTumorRuleset_1.validateReoperation(api);
  });
  api.addListener(FORMID_INNGREP_LOKAL_RESIDIV, "OnChanged", function () {
    kirurgiAvLokalResidiv_1.ValidateSurgeryLocalResidiv(api);
  });
  api.addListener(FORMID_KIRURGI_AV_METASTASER_INNGREP, "OnChanged", function () {
    KirurgiAvMetastaser_1.ValidateSurgeryOtherMetastasis(api);
  });
  api.addListener(FORMID_KIRURGI_AV_METASTASER_INNGREP, "OnChildAdded", function () {
    KirurgiAvMetastaser_1.ValidateSurgeryOtherMetastasis(api);
  });
  api.addListener(FORMID_KIRURGI_AV_METASTASER_INNGREP, "OnChildRemoved", function () {
    KirurgiAvMetastaser_1.ValidateSurgeryOtherMetastasis(api);
  });
  api.addListener(FORMID_INNGREP_MOT_METASTER_I_SAMME_INNGREP_FRA_PRIMÆR, "OnChanged", function () {
    KirurgiAvMetastaser_1.KirurgiMotMetastaserBehandlingRettetMot(api);
  });
  api.addListener(FORMID_INNGREP_MOT_METASTER_I_SAMME_INNGREP_FRA_RESIDIV, "OnChanged", function () {
    KirurgiAvMetastaser_1.KirurgiMotMetastaserBehandlingRettetMot(api);
  });
  api.addListener(FORMID_LOKALISASJON_METASTASER, "OnChanged", function () {
    KirurgiAvMetastaser_1.ValidateSurgeryOtherMetastasis(api);
    KirurgiAvMetastaser_1.KirurgiMotMetastaserBehandlingRettetMot(api);
  });
  api.addListener(FORMID_LOKALISASJON_METASTASER, "OnChildAdded", function () {
    KirurgiAvMetastaser_1.ValidateSurgeryOtherMetastasis(api);
    KirurgiAvMetastaser_1.KirurgiMotMetastaserBehandlingRettetMot(api);
  });
  api.addListener(FORMID_LOKALISASJON_METASTASER, "OnChildRemoved", function () {
    KirurgiAvMetastaser_1.ValidateSurgeryOtherMetastasis(api);
    KirurgiAvMetastaser_1.KirurgiMotMetastaserBehandlingRettetMot(api);
  });
  api.addListener(FORMID_OPPFØLGNING_TILTAK, "OnChanged", function () {
    Oppf_lgningOgTiltak_1.planlagtEtterbehandling(api);
  });
  api.addListener(FORMID_OPPFØLGNING_TILTAK_PLANLAGT, "OnChanged", function () {
    Oppf_lgningOgTiltak_1.planlagtEtterbehandling(api);
  });
  api.addListener(FORMID_OPPFØLGNING_TILTAK_PLANLAGT_INGEN_BEHANDLING_ÅRSAK, "OnChanged", function () {
    Oppf_lgningOgTiltak_1.planlagtEtterbehandling(api);
  });
  api.addListener(FORMID_OPPFØLGNING_TILTAK_PLANLAGT_INGEN_BEHANDLING_ÅRSAK, "OnChildAdded", function () {
    Oppf_lgningOgTiltak_1.planlagtEtterbehandling(api);
  });
  api.addListener(FORMID_OPPFØLGNING_TILTAK_PLANLAGT_INGEN_BEHANDLING_ÅRSAK, "OnChildRemoved", function () {
    Oppf_lgningOgTiltak_1.planlagtEtterbehandling(api);
  });
  api.addListener(FORMID_OPPFØLGNING_TILTAK_PLANLAGT_INGEN_BEHANDLING_ÅRSAK_SPESIFISERT, "OnChanged", function () {
    Oppf_lgningOgTiltak_1.planlagtEtterbehandling(api);
  });
  api.addListener(FORMID_AVSTAND_1, "OnChanged", function () {
    tumorLocalisation_1.enableAvstand(api);
  });
  api.addListener(FORMID_AVSTAND_2, "OnChanged", function () {
    tumorLocalisation_1.enableAvstand(api);
  });
  api.addListener(FORMID_LABORATORIUM, "OnChanged", function () {
    PatologiLab_1.validateSpesified(api);
    PatologiLab_1.validatePrepNumber(api);
  });
  api.addListener(FORMID_IKKE_RELEVANT, "OnChanged", function () {
    PatologiLab_1.validateNonRelevant(api);
  });
  console.log(api.getFieldValue("kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/reseksjon_av_tumor") + "HELLO");
}main(api);
},{"./rules/ForbehandlingKirurgi":2,"./rules/KirurgiAvMetastaser":4,"./rules/KirurgiAvPrimærTumorRuleset":5,"./rules/OppfølgningOgTiltak":6,"./rules/PatologiLab":7,"./rules/kirurgiAvLokalResidiv":8,"./rules/tumorLocalisation":9}],2:[function(require,module,exports){
"use strict";

exports.__esModule = true;

var GlobalFunctions_1 = require("./GlobalFunctions");

var BEHANDLINGEN_VAR_RETTET_MOT = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/behandlingen_var_rettet_mot";
var FORMID_SIKTEMÅL_FOR_BEHANDLINGEN_PREOPERATIV_INTENSJON = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/siktemål_for_behandlingen_preoperativ_intensjon";
var FORMID_FORBEHANDLING_CLUSTER = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/forbehandling";
var FORMID_FORBEHANDLING_SPESIFISER_FORBEHANDLING_ANNET = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/forbehandling/spesifiser_forbehandling_annet";
var FORMID_VALGT_FORBEHANDLING = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/forbehandling/forbehandling";

function validateForbehandlingKirurgi(api, thisValueShoudlBeTrue) {
  /** */
  console.log("Kjører funskjon for validateForbehandlingKirurgi");
  var nameOfFunctionForerrorTrace = "validateForbehandlingKirurgi";
  var selectedPreTreatment = api.getFields(FORMID_VALGT_FORBEHANDLING);
  var BehandlingRettetMot1 = api.getFieldValue(BEHANDLINGEN_VAR_RETTET_MOT);
  console.log(selectedPreTreatment);

  switch (true) {
    case selectedPreTreatment == "" && thisValueShoudlBeTrue:
      console.log("Bruker har ikke valgt noen forbehandling");
      api.setOccurrences(FORMID_VALGT_FORBEHANDLING, "1..8"); // api.resetErrorMessage(FORMID_VALGT_FORBEHANDLING)

      break;

    case selectedPreTreatment && GlobalFunctions_1.searchForValue(selectedPreTreatment, "Ingen", nameOfFunctionForerrorTrace) == true && GlobalFunctions_1.countCertainElementsInArray(selectedPreTreatment) > 1 && thisValueShoudlBeTrue:
      console.log("ERROR:Bruker har valgt forbehandling ingen og kombinert med mere enn et annet valg!");
      api.setOccurrences(FORMID_VALGT_FORBEHANDLING, "1..1"); //api.setErrorMessage(FORMID_VALGT_FORBEHANDLING,"Det er ikke tilatt og velge andre verdier når du har valgt Ingen")

      break;

    case selectedPreTreatment && GlobalFunctions_1.searchForValue(selectedPreTreatment, "Ukjent", nameOfFunctionForerrorTrace) == true && GlobalFunctions_1.countCertainElementsInArray(selectedPreTreatment) > 1 && thisValueShoudlBeTrue:
      console.log("ERROR:Bruker har valgt forbehandling Ukjent og kombinert med mere enn et annet valg!");
      api.setOccurrences(FORMID_VALGT_FORBEHANDLING, "1..1"); // api.setErrorMessage(FORMID_VALGT_FORBEHANDLING,"Det er ikke tilatt og velge andre verdier når du har valgt Ukjent")

      break;

    case selectedPreTreatment && GlobalFunctions_1.searchForValue(selectedPreTreatment, "Ingen", nameOfFunctionForerrorTrace) == true && thisValueShoudlBeTrue:
      console.log("Bruker har kun valgt forbehandling Ingen");
      api.setOccurrences(FORMID_VALGT_FORBEHANDLING, "1..1"); // api.resetErrorMessage(FORMID_VALGT_FORBEHANDLING)

      break;

    case selectedPreTreatment && GlobalFunctions_1.searchForValue(selectedPreTreatment, "Ukjent", nameOfFunctionForerrorTrace) == true && thisValueShoudlBeTrue:
      console.log("Bruker har kun valgt forbehandling Ukjent");
      api.setOccurrences(FORMID_VALGT_FORBEHANDLING, "1..1"); // api.resetErrorMessage(FORMID_VALGT_FORBEHANDLING)

      break;

    case BehandlingRettetMot1 && GlobalFunctions_1.searchForValue(selectedPreTreatment, "Kun metastase(r)", nameOfFunctionForerrorTrace) == true && GlobalFunctions_1.searchForValue(selectedPreTreatment, "Avlastende stomi", nameOfFunctionForerrorTrace) == true && thisValueShoudlBeTrue:
      console.log("ERROR: Bruker har valgt at behandlingen  er rettet mot Kun metastase(r) og kombinert med forbehandling Avlastende stomi!");
      api.setOccurrences(FORMID_VALGT_FORBEHANDLING, "1..8"); // api.setErrorMessage(FORMID_VALGT_FORBEHANDLING,"Det er ikke tilatt og velge avlastende stomi kombinert med behandling kun rettet mot metastaser")

      break;

    case BehandlingRettetMot1 && GlobalFunctions_1.searchForValue(selectedPreTreatment, "Kun metastase(r)", nameOfFunctionForerrorTrace) == true && GlobalFunctions_1.searchForValue(selectedPreTreatment, "Stenting", nameOfFunctionForerrorTrace) == true && thisValueShoudlBeTrue:
      console.log("ERROR: Bruker har valgt at behandlingen  er rettet mot Kun metastase(r) og kombinert med forbehandling Stenting!");
      api.setOccurrences(FORMID_VALGT_FORBEHANDLING, "1..8"); // api.setErrorMessage(FORMID_VALGT_FORBEHANDLING,"Det er ikke tilatt og velge stenting kombinert med behandling kun rettet mot metastaser")

      break;

    default:
      console.log("validateForbehandlingKirurgi trigger ingen regler og går til default");
      api.setOccurrences(FORMID_VALGT_FORBEHANDLING, "0..8"); // api.resetErrorMessage(FORMID_VALGT_FORBEHANDLING)

      break;
  }

  if (GlobalFunctions_1.searchForValue(selectedPreTreatment, "Annet", nameOfFunctionForerrorTrace)) {
    api.showField(FORMID_FORBEHANDLING_SPESIFISER_FORBEHANDLING_ANNET);
    console.log("Bruker har valgt Annet som forbehandling viser spesifiseringsfelt for Annet forbehandling");
  } else {
    GlobalFunctions_1.HideAndClear([FORMID_FORBEHANDLING_SPESIFISER_FORBEHANDLING_ANNET], api);
  }
}

exports.validateForbehandlingKirurgi = validateForbehandlingKirurgi;

function BehandlingRettetMotSiktemål(api) {
  console.log("Kjører funskjon for BehandlingRettetMotSiktemål");
  var BehandlingRettetMot1 = api.getFieldValue(BEHANDLINGEN_VAR_RETTET_MOT);

  if (GlobalFunctions_1.ArenaVersionValueCheck(BehandlingRettetMot1) && (BehandlingRettetMot1.value == "Primærtumor (med eller uten metastase(r))" || BehandlingRettetMot1.value == "Kun metastase(r)")) {
    console.log("Siktemål for behandlingen/preoperativ intensjon vises");
    api.showField(FORMID_TREATMENT_AIM);
    api.showField(FORMID_SIKTEMÅL_FOR_BEHANDLINGEN_PREOPERATIV_INTENSJON);
    checkAndSetOccurrencyAimForTreatment(true, api);
  } else {
    GlobalFunctions_1.HideAndClear([FORMID_TREATMENT_AIM, FORMID_SIKTEMÅL_FOR_BEHANDLINGEN_PREOPERATIV_INTENSJON], api);
    checkAndSetOccurrencyAimForTreatment(false, api);
  }
}

exports.BehandlingRettetMotSiktemål = BehandlingRettetMotSiktemål;

function BehandlingRettetMotForbehandling(api) {
  var BehandlingRettetMot1 = api.getFieldValue(BEHANDLINGEN_VAR_RETTET_MOT);
  console.log("Kjører funskjon for BehandlingRettetMotForbehandling");

  if (GlobalFunctions_1.ArenaVersionValueCheck(BehandlingRettetMot1)) {
    if (BehandlingRettetMot1.value == "Primærtumor (med eller uten metastase(r))" || "Lokalt residiv (med eller uten metastase(r))" || "Kun metastase(r)") {
      console.log("Bruker har valgt Forbehandling" + BehandlingRettetMot1.value);
      api.showField(FORMID_FORBEHANDLING_CLUSTER);
      validateForbehandlingKirurgi(api, true);
    }
  } else {
    GlobalFunctions_1.HideAndClear([FORMID_FORBEHANDLING_CLUSTER], api);
  }
}

exports.BehandlingRettetMotForbehandling = BehandlingRettetMotForbehandling;
var FORMID_TREATMENT_AIM = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/siktemål_for_behandlingen_preoperativ_intensjon/siktemål_for_behandlingen_preoperativ_intensjon";

function checkAndSetOccurrencyAimForTreatment(thisValueShoudlBeTrue, api) {
  var teatmentAim = api.getFieldValue(FORMID_TREATMENT_AIM);
  console.log("checkAndSetOccurrencyAimForTreatment kjører");

  if (GlobalFunctions_1.ArenaVersionNullCheckValue(teatmentAim) && thisValueShoudlBeTrue) {
    api.setOccurrences(FORMID_TREATMENT_AIM, "1..1");
  } else {
    api.setOccurrences(FORMID_TREATMENT_AIM, "0..1");
  }
}

exports.checkAndSetOccurrencyAimForTreatment = checkAndSetOccurrencyAimForTreatment;
},{"./GlobalFunctions":3}],3:[function(require,module,exports){
"use strict";

exports.__esModule = true;

// Kommentert ut av byggescript = require("ehrcraft-form-api");

function HideAndClear(params, api, occurence) {
  if (!occurence || occurence.Value == null) for (var i = 0; i < params.length; i++) {
    api.hideField(params[i]);
    api.clearField(params[i]);
  }
  if (occurence) for (var i = 0; i < params.length; i++) {
    api.hideField(params[i]);
    api.clearField(params[i]);
    api.setOccurrences(params[i], occurence);
  }
}

exports.HideAndClear = HideAndClear;

function ShowAndSetOccurence(params, api, occurence) {
  for (var i = 0; i < params.length; i++) {
    api.showField(params[i]);
    api.setOccurrences(params[i], occurence);
  }
}

exports.ShowAndSetOccurence = ShowAndSetOccurence;

function searchForValue(array, searchValue, functionThatCallsMe) {
  var arrayToSearch = array;

  function testFunction(element) {
    if (!element || element.Value == null) {
      return "ERROR" === searchValue;
    } else {
      return element.value === searchValue;
    }
  }

  var retval = arrayToSearch.some(testFunction);
  console.log("Searched for " + searchValue + "Returned value is : " + retval);
  return retval;
}

exports.searchForValue = searchForValue;

function CheckNullSwitch(value) {
  var returnValue = false;

  if (!value) {
    returnValue = false;
  } else {
    returnValue = true;
  }

  return returnValue;
}

exports.CheckNullSwitch = CheckNullSwitch;

function countCertainElementsInArray(array) {
  var count = array.map(function (x) {
    return x.value;
  }).length;
  console.log(count + "THIS MANY VALUES");
  return count;
}

exports.countCertainElementsInArray = countCertainElementsInArray;

function ArenaVersionValueCheck(value) {
  if (value && value.Value != null) {
    return true;
  } else {
    return false;
  }
}

exports.ArenaVersionValueCheck = ArenaVersionValueCheck;

function ArenaVersionMagnitudeCheck(value) {
  if (value && value.Magnitude != 0.0) {
    return true;
  } else {
    return false;
  }
}

exports.ArenaVersionMagnitudeCheck = ArenaVersionMagnitudeCheck;

function ArenaVersionNullCheckValue(value) {
  if (!value || value.Value == null || value.Value == false) {
    return true;
  } else {
    return false;
  }
}

exports.ArenaVersionNullCheckValue = ArenaVersionNullCheckValue;

function ArenaVersionNullCheckMagnitude(value) {
  if (!value || value.Magnitude == null || value.Magnitude == false) {
    return true;
  } else {
    return false;
  }
}

exports.ArenaVersionNullCheckMagnitude = ArenaVersionNullCheckMagnitude;

function BMICalculate(weight, height) {
  var BMIcalc = weight / (height / 100 * height / 100);
  var BMI = new DvQuantity();
  console.log(BMI);
  BMI.Magnitude = BMIcalc;
  BMI.Units = "kg/m3";
  console.log(BMI);
  return BMI;
}

exports.BMICalculate = BMICalculate;
},{}],4:[function(require,module,exports){
"use strict";

exports.__esModule = true;

var GlobalFunctions_1 = require("./GlobalFunctions");

var BEHANDLINGEN_VAR_RETTET_MOT = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/behandlingen_var_rettet_mot";
var FORMID_INNGREP_MOT_METASTER_I_SAMME_INNGREP_FRA_PRIMÆR = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/intraoperative_funn/er_det_i_samme_operasjon_gjort_inngrep_mot_metastaser";
var FORMID_INNGREP_MOT_METASTER_I_SAMME_INNGREP_FRA_RESIDIV = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_lokalt_residiv/er_det_i_samme_operasjon_gjort_inngrep_mot_metastase(r)";
var FORMID_LOKALISASJON_METASTASER = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_metastase(r)/lokalisasjon_av_behandlet_metastase";
var FORMID_LOKALISASJON_METASTASER_FIELDSET = "generic-field-47422";
var FORMID_KIRURGI_AV_METASTASER_CLUSTER = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_metastase(r)";
var FORMID_MAKROSKOPISK_RESTTUMOR = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_metastase(r)/inngrep_metastase/makroskopisk_resttumor_(kirurgens_vurdering)";
var FORMID_KIRUGI_AV_METASTASER_SPESIFISER_INNGREP_MOT_LOKAL_RESIDIV = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_metastase(r)/inngrep_metastase/spesifiser_inngrep";
var FORMID_KIRURGI_AV_METASTASER_LOKALISASJON_SPESIFISER = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_metastase(r)/spesifiser";
var FORMID_KIRURGI_AV_METASTASER_OPERASJONSDATO = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_metastase(r)/operasjonsdato_(dd.mm.åååå)";
var FORMID_KIRURGI_AV_METASTASER_INNGREP = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_metastase(r)/inngrep_metastase/inngrep_metastaser";
var FORMID_KIRURGI_AV_METASTASER_SPESIFISER = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_metastase(r)/inngrep_metastase/spesifiser_inngrep_mot_metaste(r)";
var FORMID_KIRURGI_AV_METASTASER_INNGREP_CLUSTER = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_metastase(r)/inngrep_metastase";

function KirurgiMotMetastaserBehandlingRettetMot(api) {
  var KirurgiMotMetastaserPrimær = api.getFieldValue(FORMID_INNGREP_MOT_METASTER_I_SAMME_INNGREP_FRA_PRIMÆR);
  var KirurgiMotMetastaserResidiv = api.getFieldValue(FORMID_INNGREP_MOT_METASTER_I_SAMME_INNGREP_FRA_RESIDIV);
  var BehandlingRettetMot1 = api.getFieldValue(BEHANDLINGEN_VAR_RETTET_MOT);
  console.log("KirurgiMotMetastaserBehandlingRettetMot kjører");

  switch (true) {
    case GlobalFunctions_1.ArenaVersionValueCheck(BehandlingRettetMot1) && BehandlingRettetMot1.value == "Kun metastase(r)":
      console.log("KirurgiMotMetastaserBehandlingRettetMot running because the user has selected" + BehandlingRettetMot1.value);
      api.showField(FORMID_KIRURGI_AV_METASTASER_CLUSTER); //api.showField(FORMID_LOKALISASJON_METASTASER)

      api.showField(FORMID_LOKALISASJON_METASTASER_FIELDSET);
      api.showField(FORMID_KIRURGI_AV_METASTASER_OPERASJONSDATO);
      api.showField(FORMID_KIRURGI_AV_METASTASER_INNGREP_CLUSTER); // api.showField(FORMID_KIRURGI_AV_METASTASER_INNGREP)

      api.showField(FORMID_MAKROSKOPISK_RESTTUMOR);
      api.setOccurrences(FORMID_KIRURGI_AV_METASTASER_OPERASJONSDATO, "1..1");
      ValidateSurgeryOtherMetastasis(api);
      ValidateLocationOtherMetastasis(api);
      checkAndSetOccurrencyMetastatic(true, api);
      break;

    case GlobalFunctions_1.ArenaVersionValueCheck(KirurgiMotMetastaserPrimær) && KirurgiMotMetastaserPrimær.value == true || GlobalFunctions_1.ArenaVersionValueCheck(KirurgiMotMetastaserResidiv) && KirurgiMotMetastaserResidiv.value == true:
      //api.showField(FORMID_LOKALISASJON_METASTASER)
      api.showField(FORMID_LOKALISASJON_METASTASER_FIELDSET);
      api.showField(FORMID_MAKROSKOPISK_RESTTUMOR);
      api.showField(FORMID_KIRURGI_AV_METASTASER_CLUSTER);
      api.showField(FORMID_KIRURGI_AV_METASTASER_INNGREP_CLUSTER);
      api.setOccurrences(FORMID_KIRURGI_AV_METASTASER_OPERASJONSDATO, "0..1");
      ValidateSurgeryOtherMetastasis(api);
      ValidateLocationOtherMetastasis(api);
      checkAndSetOccurrencyMetastatic(true, api);
      break;

    case GlobalFunctions_1.ArenaVersionNullCheckValue(KirurgiMotMetastaserPrimær) || GlobalFunctions_1.ArenaVersionNullCheckValue(KirurgiMotMetastaserResidiv):
      //api.hideField(FORMID_LOKALISASJON_METASTASER)
      api.hideField(FORMID_KIRURGI_AV_METASTASER_INNGREP_CLUSTER);
      GlobalFunctions_1.HideAndClear([FORMID_LOKALISASJON_METASTASER_FIELDSET, FORMID_KIRURGI_AV_METASTASER_CLUSTER, FORMID_MAKROSKOPISK_RESTTUMOR], api);
      ValidateSurgeryOtherMetastasis(api);
      ValidateLocationOtherMetastasis(api);
      checkAndSetOccurrencyMetastatic(false, api);
      break;

    case GlobalFunctions_1.CheckNullSwitch(KirurgiMotMetastaserPrimær) && GlobalFunctions_1.CheckNullSwitch(KirurgiMotMetastaserResidiv) && GlobalFunctions_1.CheckNullSwitch(BehandlingRettetMot1):
      //api.hideField(FORMID_LOKALISASJON_METASTASER)
      api.hideField(FORMID_KIRURGI_AV_METASTASER_INNGREP_CLUSTER);
      GlobalFunctions_1.HideAndClear([FORMID_LOKALISASJON_METASTASER_FIELDSET, FORMID_KIRURGI_AV_METASTASER_CLUSTER, FORMID_MAKROSKOPISK_RESTTUMOR], api);
      ValidateSurgeryOtherMetastasis(api);
      ValidateLocationOtherMetastasis(api);
      checkAndSetOccurrencyMetastatic(false, api);
      break;

    case GlobalFunctions_1.CheckNullSwitch(KirurgiMotMetastaserPrimær) && GlobalFunctions_1.CheckNullSwitch(KirurgiMotMetastaserResidiv):
      //api.hideField(FORMID_LOKALISASJON_METASTASER)
      api.hideField(FORMID_KIRURGI_AV_METASTASER_INNGREP_CLUSTER);
      GlobalFunctions_1.HideAndClear([FORMID_LOKALISASJON_METASTASER_FIELDSET, FORMID_KIRURGI_AV_METASTASER_CLUSTER, FORMID_MAKROSKOPISK_RESTTUMOR], api);
      ValidateSurgeryOtherMetastasis(api);
      ValidateLocationOtherMetastasis(api);
      checkAndSetOccurrencyMetastatic(false, api);
      break;

    default:
      GlobalFunctions_1.HideAndClear([FORMID_LOKALISASJON_METASTASER_FIELDSET, FORMID_KIRURGI_AV_METASTASER_CLUSTER, FORMID_MAKROSKOPISK_RESTTUMOR, FORMID_KIRURGI_AV_METASTASER_OPERASJONSDATO, FORMID_KIRURGI_AV_METASTASER_INNGREP_CLUSTER], api); //api.hideField(FORMID_LOKALISASJON_METASTASER)

      checkAndSetOccurrencyMetastatic(false, api);
      break;
  }
}

exports.KirurgiMotMetastaserBehandlingRettetMot = KirurgiMotMetastaserBehandlingRettetMot; //validation

function ValidateLocationOtherMetastasis(api) {
  console.log("Running ValidateLocationOtherMetastasis");
  var otherLocation = api.getFields(FORMID_LOKALISASJON_METASTASER);

  if (otherLocation && GlobalFunctions_1.searchForValue(otherLocation, "Annet", "ValidateLocationOtherMetastasis")) {
    api.showField(FORMID_KIRURGI_AV_METASTASER_LOKALISASJON_SPESIFISER);
  } else {
    api.hideField(FORMID_KIRURGI_AV_METASTASER_LOKALISASJON_SPESIFISER);
    api.clearField(FORMID_KIRURGI_AV_METASTASER_LOKALISASJON_SPESIFISER);
  }
}

exports.ValidateLocationOtherMetastasis = ValidateLocationOtherMetastasis;

function ValidateSurgeryOtherMetastasis(api) {
  console.log("Running ValidateSurgeryOtherMetastasis");
  var AnnenLokBehandletMet = api.getFields(FORMID_KIRURGI_AV_METASTASER_INNGREP);

  if (AnnenLokBehandletMet && GlobalFunctions_1.searchForValue(AnnenLokBehandletMet, "Annet")) {
    console.log("Bruker har valgt Annet som lokalisasjon for behandlede metaster");
    api.showField(FORMID_KIRURGI_AV_METASTASER_SPESIFISER);
    api.showField(FORMID_KIRUGI_AV_METASTASER_SPESIFISER_INNGREP_MOT_LOKAL_RESIDIV);
  } else {
    GlobalFunctions_1.HideAndClear([FORMID_KIRURGI_AV_METASTASER_SPESIFISER, FORMID_KIRUGI_AV_METASTASER_SPESIFISER_INNGREP_MOT_LOKAL_RESIDIV], api);
  }
}

exports.ValidateSurgeryOtherMetastasis = ValidateSurgeryOtherMetastasis; //CHECK OCCURENCES

function checkAndSetOccurrencyMetastatic(thisValueShoudlBeTrue, api) {
  console.log("Running checkAndSetOccurrencyMetastatic");

  if (thisValueShoudlBeTrue) {
    api.setOccurrences(FORMID_LOKALISASJON_METASTASER, "1..10");
    api.setOccurrences(FORMID_KIRURGI_AV_METASTASER_INNGREP, "1..2");
    api.setOccurrences(FORMID_MAKROSKOPISK_RESTTUMOR, "1..1");
  } else {
    api.setOccurrences(FORMID_LOKALISASJON_METASTASER, "0..10");
    api.setOccurrences(FORMID_KIRURGI_AV_METASTASER_OPERASJONSDATO, "0..1");
    api.setOccurrences(FORMID_KIRURGI_AV_METASTASER_INNGREP, "0..2");
    api.setOccurrences(FORMID_MAKROSKOPISK_RESTTUMOR, "0..1");
  }
}

exports.checkAndSetOccurrencyMetastatic = checkAndSetOccurrencyMetastatic;
},{"./GlobalFunctions":3}],5:[function(require,module,exports){
"use strict";

exports.__esModule = true;

var GlobalFunctions_1 = require("./GlobalFunctions");

var FORMID_KIRUGI_AV_PRIMÆRTUMOR_CLUSTER = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor";
var FORMID_LOKALISASJON_PRIMARTUMOR_CLUSTER = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/lokalisasjon_av_primaertumor";
var FORMID_KLINISK_SIKKER_KREFT = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/lokalisasjon_av_primaertumor/klinisk_sikker_kreft";
var FORMID_HASTEGRAD = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/hastegrad/hastegrad";
var FORMID_HASTEGRAD_ANNET = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/hastegrad/spesifiser_hastegrad_annet";
var FORMID_INNGREP_COLON = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/inngrep_colon/inngrep_colon";
var FORMID_INGNREP_RECTUM = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/inngrep_rectum/inngrep_rectum";
var FORMID_ANASTOMOSE = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/anastomose";
var FORMID_RESEKSJON_NABOORGAN = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/reseksjon_av_naboorgan/reseksjon_av_naboorgan";
var FORMID_RESEKSJON = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/reseksjon_av_tumor";
var FORMID_OPERASJON_UTEN_RESEKSJON = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/operasjon_uten_reseksjon_av_tumorbærende_tarmsegment";
var FORMID_OPERASJON__UTEN_RESEKSJON_UTFØRT_INNGREP = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/operasjon_uten_reseksjon_av_tumorbærende_tarmsegment/utført_inngrep";
var FOMRID_SPESIFIED_COLON_SURGERY = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/inngrep_colon/spesifiser_inngrep_colon";
var FOMRID_SPESIFIED_RECTUM_SURGERY = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/inngrep_rectum/spesifiser_inngrep_rectum";
var FORMID_AVLASTENDE_STOMI = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/Avlastende_stomi";
var FORMID_KOMPLIKASJONER_SPESIFISERT = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/komplikasjoner/spesifiser_komplikasjoner_annet";
var FORMID_KONPLIKASJONER_DATO_REOPERASJON = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/komplikasjoner/dato_reoperasjon";
var FORMID_HØYDE = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/kliniske_parametre/høyde_(cm)";
var FORMID_VEKT = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/kliniske_parametre/vekt_(kg)";
var FORMID_HØYDE_UKJENT = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/kliniske_parametre/høyde_ukjent";
var FORMID_VEKT_UKJENT = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/kliniske_parametre/vekt_ukjent";
var FORMID_BMI = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/kliniske_parametre/bmi";
var FORMID_BMI_UKJENT = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/kliniske_parametre/bmi_ukjent";
var FORMID_ASA_SCORE = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/asa-score";
var FORMID_KLINISKE_PARAMETERE_CLUSTER = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/kliniske_parametre";
var FORMID_LOKALISASJON_NABOORGAN = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/reseksjon_av_naboorgan/lokalisasjon";
var FORMID_LOKALISASJON_NABOORGAN_GENERIC_FIELD = "generic-field-44078";
var FORMID_SPEIFISERT_VEKST_I_NABOORGAN = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/intraoperative_funn/spesifiser_annet_naboorgan";
var BEHANDLINGEN_VAR_RETTET_MOT = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/behandlingen_var_rettet_mot";
var FORMID_SPESIFISER_LOKALISASJON_NABOORGAN = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/reseksjon_av_naboorgan/spesifiser_lokalisasjon_annet";
var FORMID_KOMPLIKASJONER_REOPERASJON = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/komplikasjoner/reoperasjon";
var FORMID_KOMPLIKASJONER = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/komplikasjoner/komplikasjoner";
var FORMID_SURGERY_TYPE = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/type_kirurgi";
var FORMID_SURGERY_DATE = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/operasjonsdato";
var FORMID_LEVER_METASTASER = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/intraoperative_funn/levermetastaser";
var FORMID_PERITONEAL_METASTASE = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/intraoperative_funn/peritoneal_metastase_carcinomatose";
var FORMID_LYMFEKNUTEMETASTASE = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/intraoperative_funn/lymfeknutemetastaser_utenfor_reseksjonsområdet";
var FORMID_INNVEKST_I_NABOORGAN = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/intraoperative_funn/innvekst_i_naboorgan";
var FORMID_INNGREP_MOT_METASTER_I_SAMME_INNGREP_FRA_PRIMÆR = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/intraoperative_funn/er_det_i_samme_operasjon_gjort_inngrep_mot_metastaser"; //Intraoperative funn

var FORMID_INTEROPERATIVE_FUNN_CLUSTER = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/intraoperative_funn";
var FORMID_INTEROPERATIVE_FUNN_PERFORASJON_OPPSTÅTT_UNDER_OPERASJON = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/intraoperative_funn/perforasjon_oppstått_under_operasjonen";
var FORMID_INTEROPERATIVE_FUNN_PERFORASJON_OPPSTÅTT_UNDER_OPERASJON_STATUS = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/intraoperative_funn/perforasjon_oppstått_under_operasjonen/perforasjon_status";
var FORMID_INTEROPERATIVE_FUNN_KIRURGENS_VURDERING = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_primærtumor/intraoperative_funn/resttumor_lokalt_(kirurgens_vurdering)";
var FORMID_SIKTEMÅL_FOR_BEHANDLINGEN_PREOPERATIV_INTENSJON = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/siktemål_for_behandlingen_preoperativ_intensjon"; //Kirurgi av primærtumor 

function AnnetLokNaboorgan(api) {
  var AnnetLokNaboorgan = api.getFields(FORMID_LOKALISASJON_NABOORGAN);

  if (GlobalFunctions_1.searchForValue(AnnetLokNaboorgan, "Annet")) {
    api.showField(FORMID_SPESIFISER_LOKALISASJON_NABOORGAN);
  } else {
    api.hideField(FORMID_SPESIFISER_LOKALISASJON_NABOORGAN);
  }
}

exports.AnnetLokNaboorgan = AnnetLokNaboorgan;

function ReseksjonNaboorgan(api) {
  var ReseksjonNaboorgan = api.getFieldValue(FORMID_RESEKSJON_NABOORGAN);
  console.log("ReseksjonNaboorgan is running");

  switch (true) {
    case GlobalFunctions_1.ArenaVersionValueCheck(ReseksjonNaboorgan) && ReseksjonNaboorgan.value == true:
      console.log("ReseksjonNaboorgan is selected true by the user");
      api.showField(FORMID_LOKALISASJON_NABOORGAN);
      api.showField(FORMID_LOKALISASJON_NABOORGAN_GENERIC_FIELD);
      checkAndSetOccurrencyTumorResectionLocalisation(true, api);
      break;

    case GlobalFunctions_1.ArenaVersionValueCheck(ReseksjonNaboorgan) && ReseksjonNaboorgan.value == false:
      console.log("ReseksjonNaboorgan is selected false by the user");
      GlobalFunctions_1.HideAndClear([FORMID_LOKALISASJON_NABOORGAN, FORMID_LOKALISASJON_NABOORGAN_GENERIC_FIELD], api);
      checkAndSetOccurrencyTumorResectionLocalisation(false, api);
      break;

    default:
      console.log("ReseksjonNaboorgan is not selected by the user");
      GlobalFunctions_1.HideAndClear([FORMID_LOKALISASJON_NABOORGAN, FORMID_LOKALISASJON_NABOORGAN_GENERIC_FIELD], api);
      checkAndSetOccurrencyTumorResectionLocalisation(false, api);
      break;
  }
}

exports.ReseksjonNaboorgan = ReseksjonNaboorgan;

function BehandliungRettetMotPrimærTumor(api) {
  var BehandlingRettetMot1 = api.getFieldValue(BEHANDLINGEN_VAR_RETTET_MOT);
  console.log(BehandlingRettetMot1);

  if (GlobalFunctions_1.ArenaVersionValueCheck(BehandlingRettetMot1) && BehandlingRettetMot1.value == "Primærtumor (med eller uten metastase(r))") {
    //Kirurgi av primærtumor
    console.log("BehandliungRettetMotPrimærTumor running because the user has selected" + BehandlingRettetMot1.value);
    GlobalFunctions_1.ShowAndSetOccurence([FORMID_KIRUGI_AV_PRIMÆRTUMOR_CLUSTER, FORMID_HASTEGRAD, FORMID_ASA_SCORE, FORMID_KLINISKE_PARAMETERE_CLUSTER, FORMID_SURGERY_TYPE, FORMID_RESEKSJON], api, "1..1");
    api.showField(FORMID_HØYDE);
    api.showField(FORMID_HØYDE_UKJENT);
    api.showField(FORMID_VEKT);
    api.showField(FORMID_VEKT_UKJENT);
    api.showField(FORMID_BMI);
    api.showField(FORMID_BMI_UKJENT);
    api.showField(FORMID_SURGERY_DATE);
    api.showField(FORMID_KLINISK_SIKKER_KREFT);
    api.showField(FORMID_LOKALISASJON_PRIMARTUMOR_CLUSTER); //Intraoperative funn

    GlobalFunctions_1.ShowAndSetOccurence([FORMID_INTEROPERATIVE_FUNN_CLUSTER, FORMID_LEVER_METASTASER, FORMID_PERITONEAL_METASTASE, FORMID_LYMFEKNUTEMETASTASE, FORMID_INNVEKST_I_NABOORGAN, FORMID_INTEROPERATIVE_FUNN_PERFORASJON_OPPSTÅTT_UNDER_OPERASJON, FORMID_INTEROPERATIVE_FUNN_PERFORASJON_OPPSTÅTT_UNDER_OPERASJON_STATUS, FORMID_INTEROPERATIVE_FUNN_KIRURGENS_VURDERING, FORMID_INNGREP_MOT_METASTER_I_SAMME_INNGREP_FRA_PRIMÆR, FORMID_SIKTEMÅL_FOR_BEHANDLINGEN_PREOPERATIV_INTENSJON], api, "1..3"); //Komplikasjoner

    api.showField(FORMID_KOMPLIKASJONER);
    checkAndSetOccurrencyUrgency(true, api);
    checkAndSetOccurrencyASA(true, api);
    checkAndSetOccurrencyWeight(true, api);
    checkAndSetOccurrencyHeight(true, api);
    checkAndSetOccurrencyTypeOfSurgery(true, api);
    checkAndSetOccurrencyDateOfSurgery(true, api);
    checkAndSetOccurrencyResectionTumor(true, api);
    checkAndSetOccurrencyInteropartiveFindings(true, api);
    validateComplications(api);
    checkAndSetOccurrencyPerforationStatus(true, api);
    checkAndSetOccurrencySurgeonEvaluation(true, api);
    checkAndSetOccurrencyClinicalConfirmedCancer(true, api);
  } else {
    GlobalFunctions_1.HideAndClear([FORMID_HASTEGRAD, FORMID_OPERASJON__UTEN_RESEKSJON_UTFØRT_INNGREP], api);
    GlobalFunctions_1.HideAndClear([
    /**Kirurgi av primærtumor */
    FORMID_KIRUGI_AV_PRIMÆRTUMOR_CLUSTER, FORMID_HASTEGRAD, FORMID_ASA_SCORE, FORMID_KLINISKE_PARAMETERE_CLUSTER, FORMID_HØYDE, FORMID_HØYDE_UKJENT, FORMID_VEKT, FORMID_VEKT_UKJENT, FORMID_BMI, FORMID_BMI_UKJENT, FORMID_SURGERY_TYPE, FORMID_SURGERY_DATE, FORMID_RESEKSJON, FORMID_KLINISK_SIKKER_KREFT,
    /**Intraoperative funn */
    FORMID_INTEROPERATIVE_FUNN_CLUSTER, FORMID_LEVER_METASTASER, FORMID_PERITONEAL_METASTASE, FORMID_LYMFEKNUTEMETASTASE, FORMID_INNVEKST_I_NABOORGAN, FORMID_INTEROPERATIVE_FUNN_PERFORASJON_OPPSTÅTT_UNDER_OPERASJON, FORMID_INTEROPERATIVE_FUNN_PERFORASJON_OPPSTÅTT_UNDER_OPERASJON_STATUS, FORMID_INTEROPERATIVE_FUNN_KIRURGENS_VURDERING, FORMID_INNGREP_MOT_METASTER_I_SAMME_INNGREP_FRA_PRIMÆR,
    /**Komplikasjoner */
    FORMID_KOMPLIKASJONER], api, "0..1");
    api.hideField(FORMID_LOKALISASJON_PRIMARTUMOR_CLUSTER);
    checkAndSetOccurrencyUrgency(false, api);
    checkAndSetOccurrencyASA(false, api);
    checkAndSetOccurrencyWeight(false, api);
    checkAndSetOccurrencyHeight(false, api);
    checkAndSetOccurrencyTypeOfSurgery(false, api);
    checkAndSetOccurrencyDateOfSurgery(false, api);
    checkAndSetOccurrencyResectionTumor(false, api);
    checkAndSetOccurrencyTumorResection(false, api);
    checkAndSetOccurrencyTumorResectionLocalisation(false, api);
    checkAndSetOccurrencySurgeryColonOrRectum(false, api);
    checkAndSetOccurrencyRelivingStoma(false, api);
    checkAndSetOccurrencySurgeryWithoutResectionOfTumorcarryingSegment(false, api);
    checkAndSetOccurrencyInteropartiveFindings(false, api);
    validateComplications(api);
    checkAndSetOccurrencyPerforationStatus(false, api);
    checkAndSetOccurrencySurgeonEvaluation(false, api);
    checkAndSetOccurrencyClinicalConfirmedCancer(false, api);
  }
}

exports.BehandliungRettetMotPrimærTumor = BehandliungRettetMotPrimærTumor; //Validation

function validateUrgency(api) {
  var hastegrad = api.getFieldValue(FORMID_HASTEGRAD);
  console.log("Urgency validation running");

  if (GlobalFunctions_1.ArenaVersionValueCheck(hastegrad) && hastegrad.value == "Akutt pga annet") {
    api.showField(FORMID_HASTEGRAD_ANNET);
  } else {
    api.clearField(FORMID_HASTEGRAD_ANNET);
    api.hideField(FORMID_HASTEGRAD_ANNET);
  }
}

exports.validateUrgency = validateUrgency;

function validateClinicalParameters(api) {
  var heightUnknown = api.getFieldValue(FORMID_HØYDE_UKJENT);
  var weightUnknown = api.getFieldValue(FORMID_VEKT_UKJENT);
  var height = api.getFieldValue(FORMID_HØYDE);
  var weight = api.getFieldValue(FORMID_VEKT);
  console.log("validateClinicalParameters running");

  switch (true) {
    case GlobalFunctions_1.ArenaVersionMagnitudeCheck(height):
      console.log("Hight has value hidding Unkown");
      api.hideField(FORMID_HØYDE_UKJENT);
      checkAndSetOccurrencyHeight(true, api);
      break;

    case GlobalFunctions_1.ArenaVersionNullCheckMagnitude(height):
      console.log("Hight dosent have value showing Unkown");
      api.showField(FORMID_HØYDE_UKJENT);
      checkAndSetOccurrencyHeight(true, api);
      break;

    case GlobalFunctions_1.ArenaVersionValueCheck(heightUnknown) && heightUnknown.value == true:
      console.log("Hight is selected Unknown by the user");
      GlobalFunctions_1.HideAndClear([FORMID_HØYDE, FORMID_BMI], api);
      checkAndSetOccurrencyHeight(true, api);
      break;

    case GlobalFunctions_1.ArenaVersionNullCheckValue(heightUnknown):
      console.log("Hight is not selected Unknown by the user");
      api.showField(FORMID_HØYDE);
      checkAndSetOccurrencyHeight(true, api);
      break;

    default:
      break;
  }

  switch (true) {
    case GlobalFunctions_1.ArenaVersionMagnitudeCheck(weight):
      console.log("weight has value hidding Unkown");
      api.hideField(FORMID_VEKT_UKJENT);
      checkAndSetOccurrencyWeight(true, api);
      break;

    case GlobalFunctions_1.ArenaVersionNullCheckMagnitude(weight):
      console.log("weight dosent have value showing Unkown");
      api.showField(FORMID_VEKT_UKJENT);
      checkAndSetOccurrencyWeight(true, api);
      break;

    case GlobalFunctions_1.ArenaVersionValueCheck(weightUnknown) && weightUnknown.value == true:
      console.log("weight is selected Unknown by the user");
      GlobalFunctions_1.HideAndClear([FORMID_VEKT], api);
      checkAndSetOccurrencyWeight(true, api);
      break;

    case GlobalFunctions_1.ArenaVersionNullCheckValue(weightUnknown):
      console.log("Hight is not selected Unknown by the user");
      api.showField(FORMID_VEKT);
      checkAndSetOccurrencyWeight(true, api);
      break;

    default:
      break;
  }

  if (GlobalFunctions_1.ArenaVersionMagnitudeCheck(weight) && GlobalFunctions_1.ArenaVersionMagnitudeCheck(height)) {
    api.setFieldValue(FORMID_BMI, GlobalFunctions_1.BMICalculate(weight.Magnitude, height.Magnitude));
    api.hideField(FORMID_BMI_UKJENT);
  } else {
    api.clearField(FORMID_BMI);
    api.showField(FORMID_BMI_UKJENT);
  }
}

exports.validateClinicalParameters = validateClinicalParameters;

function validateResectionTumor(api) {
  console.log("validateResectionTumor running");
  var rescetionTumor = api.getFieldValue(FORMID_RESEKSJON);

  switch (true) {
    case GlobalFunctions_1.ArenaVersionValueCheck(rescetionTumor) && rescetionTumor.value == true:
      console.log("Resectioning of tumor is selected true by the user");
      api.showField(FORMID_INNGREP_COLON);
      api.showField(FORMID_INGNREP_RECTUM);
      api.showField(FORMID_ANASTOMOSE);
      api.showField(FORMID_RESEKSJON_NABOORGAN);
      GlobalFunctions_1.HideAndClear([FORMID_OPERASJON_UTEN_RESEKSJON, FORMID_OPERASJON__UTEN_RESEKSJON_UTFØRT_INNGREP], api);
      checkAndSetOccurrencySurgeryColonOrRectum(true, api);
      checkAndSetOccurrencyTumorResection(true, api);
      checkAndSetOccurrencySurgeryWithoutResectionOfTumorcarryingSegment(false, api);
      break;

    case GlobalFunctions_1.ArenaVersionValueCheck(rescetionTumor) && api.getFieldValue("generic-field-40749").Value == "False":
      console.log("Resectioning of tumor is selected false by the user");
      GlobalFunctions_1.HideAndClear([FORMID_INNGREP_COLON, FORMID_INGNREP_RECTUM, FORMID_ANASTOMOSE, FORMID_RESEKSJON_NABOORGAN], api);
      api.showField(FORMID_OPERASJON_UTEN_RESEKSJON);
      api.showField(FORMID_OPERASJON__UTEN_RESEKSJON_UTFØRT_INNGREP);
      checkAndSetOccurrencySurgeryColonOrRectum(false, api);
      checkAndSetOccurrencyTumorResection(false, api);
      checkAndSetOccurrencySurgeryWithoutResectionOfTumorcarryingSegment(true, api);
      break;

    default:
      console.log("Resectioning of tumor is not selected by the user");
      GlobalFunctions_1.HideAndClear([FORMID_INNGREP_COLON, FORMID_INGNREP_RECTUM, FORMID_ANASTOMOSE, FORMID_RESEKSJON_NABOORGAN, FORMID_OPERASJON_UTEN_RESEKSJON, FORMID_OPERASJON__UTEN_RESEKSJON_UTFØRT_INNGREP], api);
      checkAndSetOccurrencySurgeryColonOrRectum(false, api);
      checkAndSetOccurrencyTumorResection(false, api);
      checkAndSetOccurrencySurgeryWithoutResectionOfTumorcarryingSegment(false, api);
      break;
  }
}

exports.validateResectionTumor = validateResectionTumor;

function validateColonSurgery(api) {
  console.log("validateColonSurgery running");
  var ColonSurgery = api.getFieldValue(FORMID_INNGREP_COLON);

  if (GlobalFunctions_1.ArenaVersionValueCheck(ColonSurgery) && ColonSurgery.value == "Annet") {
    api.showField(FOMRID_SPESIFIED_COLON_SURGERY);
  } else {
    GlobalFunctions_1.HideAndClear([FOMRID_SPESIFIED_COLON_SURGERY], api);
  }
}

exports.validateColonSurgery = validateColonSurgery;

function validateRectumSurgery(api) {
  console.log("validateRectumSurgery running");
  var RectumSurgery = api.getFieldValue(FORMID_INGNREP_RECTUM);

  if (GlobalFunctions_1.ArenaVersionValueCheck(RectumSurgery) && RectumSurgery.value == "Annet") {
    api.showField(FOMRID_SPESIFIED_RECTUM_SURGERY);
  } else {
    GlobalFunctions_1.HideAndClear([FOMRID_SPESIFIED_RECTUM_SURGERY], api);
  }
}

exports.validateRectumSurgery = validateRectumSurgery;

function validateAnostemose(api) {
  console.log("validateAnostemose running");
  var anestomoste = api.getFieldValue(FORMID_ANASTOMOSE);

  if (anestomoste && anestomoste.value == true) {
    api.showField(FORMID_AVLASTENDE_STOMI);
    checkAndSetOccurrencyRelivingStoma(true, api);
  } else {
    GlobalFunctions_1.HideAndClear([FORMID_AVLASTENDE_STOMI], api);
    checkAndSetOccurrencyRelivingStoma(false, api);
  }
}

exports.validateAnostemose = validateAnostemose;

function validateLocation(api) {
  console.log("validateLocation running");
  var ResectionNeighourOrgan = api.getFieldValue(FORMID_RESEKSJON_NABOORGAN);

  if (ResectionNeighourOrgan && ResectionNeighourOrgan.value == false) {
    api.clearField(FORMID_LOKALISASJON_NABOORGAN);
  }
}

exports.validateLocation = validateLocation; //valiadation Intraoperative funn

function validateGrowthIntoNabouringOrgan(api) {
  console.log("validateGrowthIntoNabouringOrgan running");
  var GrowthIntoNeigbourOrgan = api.getFieldValue(FORMID_INNVEKST_I_NABOORGAN);

  if (GlobalFunctions_1.ArenaVersionValueCheck(GrowthIntoNeigbourOrgan) && GrowthIntoNeigbourOrgan.value == "Ja") {
    api.showField(FORMID_SPEIFISERT_VEKST_I_NABOORGAN);
  } else {
    api.hideField(FORMID_SPEIFISERT_VEKST_I_NABOORGAN);
    api.clearField(FORMID_SPEIFISERT_VEKST_I_NABOORGAN);
  }
}

exports.validateGrowthIntoNabouringOrgan = validateGrowthIntoNabouringOrgan; //valiadation komplikasjoner funn

function validateComplications(api) {
  console.log("validateComplications running");
  var complications = api.getFields(FORMID_KOMPLIKASJONER);
  console.log(complications);
  var BehandlingRettetMot1 = api.getFieldValue(BEHANDLINGEN_VAR_RETTET_MOT);

  switch (true) {
    case complications && GlobalFunctions_1.searchForValue(complications, "Ingen", "validateComplications"):
      GlobalFunctions_1.HideAndClear([FORMID_KOMPLIKASJONER_REOPERASJON, FORMID_KOMPLIKASJONER_SPESIFISERT, FORMID_KONPLIKASJONER_DATO_REOPERASJON], api);
      api.setOccurrences(FORMID_KOMPLIKASJONER, "1..1");
      api.setOccurrences(FORMID_KOMPLIKASJONER_REOPERASJON, "0..1");
      break;

    case complications && GlobalFunctions_1.searchForValue(complications, "Annet", "validateComplications"):
      api.showField(FORMID_KOMPLIKASJONER_REOPERASJON);
      api.showField(FORMID_KOMPLIKASJONER_SPESIFISERT);
      api.setOccurrences(FORMID_KOMPLIKASJONER, "1..3");
      api.setOccurrences(FORMID_KOMPLIKASJONER_REOPERASJON, "1..1");
      break;

    case complications && GlobalFunctions_1.searchForValue(complications, "Anastomoselekkasje", "validateComplications"):
      api.showField(FORMID_KOMPLIKASJONER_REOPERASJON);
      GlobalFunctions_1.HideAndClear([FORMID_KOMPLIKASJONER_SPESIFISERT], api);
      api.setOccurrences(FORMID_KOMPLIKASJONER, "1..3");
      api.setOccurrences(FORMID_KOMPLIKASJONER_REOPERASJON, "1..1");
      break;

    case GlobalFunctions_1.ArenaVersionValueCheck(BehandlingRettetMot1) && BehandlingRettetMot1.value == "Primærtumor (med eller uten metastase(r))":
      GlobalFunctions_1.HideAndClear([FORMID_KOMPLIKASJONER_REOPERASJON, FORMID_KOMPLIKASJONER_SPESIFISERT, FORMID_KONPLIKASJONER_DATO_REOPERASJON], api);
      api.setOccurrences(FORMID_KOMPLIKASJONER, "1..3");
      api.setOccurrences(FORMID_KOMPLIKASJONER_REOPERASJON, "0..1");
      break;

    default:
      console.log("No complications selected");
      GlobalFunctions_1.HideAndClear([FORMID_KOMPLIKASJONER_REOPERASJON, FORMID_KOMPLIKASJONER_SPESIFISERT, FORMID_KONPLIKASJONER_DATO_REOPERASJON], api);
      api.setOccurrences(FORMID_KOMPLIKASJONER, "0..3");
      api.setOccurrences(FORMID_KOMPLIKASJONER_REOPERASJON, "0..1");
      break;
  }
}

exports.validateComplications = validateComplications;

function validateReoperation(api) {
  console.log("validateReoperation running");
  var reop = api.getFieldValue(FORMID_KOMPLIKASJONER_REOPERASJON);

  switch (true) {
    case reop && reop.value == "Ja":
      api.showField(FORMID_KONPLIKASJONER_DATO_REOPERASJON);
      checkAndSetOccurrencyComplicationsReoperationDate(true, api);
      break;

    case reop && (reop.value == "Nei" || reop.value == "Ukjent"):
      api.hideField(FORMID_KONPLIKASJONER_DATO_REOPERASJON);
      checkAndSetOccurrencyComplicationsReoperationDate(false, api);
      break;

    default:
      api.hideField(FORMID_KONPLIKASJONER_DATO_REOPERASJON);
      checkAndSetOccurrencyComplicationsReoperationDate(false, api);
      break;
  }
}

exports.validateReoperation = validateReoperation; //OCCURENCY CHECK

function checkAndSetOccurrencyUrgency(thisValueShoudlBeTrue, api) {
  var urgency = api.getFieldValue(FORMID_HASTEGRAD);

  if (GlobalFunctions_1.ArenaVersionNullCheckValue(urgency) && thisValueShoudlBeTrue) {
    api.setOccurrences(FORMID_HASTEGRAD, "1..1");
  } else {
    api.setOccurrences(FORMID_HASTEGRAD, "0..1");
  }
}

exports.checkAndSetOccurrencyUrgency = checkAndSetOccurrencyUrgency;

function checkAndSetOccurrencyASA(thisValueShoudlBeTrue, api) {
  var asaScore = api.getFieldValue(FORMID_ASA_SCORE);

  if (GlobalFunctions_1.ArenaVersionNullCheckValue(asaScore) && thisValueShoudlBeTrue) {
    api.setOccurrences(FORMID_ASA_SCORE, "1..1");
  } else {
    api.setOccurrences(FORMID_ASA_SCORE, "0..1");
  }
}

exports.checkAndSetOccurrencyASA = checkAndSetOccurrencyASA;

function checkAndSetOccurrencyClinicalConfirmedCancer(thisValueShoudlBeTrue, api) {
  var clinicalCertainCancer = api.getFieldValue(FORMID_KLINISK_SIKKER_KREFT);

  if (GlobalFunctions_1.ArenaVersionNullCheckValue(clinicalCertainCancer) && thisValueShoudlBeTrue) {
    api.setOccurrences(FORMID_KLINISK_SIKKER_KREFT, "1..1");
  } else {
    api.setOccurrences(FORMID_KLINISK_SIKKER_KREFT, "0..1");
  }
}

exports.checkAndSetOccurrencyClinicalConfirmedCancer = checkAndSetOccurrencyClinicalConfirmedCancer;

function checkAndSetOccurrencyHeight(thisValueShoudlBeTrue, api) {
  var hight = api.getFieldValue(FORMID_HØYDE);
  var heightUnknown = api.getFieldValue(FORMID_HØYDE_UKJENT);
  console.log(hight);
  console.log(heightUnknown);

  if (GlobalFunctions_1.ArenaVersionNullCheckMagnitude(hight) && GlobalFunctions_1.ArenaVersionNullCheckValue(heightUnknown) && thisValueShoudlBeTrue) {
    api.setOccurrences(FORMID_HØYDE, "1..1");
    api.setOccurrences(FORMID_HØYDE_UKJENT, "1..1");
  } else {
    api.setOccurrences(FORMID_HØYDE, "0..1");
    api.setOccurrences(FORMID_HØYDE_UKJENT, "0..1");
  }
}

exports.checkAndSetOccurrencyHeight = checkAndSetOccurrencyHeight;

function checkAndSetOccurrencyWeight(thisValueShoudlBeTrue, api) {
  var weight = api.getFieldValue(FORMID_VEKT);
  var weightUnknown = api.getFieldValue(FORMID_VEKT_UKJENT);

  if (GlobalFunctions_1.ArenaVersionNullCheckMagnitude(weight) && GlobalFunctions_1.ArenaVersionNullCheckValue(weightUnknown) && thisValueShoudlBeTrue) {
    api.setOccurrences(FORMID_VEKT, "1..1");
    api.setOccurrences(FORMID_VEKT_UKJENT, "1..1");
  } else {
    api.setOccurrences(FORMID_VEKT, "0..1");
    api.setOccurrences(FORMID_VEKT_UKJENT, "0..1");
  }
}

exports.checkAndSetOccurrencyWeight = checkAndSetOccurrencyWeight;

function checkAndSetOccurrencyTypeOfSurgery(thisValueShoudlBeTrue, api) {
  var surgeryType = api.getFieldValue(FORMID_SURGERY_TYPE);

  if (GlobalFunctions_1.ArenaVersionNullCheckValue(surgeryType) && thisValueShoudlBeTrue) {
    api.setOccurrences(FORMID_SURGERY_TYPE, "1..1");
  } else {
    api.setOccurrences(FORMID_SURGERY_TYPE, "0..1");
  }
}

exports.checkAndSetOccurrencyTypeOfSurgery = checkAndSetOccurrencyTypeOfSurgery;

function checkAndSetOccurrencyDateOfSurgery(thisValueShoudlBeTrue, api) {
  var surgeryDate = api.getFieldValue(FORMID_SURGERY_DATE);

  if (GlobalFunctions_1.ArenaVersionNullCheckValue(surgeryDate) && thisValueShoudlBeTrue) {
    api.setOccurrences(FORMID_SURGERY_DATE, "1..1");
  } else {
    api.setOccurrences(FORMID_SURGERY_DATE, "0..1");
  }
}

exports.checkAndSetOccurrencyDateOfSurgery = checkAndSetOccurrencyDateOfSurgery;

function checkAndSetOccurrencyResectionTumor(thisValueShoudlBeTrue, api) {
  var resectionOfTumer = api.getFieldValue(FORMID_RESEKSJON);

  if (GlobalFunctions_1.ArenaVersionNullCheckValue(resectionOfTumer) && thisValueShoudlBeTrue) {
    api.setOccurrences(FORMID_RESEKSJON, "1..1");
  } else {
    api.setOccurrences(FORMID_RESEKSJON, "0..1");
  }
}

exports.checkAndSetOccurrencyResectionTumor = checkAndSetOccurrencyResectionTumor;

function checkAndSetOccurrencySurgeryColonOrRectum(thisValueShoudlBeTrue, api) {
  var ColonSurgery = api.getFieldValue(FORMID_INNGREP_COLON);
  var RectumSurgery = api.getFieldValue(FORMID_INGNREP_RECTUM);
  console.log("checkAndSetOccurrencySurgeryColonOrRectum Running");

  if (GlobalFunctions_1.ArenaVersionNullCheckValue(ColonSurgery) && GlobalFunctions_1.ArenaVersionNullCheckValue(RectumSurgery) && thisValueShoudlBeTrue) {
    api.setOccurrences(FORMID_INNGREP_COLON, "1..1");
    api.setOccurrences(FORMID_INGNREP_RECTUM, "1..1");
  } else {
    api.setOccurrences(FORMID_INNGREP_COLON, "0..1");
    api.setOccurrences(FORMID_INGNREP_RECTUM, "0..1");
  }

  if (GlobalFunctions_1.ArenaVersionNullCheckValue(ColonSurgery)) {
    api.enableField(FORMID_INGNREP_RECTUM);
  } else {
    api.disableField(FORMID_INGNREP_RECTUM);
  }

  if (GlobalFunctions_1.ArenaVersionNullCheckValue(RectumSurgery)) {
    api.enableField(FORMID_INNGREP_COLON);
  } else {
    api.disableField(FORMID_INNGREP_COLON);
  }
}

exports.checkAndSetOccurrencySurgeryColonOrRectum = checkAndSetOccurrencySurgeryColonOrRectum;

function checkAndSetOccurrencyTumorResection(thisValueShoudlBeTrue, api) {
  var tumorResection = api.getFieldValue(FORMID_RESEKSJON);

  if (GlobalFunctions_1.ArenaVersionValueCheck(tumorResection) && tumorResection.value == true && thisValueShoudlBeTrue) {
    api.setOccurrences(FORMID_ANASTOMOSE, "1..1");
    api.setOccurrences(FORMID_RESEKSJON_NABOORGAN, "1..1");
  } else {
    api.setOccurrences(FORMID_ANASTOMOSE, "0..1");
    api.setOccurrences(FORMID_RESEKSJON_NABOORGAN, "0..1");
  }
}

exports.checkAndSetOccurrencyTumorResection = checkAndSetOccurrencyTumorResection;

function checkAndSetOccurrencyTumorResectionLocalisation(thisValueShoudlBeTrue, api) {
  if (thisValueShoudlBeTrue) {
    api.setOccurrences(FORMID_LOKALISASJON_NABOORGAN, "1..10");
  } else {
    api.setOccurrences(FORMID_LOKALISASJON_NABOORGAN, "0..10");
  }
}

exports.checkAndSetOccurrencyTumorResectionLocalisation = checkAndSetOccurrencyTumorResectionLocalisation;

function checkAndSetOccurrencyRelivingStoma(thisValueShoudlBeTrue, api) {
  if (thisValueShoudlBeTrue) {
    api.setOccurrences(FORMID_AVLASTENDE_STOMI, "1..1");
  } else {
    api.setOccurrences(FORMID_AVLASTENDE_STOMI, "0..10");
  }
}

exports.checkAndSetOccurrencyRelivingStoma = checkAndSetOccurrencyRelivingStoma;

function checkAndSetOccurrencySurgeryWithoutResectionOfTumorcarryingSegment(thisValueShoudlBeTrue, api) {
  if (thisValueShoudlBeTrue) {
    api.setOccurrences(FORMID_OPERASJON__UTEN_RESEKSJON_UTFØRT_INNGREP, "1..10");
  } else {
    api.setOccurrences(FORMID_OPERASJON__UTEN_RESEKSJON_UTFØRT_INNGREP, "0..10");
  }
}

exports.checkAndSetOccurrencySurgeryWithoutResectionOfTumorcarryingSegment = checkAndSetOccurrencySurgeryWithoutResectionOfTumorcarryingSegment;

function checkAndSetOccurrencyInteropartiveFindings(thisValueShoudlBeTrue, api) {
  if (thisValueShoudlBeTrue) {
    api.setOccurrences(FORMID_LEVER_METASTASER, "1..1");
    api.setOccurrences(FORMID_PERITONEAL_METASTASE, "1..1");
    api.setOccurrences(FORMID_LYMFEKNUTEMETASTASE, "1..1");
    api.setOccurrences(FORMID_INNVEKST_I_NABOORGAN, "1..1");
  } else {
    api.setOccurrences(FORMID_LEVER_METASTASER, "0..1");
    api.setOccurrences(FORMID_PERITONEAL_METASTASE, "0..1");
    api.setOccurrences(FORMID_LYMFEKNUTEMETASTASE, "0..1");
    api.setOccurrences(FORMID_INNVEKST_I_NABOORGAN, "0..1");
  }
}

exports.checkAndSetOccurrencyInteropartiveFindings = checkAndSetOccurrencyInteropartiveFindings;

function checkAndSetOccurrencyComplicationsReoperationDate(thisValueShoudlBeTrue, api) {
  if (thisValueShoudlBeTrue) {
    api.setOccurrences(FORMID_KONPLIKASJONER_DATO_REOPERASJON, "1..1");
  } else {
    api.setOccurrences(FORMID_KONPLIKASJONER_DATO_REOPERASJON, "0..1");
  }
}

exports.checkAndSetOccurrencyComplicationsReoperationDate = checkAndSetOccurrencyComplicationsReoperationDate;

function checkAndSetOccurrencyPerforationStatus(thisValueShoudlBeTrue, api) {
  if (thisValueShoudlBeTrue) {
    api.setOccurrences(FORMID_INTEROPERATIVE_FUNN_PERFORASJON_OPPSTÅTT_UNDER_OPERASJON_STATUS, "1..3");
  } else {
    api.setOccurrences(FORMID_INTEROPERATIVE_FUNN_PERFORASJON_OPPSTÅTT_UNDER_OPERASJON_STATUS, "0..3");
  }
}

exports.checkAndSetOccurrencyPerforationStatus = checkAndSetOccurrencyPerforationStatus;

function checkAndSetOccurrencySurgeonEvaluation(thisValueShoudlBeTrue, api) {
  if (thisValueShoudlBeTrue) {
    api.setOccurrences(FORMID_INTEROPERATIVE_FUNN_KIRURGENS_VURDERING, "1..1");
  } else {
    api.setOccurrences(FORMID_INTEROPERATIVE_FUNN_KIRURGENS_VURDERING, "0..1");
  }
}

exports.checkAndSetOccurrencySurgeonEvaluation = checkAndSetOccurrencySurgeonEvaluation;
},{"./GlobalFunctions":3}],6:[function(require,module,exports){
"use strict";

exports.__esModule = true;

var GlobalFunctions_1 = require("./GlobalFunctions");

var FORMID_OPPFØLGNING_TILTAK = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/oppfølging_tiltak/oppfølging_tiltak";
var FORMID_OPPFØLGNING_TILTAK_PLANLAGT = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/oppfølging_tiltak/planlagt_etterbehandling";
var FORMID_OPPFØLGNING_TILTAK_PLANLAGT_GENERIC = "generic-field-87774";
var FORMID_OPPFØLGNING_TILTAK_PLANLAGT_INGEN_BEHANDLING_ÅRSAK = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/oppfølging_tiltak/årsak_ingen_behandling";
var FORMID_OPPFØLGNING_TILTAK_PLANLAGT_INGEN_BEHANDLING_ÅRSAK_GENERIC = "generic-field-76148";
var FORMID_OPPFØLGNING_TILTAK_PLANLAGT_INGEN_BEHANDLING_ÅRSAK_SPESIFISERT = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/oppfølging_tiltak/spesifiser_årsak_til_ingen_behandling";

function planlagtEtterbehandling(api) {
  var SelectedFollowUpLocation = api.getFields(FORMID_OPPFØLGNING_TILTAK);

  switch (true) {
    case SelectedFollowUpLocation && (GlobalFunctions_1.searchForValue(SelectedFollowUpLocation, "Behandling ved samme institusjon", "planlagtEtterbehandling") || GlobalFunctions_1.searchForValue(SelectedFollowUpLocation, "Behandling ved annen institusjon", "planlagtEtterbehandling")):
      //api.showField(FORMID_OPPFØLGNING_TILTAK_PLANLAGT)
      api.showField(FORMID_OPPFØLGNING_TILTAK_PLANLAGT_GENERIC); //api.hideField(FORMID_OPPFØLGNING_TILTAK_PLANLAGT_INGEN_BEHANDLING_ÅRSAK)

      api.hideField(FORMID_OPPFØLGNING_TILTAK_PLANLAGT_INGEN_BEHANDLING_ÅRSAK_GENERIC);
      api.clearField(FORMID_OPPFØLGNING_TILTAK_PLANLAGT_INGEN_BEHANDLING_ÅRSAK);
      validatePlanedFollowUpTreatment(api, true);
      validatePlanedFollowUpTreatmentNone(api, false);
      break;

    case SelectedFollowUpLocation && GlobalFunctions_1.searchForValue(SelectedFollowUpLocation, "Ingen videre behandling", "planlagtEtterbehandling"):
      //api.showField(FORMID_OPPFØLGNING_TILTAK_PLANLAGT_INGEN_BEHANDLING_ÅRSAK)
      api.showField(FORMID_OPPFØLGNING_TILTAK_PLANLAGT_INGEN_BEHANDLING_ÅRSAK_GENERIC); //api.hideField(FORMID_OPPFØLGNING_TILTAK_PLANLAGT)

      api.hideField(FORMID_OPPFØLGNING_TILTAK_PLANLAGT_GENERIC);
      api.clearField(FORMID_OPPFØLGNING_TILTAK_PLANLAGT);
      validatePlanedFollowUpTreatment(api, false);
      validatePlanedFollowUpTreatmentNone(api, true);
      break;

    default:
      GlobalFunctions_1.HideAndClear([//FORMID_OPPFØLGNING_TILTAK_PLANLAGT_INGEN_BEHANDLING_ÅRSAK,
      //FORMID_OPPFØLGNING_TILTAK_PLANLAGT,
      FORMID_OPPFØLGNING_TILTAK_PLANLAGT_GENERIC, FORMID_OPPFØLGNING_TILTAK_PLANLAGT_INGEN_BEHANDLING_ÅRSAK_GENERIC], api);
      api.clearField(FORMID_OPPFØLGNING_TILTAK_PLANLAGT);
      api.clearField(FORMID_OPPFØLGNING_TILTAK_PLANLAGT_INGEN_BEHANDLING_ÅRSAK);
      validatePlanedFollowUpTreatment(api, false);
      validatePlanedFollowUpTreatmentNone(api, false);
      break;
  }
}

exports.planlagtEtterbehandling = planlagtEtterbehandling;

function validatePlanedFollowUpTreatment(api, thisValueShoudlBeTrue) {
  var SelectedFollowUpLocation = api.getFieldValue(FORMID_OPPFØLGNING_TILTAK);
  var SelectedFollowUpTreatment = api.getFields(FORMID_OPPFØLGNING_TILTAK_PLANLAGT);

  switch (true) {
    case SelectedFollowUpLocation && thisValueShoudlBeTrue && SelectedFollowUpTreatment.toString() == "":
      api.setOccurrences(FORMID_OPPFØLGNING_TILTAK_PLANLAGT, "1..5");
      break;

    case SelectedFollowUpLocation && thisValueShoudlBeTrue && SelectedFollowUpTreatment && GlobalFunctions_1.searchForValue(SelectedFollowUpTreatment, "Ikke avklart", "validatePlanedFollowUpTreatment") && GlobalFunctions_1.countCertainElementsInArray(SelectedFollowUpTreatment) > 1:
      api.setOccurrences(FORMID_OPPFØLGNING_TILTAK_PLANLAGT, "1..1"); //api.setErrorMessage(FORMID_OPPFØLGNING_TILTAK_PLANLAGT,"Det er ikke tilatt og velge andre verdier når du har valgt ikke avklart")

      break;

    case SelectedFollowUpLocation && thisValueShoudlBeTrue && SelectedFollowUpTreatment && GlobalFunctions_1.searchForValue(SelectedFollowUpTreatment, "Ikke avklart", "validatePlanedFollowUpTreatment"):
      api.setOccurrences(FORMID_OPPFØLGNING_TILTAK_PLANLAGT, "1..1"); //api.resetErrorMessage(FORMID_OPPFØLGNING_TILTAK_PLANLAGT)

      break;

    default:
      api.setOccurrences(FORMID_OPPFØLGNING_TILTAK_PLANLAGT, "0..5"); //api.resetErrorMessage(FORMID_OPPFØLGNING_TILTAK_PLANLAGT)

      break;
  }
}

function validatePlanedFollowUpTreatmentNone(api, thisValueShoudlBeTrue) {
  var SelectedFollowUpLocation = api.getFieldValue(FORMID_OPPFØLGNING_TILTAK);
  var causeForNoPlannedfollowupTreatment = api.getFields(FORMID_OPPFØLGNING_TILTAK_PLANLAGT_INGEN_BEHANDLING_ÅRSAK);

  switch (true) {
    case SelectedFollowUpLocation && thisValueShoudlBeTrue && causeForNoPlannedfollowupTreatment.toString() == "":
      api.setOccurrences(FORMID_OPPFØLGNING_TILTAK_PLANLAGT_INGEN_BEHANDLING_ÅRSAK, "1..4");
      api.hideField(FORMID_OPPFØLGNING_TILTAK_PLANLAGT_INGEN_BEHANDLING_ÅRSAK_SPESIFISERT);
      break;

    case SelectedFollowUpLocation && thisValueShoudlBeTrue && causeForNoPlannedfollowupTreatment && GlobalFunctions_1.searchForValue(causeForNoPlannedfollowupTreatment, "Ukjent", "validatePlanedFollowUpTreatmentNone") && GlobalFunctions_1.countCertainElementsInArray(causeForNoPlannedfollowupTreatment) > 1:
      api.setOccurrences(FORMID_OPPFØLGNING_TILTAK_PLANLAGT_INGEN_BEHANDLING_ÅRSAK, "1..1"); //api.setErrorMessage(FORMID_OPPFØLGNING_TILTAK_PLANLAGT_INGEN_BEHANDLING_ÅRSAK,"Det er ikke tilatt og velge andre verdier når du har valgt Ukjent")

      api.hideField(FORMID_OPPFØLGNING_TILTAK_PLANLAGT_INGEN_BEHANDLING_ÅRSAK_SPESIFISERT);
      break;

    case SelectedFollowUpLocation && thisValueShoudlBeTrue && causeForNoPlannedfollowupTreatment && GlobalFunctions_1.searchForValue(causeForNoPlannedfollowupTreatment, "Annet", "validatePlanedFollowUpTreatmentNone"):
      api.setOccurrences(FORMID_OPPFØLGNING_TILTAK_PLANLAGT_INGEN_BEHANDLING_ÅRSAK, "1..1"); //api.resetErrorMessage(FORMID_OPPFØLGNING_TILTAK_PLANLAGT_INGEN_BEHANDLING_ÅRSAK)

      api.showField(FORMID_OPPFØLGNING_TILTAK_PLANLAGT_INGEN_BEHANDLING_ÅRSAK_SPESIFISERT);
      break;

    default:
      api.setOccurrences(FORMID_OPPFØLGNING_TILTAK_PLANLAGT_INGEN_BEHANDLING_ÅRSAK, "0..4"); //api.resetErrorMessage(FORMID_OPPFØLGNING_TILTAK_PLANLAGT_INGEN_BEHANDLING_ÅRSAK)

      api.hideField(FORMID_OPPFØLGNING_TILTAK_PLANLAGT_INGEN_BEHANDLING_ÅRSAK_SPESIFISERT);
      break;
  }
}
},{"./GlobalFunctions":3}],7:[function(require,module,exports){
"use strict";

exports.__esModule = true;

var GlobalFunctions_1 = require("./GlobalFunctions");

var FORMID_LABORATORIUM = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/patologilaboratorium/laboratorium";
var FORMID_IKKE_RELEVANT = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/patologilaboratorium/ikke_relevant";
var FORMID_SPSIFISER = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/patologilaboratorium/spesifiser";
var FORMID_PREPARATNUMMER = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/patologilaboratorium/preparatnummer";

function validateNonRelevant(api) {
  var nonRelevant = api.getFieldValue(FORMID_IKKE_RELEVANT);

  if (GlobalFunctions_1.ArenaVersionValueCheck(nonRelevant) && nonRelevant.value == true) {
    api.hideField(FORMID_LABORATORIUM);
    api.setOccurrences(FORMID_LABORATORIUM, "0..1");
    api.clearField(FORMID_LABORATORIUM);
  } else {
    api.showField(FORMID_LABORATORIUM);
    api.setOccurrences(FORMID_LABORATORIUM, "1..1");
  }
}

exports.validateNonRelevant = validateNonRelevant;

function validateSpesified(api) {
  var lab = api.getFieldValue(FORMID_LABORATORIUM);

  if (GlobalFunctions_1.ArenaVersionValueCheck(lab) && lab.value == "Annet") {
    api.showField(FORMID_SPSIFISER);
  } else {
    api.hideField(FORMID_SPSIFISER);
    api.clearField(FORMID_SPSIFISER);
  }
}

exports.validateSpesified = validateSpesified;

function validatePrepNumber(api) {
  var lab = api.getFieldValue(FORMID_LABORATORIUM);

  if (GlobalFunctions_1.ArenaVersionValueCheck(lab)) {
    api.showField(FORMID_PREPARATNUMMER);
  } else {
    api.hideField(FORMID_PREPARATNUMMER);
    api.clearField(FORMID_PREPARATNUMMER);
  }
}

exports.validatePrepNumber = validatePrepNumber;
},{"./GlobalFunctions":3}],8:[function(require,module,exports){
"use strict";

exports.__esModule = true;

var GlobalFunctions_1 = require("./GlobalFunctions");

var BEHANDLINGEN_VAR_RETTET_MOT = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/behandlingen_var_rettet_mot";
var FORMID_LOKAL_RESIDIV_OPERASJONSDATO = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_lokalt_residiv/operasjonsdato_(dd.mm.åååå)";
var FORMID_LOKAL_RESIDIV_TYPE_INNGREP = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_lokalt_residiv/inngrep_lokalt_residiv";
var FORMID_LOKAL_RESIDIV_RESTUMOR_LOKALT = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_lokalt_residiv/resttumor_lokalt_(kirurgens_vurdering)";
var FORMID_LOKAL_RESIDIV_ER_DET_UTFØRT_INNGREP_MOT_METASTASE = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_lokalt_residiv/er_det_i_samme_operasjon_gjort_inngrep_mot_metastase(r)";
var FORMID_LOKAL_RESIDIV_CLUSTER = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_lokalt_residiv";

function BehandliungRettetMotLokalResidiv(api) {
  var BehandlingRettetMot1 = api.getFieldValue(BEHANDLINGEN_VAR_RETTET_MOT);
  console.log("Kjører funksjon for BehandliungRettetMotLokalResidiv");

  if (GlobalFunctions_1.ArenaVersionValueCheck(BehandlingRettetMot1) && BehandlingRettetMot1.value == "Lokalt residiv (med eller uten metastase(r))") {
    //Kirurgi av lokalt residiv
    console.log("Bruker har valgt Lokalt residiv (med eller uten metastase(r))");
    api.showField(FORMID_LOKAL_RESIDIV_CLUSTER);
    api.showField(FORMID_LOKAL_RESIDIV_OPERASJONSDATO);
    api.showField(FORMID_LOKAL_RESIDIV_TYPE_INNGREP);
    api.showField(FORMID_LOKAL_RESIDIV_RESTUMOR_LOKALT);
    api.showField(FORMID_LOKAL_RESIDIV_ER_DET_UTFØRT_INNGREP_MOT_METASTASE);
    checkAndSetOccurrencyLocalResidive(true, api);
  } else {
    GlobalFunctions_1.HideAndClear([FORMID_LOKAL_RESIDIV_CLUSTER, FORMID_LOKAL_RESIDIV_OPERASJONSDATO, FORMID_LOKAL_RESIDIV_TYPE_INNGREP, FORMID_LOKAL_RESIDIV_RESTUMOR_LOKALT, FORMID_LOKAL_RESIDIV_ER_DET_UTFØRT_INNGREP_MOT_METASTASE], api);
    checkAndSetOccurrencyLocalResidive(false, api);
  }
}

exports.BehandliungRettetMotLokalResidiv = BehandliungRettetMotLokalResidiv; //validation

function ValidateSurgeryLocalResidiv(api) {
  console.log("Kjører funksjon for ValidateSurgeryLocalResidiv");
  var otherLocation = api.getFields(FORMID_LOKAL_RESIDIV_TYPE_INNGREP);

  if (GlobalFunctions_1.searchForValue(otherLocation, "Annet", "ValidateSurgeryLocalResidiv")) {
    console.log("Bruker har valgt Lokalt residiv lokalisasjon for inngrep Annet)");
    api.showField("kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_lokalt_residiv/spesifiser_inngrep");
  } else {
    api.hideField("kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/kirurgi_av_lokalt_residiv/spesifiser_inngrep");
  }
}

exports.ValidateSurgeryLocalResidiv = ValidateSurgeryLocalResidiv;

function checkAndSetOccurrencyLocalResidive(thisValueShoudlBeTrue, api) {
  console.log("Kjører funksjon for checkAndSetOccurrencyLocalResidive");

  if (thisValueShoudlBeTrue) {
    api.setOccurrences(FORMID_LOKAL_RESIDIV_OPERASJONSDATO, "1..1");
    api.setOccurrences(FORMID_LOKAL_RESIDIV_TYPE_INNGREP, "1..1");
    api.setOccurrences(FORMID_LOKAL_RESIDIV_RESTUMOR_LOKALT, "1..1");
    api.setOccurrences(FORMID_LOKAL_RESIDIV_ER_DET_UTFØRT_INNGREP_MOT_METASTASE, "1..1");
  } else {
    api.setOccurrences(FORMID_LOKAL_RESIDIV_OPERASJONSDATO, "0..1");
    api.setOccurrences(FORMID_LOKAL_RESIDIV_TYPE_INNGREP, "0..1");
    api.setOccurrences(FORMID_LOKAL_RESIDIV_RESTUMOR_LOKALT, "0..1");
    api.setOccurrences(FORMID_LOKAL_RESIDIV_ER_DET_UTFØRT_INNGREP_MOT_METASTASE, "0..1");
  }
}

exports.checkAndSetOccurrencyLocalResidive = checkAndSetOccurrencyLocalResidive;
},{"./GlobalFunctions":3}],9:[function(require,module,exports){
"use strict";

exports.__esModule = true;

var GlobalFunctions_1 = require("./GlobalFunctions"); // DENNE METODEN VISER FELTER BASERT PÅ VALGT AV LOKALISASJON - må ha kal på denne både på lokalisasjon og på funn i utredning 


var FUNN_I_UTREDNING = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/behandlingen_var_rettet_mot";
var LOKALISASJON = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/lokalisasjon_av_primaertumor/lokalisajon";
var SPESIFISER_LOKALISASJON_COLON = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/lokalisasjon_av_primaertumor/spesifiser_lokalisajon_colon";
var AVSTAND_1 = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/lokalisasjon_av_primaertumor/angir_avstand_fra_analåpning_til_nedre_kant_av_tumor_(målt_på_stivt_skop)";
var UKJENT_1 = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/lokalisasjon_av_primaertumor/ukjent";
var AVSTAND_2 = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/lokalisasjon_av_primaertumor/avstand_fra_øvre_kant_av_m.puborektalis_til_nedre_kant_av_tumor_(målt_ved_mr)";
var UKJENT_2 = "kreftmelding_kolorektalkreft_dips/kolorektal_kreftmelding_for_kirurgi/any_event/lokalisasjon_av_primaertumor/ukjent2";
var TUMOR_COLON = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/tumor_(t-sykdom)/tumor_colon";
var TUMOR_RECTUM = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/tumor_(t-sykdom)/tumor_rectum";
var TUMOR_COLON_FIELDSET = "generic-field-82684";
var TUMOR_RECTUM_FIELDSET = "generic-field-95784";

function tumorLocalisation(api) {
  var funnIutredning = api.getFieldValue(FUNN_I_UTREDNING);
  var localisation = api.getFieldValue(LOKALISASJON);
  console.log("tumor Lokalisasjon function runs");

  if (GlobalFunctions_1.ArenaVersionNullCheckValue(funnIutredning)) {
    console.log("ingen funn");
    GlobalFunctions_1.HideAndClear([TUMOR_COLON, TUMOR_RECTUM, AVSTAND_1, UKJENT_1, AVSTAND_2, UKJENT_2, SPESIFISER_LOKALISASJON_COLON, LOKALISASJON], api, "0..1");
  }

  if (GlobalFunctions_1.ArenaVersionValueCheck(funnIutredning)) {
    if (funnIutredning.Value == "Primærtumor (med eller uten metastase(r))") {
      console.log("primartumor er valgt , under ser du verdien av lkoalisasjon");
      console.log(localisation);

      if (GlobalFunctions_1.ArenaVersionNullCheckValue(localisation)) {
        console.log("Lokalisasjon ikke valgt");
        GlobalFunctions_1.HideAndClear([TUMOR_COLON, TUMOR_RECTUM, AVSTAND_1, UKJENT_1, AVSTAND_2, UKJENT_2, SPESIFISER_LOKALISASJON_COLON], api, "0..1");
      }

      if (GlobalFunctions_1.ArenaVersionValueCheck(localisation)) {
        console.log("kommer du hit?");

        if (localisation.Value == "Colon (C18-C19)") {
          console.log("C18-19 valgt");
          api.showField(SPESIFISER_LOKALISASJON_COLON);
          api.setOccurrences(SPESIFISER_LOKALISASJON_COLON, "1..1");
          api.showField(TUMOR_COLON_FIELDSET);
          api.showField(TUMOR_COLON);
          api.setOccurrences(TUMOR_COLON, "1..-1");
          GlobalFunctions_1.HideAndClear([TUMOR_RECTUM_FIELDSET, UKJENT_2], api, "0..1");
          GlobalFunctions_1.HideAndClear([TUMOR_RECTUM, AVSTAND_2], api, "0..1");
        }

        if (localisation.Value == "Rectum (C20)") {
          console.log("C20 valgt");
          GlobalFunctions_1.HideAndClear([TUMOR_COLON_FIELDSET, TUMOR_COLON, AVSTAND_1, UKJENT_1, SPESIFISER_LOKALISASJON_COLON], api, "0..1");
          api.setOccurrences(SPESIFISER_LOKALISASJON_COLON, "0..1");
          api.showField(TUMOR_RECTUM_FIELDSET);
          api.showField(UKJENT_2);
          api.setOccurrences(TUMOR_RECTUM, "1..99");
          GlobalFunctions_1.ShowAndSetOccurence([AVSTAND_1, AVSTAND_2], api, "1..1");
        }
      }
    }

    if (funnIutredning && (funnIutredning.Value == "Lokal residiv (med eller uten metastase(r))" || funnIutredning.Value == "Kun metastase(r)")) {
      console.log("lokal residiv eller metastaser er valgt");
      api.hideField("generic-field-71553");

      if (localisation && localisation.Value == "Colon (C18-C19)") {
        api.showField(SPESIFISER_LOKALISASJON_COLON);
        api.setOccurrences(SPESIFISER_LOKALISASJON_COLON, "1..1");
      }

      if (localisation && localisation.Value == "Rectum (C20)") {
        GlobalFunctions_1.HideAndClear([SPESIFISER_LOKALISASJON_COLON], api, "0..1");
      }
    }
  }
}

exports.tumorLocalisation = tumorLocalisation; // DENNE METODEN DISABLER OG SETTER FOREKOMST TIL 0..1 dersom ukjent er valgt 

function enableAvstand(api) {
  var UKJENT_1_STATUS = api.getFieldValue(UKJENT_1);
  var UKJENT_2_STATUS = api.getFieldValue(UKJENT_2);

  if (GlobalFunctions_1.ArenaVersionValueCheck(UKJENT_1_STATUS)) {
    api.disableField(AVSTAND_1);
    api.setOccurrences(AVSTAND_1, "0..1");
  }

  if (GlobalFunctions_1.ArenaVersionNullCheckValue(UKJENT_1_STATUS)) {
    api.enableField(AVSTAND_1);
    api.setOccurrences(AVSTAND_1, "1..1");
  }

  if (GlobalFunctions_1.ArenaVersionValueCheck(UKJENT_2_STATUS)) {
    api.disableField(AVSTAND_2);
    api.setOccurrences(AVSTAND_2, "0..1");
  }

  if (GlobalFunctions_1.ArenaVersionNullCheckValue(UKJENT_2_STATUS)) {
    api.enableField(AVSTAND_2);
    api.setOccurrences(AVSTAND_2, "1..1");
  }
}

exports.enableAvstand = enableAvstand;
},{"./GlobalFunctions":3}]},{},[1])