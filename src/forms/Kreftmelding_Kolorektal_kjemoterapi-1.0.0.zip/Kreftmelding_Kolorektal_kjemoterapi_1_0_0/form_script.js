(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
"use strict";

exports.__esModule = true;

var ChemoTherapyTreatmentDirectedTowards_1 = require("./rules/ChemoTherapyTreatmentDirectedTowards");

var tumorLocalisation_1 = require("./rules/tumorLocalisation"); // Kreftregisteret_Kolorektalskjema_kjemoterapi


var BEHANDLING_FOR2 = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_kjemoterapi_dips/any_event/behandling_for/behandling_for";
var LOKALISASJON_AV_METASTASER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_kjemoterapi_dips/any_event/behandling_for/lokalisasjon_av_metastaser";
var CEA = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_kjemoterapi_dips/any_event/kjemoterapi/cea/cea";
var HENSIKTEN_MED_BEHANDLINGSPLANEN = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_kjemoterapi_dips/any_event/kjemoterapi/hensikten_med_behandlingsplanen";
var LINJE = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_kjemoterapi_dips/any_event/kjemoterapi/linje";
var MEDIKAMENTER2 = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_kjemoterapi_dips/any_event/kjemoterapi/medikamenter/medikamenter";
var UKJENT_CEA = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_kjemoterapi_dips/any_event/kjemoterapi/cea/ikke_tatt";
var ÅRSAK_TIL_SKIFTE_AV_BEHANDLING = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_kjemoterapi_dips/any_event/kjemoterapi/årsak_til_skifte_av_behandling";
var ÅRSAKER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_kjemoterapi_dips/any_event/kjemoterapi/årsak_til_skifte_av_behandling/årsaker";
var LOKALISASJON = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_kjemoterapi_dips/any_event/lokalisasjon_av_primaertumor/lokalisajon";
var UKJENT_1 = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_kjemoterapi_dips/any_event/lokalisasjon_av_primaertumor/ukjent";
var UKJENT_2 = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_kjemoterapi_dips/any_event/lokalisasjon_av_primaertumor/ukjent2";

function main(api) {
  ChemoTherapyTreatmentDirectedTowards_1.behandlingRettetMot3(api);
  ChemoTherapyTreatmentDirectedTowards_1.behandlingRettetMotBlank(api);
  ChemoTherapyTreatmentDirectedTowards_1.behandlingRettetMot3eller4(api);
  ChemoTherapyTreatmentDirectedTowards_1.linjeKjemo2or3or4(api);
  tumorLocalisation_1.tumorLocalisation(api);
  ChemoTherapyTreatmentDirectedTowards_1.validateMedicationOther(api);
  ChemoTherapyTreatmentDirectedTowards_1.validateReasonForChangeOftreatmentOther(api);
  api.addListener(BEHANDLING_FOR2, "OnChanged", function () {
    ChemoTherapyTreatmentDirectedTowards_1.behandlingRettetMot3(api);
    tumorLocalisation_1.tumorLocalisation(api);
  });
  api.addListener(LOKALISASJON_AV_METASTASER, "OnChanged", function () {
    ChemoTherapyTreatmentDirectedTowards_1.validateLocalisationOther(api);
  });
  api.addListener(LOKALISASJON_AV_METASTASER, "OnChildAdded", function () {
    ChemoTherapyTreatmentDirectedTowards_1.validateLocalisationOther(api);
  });
  api.addListener(LOKALISASJON_AV_METASTASER, "OnChildRemoved", function () {
    ChemoTherapyTreatmentDirectedTowards_1.validateLocalisationOther(api);
  });
  api.addListener(HENSIKTEN_MED_BEHANDLINGSPLANEN, "OnChanged", function () {
    ChemoTherapyTreatmentDirectedTowards_1.behandlingRettetMot3eller4(api);
    ChemoTherapyTreatmentDirectedTowards_1.behandlingRettetMotBlank(api);
  });
  api.addListener(UKJENT_CEA, "OnChanged", function () {
    ChemoTherapyTreatmentDirectedTowards_1.validateCEA(api);
  });
  api.addListener(CEA, "OnChanged", function () {
    ChemoTherapyTreatmentDirectedTowards_1.validateCEA(api);
  });
  api.addListener(LINJE, "OnChanged", function () {
    ChemoTherapyTreatmentDirectedTowards_1.linjeKjemo2or3or4(api);
  });
  api.addListener(ÅRSAK_TIL_SKIFTE_AV_BEHANDLING, "OnChanged", function () {
    ChemoTherapyTreatmentDirectedTowards_1.validateReasonForChangeOftreatmentOther(api);
  });
  api.addListener(MEDIKAMENTER2, "OnChanged", function () {
    ChemoTherapyTreatmentDirectedTowards_1.validateMedicationOther(api);
  });
  api.addListener(MEDIKAMENTER2, "OnChildAdded", function () {
    ChemoTherapyTreatmentDirectedTowards_1.validateMedicationOther(api);
  });
  api.addListener(MEDIKAMENTER2, "OnChildRemoved", function () {
    ChemoTherapyTreatmentDirectedTowards_1.validateMedicationOther(api);
  });
  api.addListener(LOKALISASJON, "OnChanged", function () {
    tumorLocalisation_1.tumorLocalisation(api);
  });
  api.addListener(UKJENT_1, "OnChanged", function () {
    tumorLocalisation_1.enableAvstand(api);
  });
  api.addListener(UKJENT_2, "OnChanged", function () {
    tumorLocalisation_1.enableAvstand(api);
  });
  api.addListener(ÅRSAKER, "OnChanged", function () {
    ChemoTherapyTreatmentDirectedTowards_1.validateReasonForChangeOftreatmentOther(api);
  });
  api.addListener(ÅRSAKER, "OnChildAdded", function () {
    ChemoTherapyTreatmentDirectedTowards_1.validateReasonForChangeOftreatmentOther(api);
  });
  api.addListener(ÅRSAKER, "OnChildRemoved", function () {
    ChemoTherapyTreatmentDirectedTowards_1.validateReasonForChangeOftreatmentOther(api);
  });
}main(api);
},{"./rules/ChemoTherapyTreatmentDirectedTowards":2,"./rules/tumorLocalisation":4}],2:[function(require,module,exports){
"use strict";

exports.__esModule = true;

var GlobalFunctions_1 = require("./GlobalFunctions");

var BEHANDLING_FOR2 = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_kjemoterapi_dips/any_event/behandling_for/behandling_for";
var LOKALISASJON_AV_METASTASER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_kjemoterapi_dips/any_event/behandling_for/lokalisasjon_av_metastaser";
var LOKALISASJON_AV_METASTASER_FIELDSET = "generic-field-54103";
var SPESIFISER_LOKALISASJON = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_kjemoterapi_dips/any_event/behandling_for/spesifiser_lokalisasjon";
var CEA = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_kjemoterapi_dips/any_event/kjemoterapi/cea/cea";
var FUNKSJONSSTATUS_ECOG = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_kjemoterapi_dips/any_event/kjemoterapi/ecog_funksjonsstatus/ecog_funksjonsstatus";
var HENSIKTEN_MED_BEHANDLINGSPLANEN = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_kjemoterapi_dips/any_event/kjemoterapi/hensikten_med_behandlingsplanen";
var LINJE = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_kjemoterapi_dips/any_event/kjemoterapi/linje";
var MEDIKAMENTER2 = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_kjemoterapi_dips/any_event/kjemoterapi/medikamenter/medikamenter";
var SPESIFISER_MEDIKAMENT = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_kjemoterapi_dips/any_event/kjemoterapi/medikamenter/spesifiser_medikament";
var STARTDATO_FOR_BEHANDLINGEN_DD_MM_ÅÅÅÅ = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_kjemoterapi_dips/any_event/kjemoterapi/startdato_for_behandlingen(dd.mm.åååå)";
var UKJENT_CEA = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_kjemoterapi_dips/any_event/kjemoterapi/cea/ikke_tatt";
var ÅRSAK_TIL_SKIFTE_AV_BEHANDLING = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_kjemoterapi_dips/any_event/kjemoterapi/årsak_til_skifte_av_behandling";
var SPESIFISER_ÅRSAK = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_kjemoterapi_dips/any_event/kjemoterapi/årsak_til_skifte_av_behandling/spesifiser_årsak";
var ÅRSAKER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_kjemoterapi_dips/any_event/kjemoterapi/årsak_til_skifte_av_behandling/årsaker";
var FORMID_MEDIKAMETER_FIELDSET = "generic-field-00982";
var FORMID_LOKALISASJON_AV_METASTASE = "generic-field-54103";
var FORMID_LOKALISASJON_AV_PRIMÆRTUMOR_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_kjemoterapi_dips/any_event/lokalisasjon_av_primaertumor";

function behandlingRettetMot3(api) {
  console.log("behandlingRettetMot3 running");
  var treatementDirectedTowards = api.getFieldValue(BEHANDLING_FOR2);

  if (GlobalFunctions_1.ArenaVersionValueCheck(treatementDirectedTowards) && (treatementDirectedTowards.Value == "Primærsykdom - avansert sykdom (fjernspredning)" || treatementDirectedTowards.Value == "Tilbakefall - avansert sykdom (fjernspredning)")) {
    console.log("Treatment directed Towards is " + treatementDirectedTowards.Value); //api.showField(LOKALISASJON_AV_METASTASER)

    api.showField(LOKALISASJON_AV_METASTASER_FIELDSET);
    api.setOccurrences(LOKALISASJON_AV_METASTASER, "1..99");
    api.showField(FORMID_LOKALISASJON_AV_METASTASE);
  } else {
    //api.hideField(LOKALISASJON_AV_METASTASER)
    api.hideField(LOKALISASJON_AV_METASTASER_FIELDSET);
    api.clearField(LOKALISASJON_AV_METASTASER);
    api.setOccurrences(LOKALISASJON_AV_METASTASER, "0..99");
    api.hideField(FORMID_LOKALISASJON_AV_METASTASE);
  }

  if (GlobalFunctions_1.ArenaVersionValueCheck(treatementDirectedTowards)) {
    api.showField(FORMID_LOKALISASJON_AV_PRIMÆRTUMOR_CLUSTER);
  } else {
    api.hideField(FORMID_LOKALISASJON_AV_PRIMÆRTUMOR_CLUSTER);
  }

  validateLocalisationOther(api);
}

exports.behandlingRettetMot3 = behandlingRettetMot3;

function validateLocalisationOther(api) {
  var localisation = api.getFields(LOKALISASJON_AV_METASTASER);
  console.log("validateLocalisationOther running");

  if (GlobalFunctions_1.searchForValue(localisation, "Annet")) {
    api.showField(SPESIFISER_LOKALISASJON);
  } else {
    api.hideField(SPESIFISER_LOKALISASJON), api.clearField(SPESIFISER_LOKALISASJON);
  }
}

exports.validateLocalisationOther = validateLocalisationOther;

function behandlingRettetMotBlank(api) {
  console.log("behandlingRettetMotBlank running");
  var aimOfTreatmentPlan = api.getFieldValue(HENSIKTEN_MED_BEHANDLINGSPLANEN);

  if (GlobalFunctions_1.ArenaVersionValueCheck(aimOfTreatmentPlan)) {
    console.log("Aim for the treatment plan has been selected");
    api.showField(FUNKSJONSSTATUS_ECOG);
    api.showField(STARTDATO_FOR_BEHANDLINGEN_DD_MM_ÅÅÅÅ); //api.showField(MEDIKAMENTER2)

    api.setOccurrences(FUNKSJONSSTATUS_ECOG, "1..1");
    api.setOccurrences(STARTDATO_FOR_BEHANDLINGEN_DD_MM_ÅÅÅÅ, "1..1");
    api.setOccurrences(MEDIKAMENTER2, "1..99");
    api.showField(FORMID_MEDIKAMETER_FIELDSET);
  } else {
    console.log("Aim for the treatment plan has not been selected");
    api.hideField(FUNKSJONSSTATUS_ECOG);
    api.hideField(STARTDATO_FOR_BEHANDLINGEN_DD_MM_ÅÅÅÅ); //api.hideField(MEDIKAMENTER2) 

    api.setOccurrences(FUNKSJONSSTATUS_ECOG, "0..1");
    api.setOccurrences(STARTDATO_FOR_BEHANDLINGEN_DD_MM_ÅÅÅÅ, "0..1");
    api.setOccurrences(MEDIKAMENTER2, "0..99");
    api.hideField(FORMID_MEDIKAMETER_FIELDSET);
  }
}

exports.behandlingRettetMotBlank = behandlingRettetMotBlank;

function behandlingRettetMot3eller4(api) {
  console.log("behandlingRettetMot3eller4 running");
  var aimOfTreatmentPlan = api.getFieldValue(HENSIKTEN_MED_BEHANDLINGSPLANEN);

  if (GlobalFunctions_1.ArenaVersionValueCheck(aimOfTreatmentPlan) && aimOfTreatmentPlan.Value == "Livsforlengende og lindrende behandling") {
    console.log("Aim for the treatment plan is " + aimOfTreatmentPlan.Value);
    api.showField(LINJE);
    api.setOccurrences(LINJE, "1..1");
  } else {
    api.hideField(LINJE);
    api.setOccurrences(LINJE, "0..1");
  }

  if (GlobalFunctions_1.ArenaVersionValueCheck(aimOfTreatmentPlan) && (aimOfTreatmentPlan.Value == "Livsforlengende og lindrende behandling" || aimOfTreatmentPlan.Value == "Kjemoterapi før planlagt kirurgi")) {
    console.log("Aim for the treatment plan is " + aimOfTreatmentPlan.Value);
    api.showField(CEA);
    api.showField(UKJENT_CEA);
    CheckAndSetOccurenceCEA(api, true, "behandlingRettetMot3eller4");
  } else {
    api.hideField(CEA);
    api.hideField(UKJENT_CEA);
    CheckAndSetOccurenceCEA(api, false, "behandlingRettetMot3eller4");
  }
}

exports.behandlingRettetMot3eller4 = behandlingRettetMot3eller4;

function linjeKjemo2or3or4(api) {
  console.log("linjeKjemo2or3or4 running");
  var lineOfChemoTherapy = api.getFieldValue(LINJE);

  if (GlobalFunctions_1.ArenaVersionValueCheck(lineOfChemoTherapy) && (lineOfChemoTherapy.Value == "2.linje palliativ behandling" || lineOfChemoTherapy.Value == "3.linje palliativ behandling" || lineOfChemoTherapy.Value == "Seinere palliativ linje")) {
    console.log("Chemotherapy line is " + lineOfChemoTherapy.Value);
    api.showField(ÅRSAK_TIL_SKIFTE_AV_BEHANDLING);
    api.setOccurrences(ÅRSAK_TIL_SKIFTE_AV_BEHANDLING, "1..1");
    api.setOccurrences(ÅRSAKER, "1..5");
  } else {
    api.hideField(ÅRSAK_TIL_SKIFTE_AV_BEHANDLING);
    api.clearField(ÅRSAK_TIL_SKIFTE_AV_BEHANDLING);
    api.setOccurrences(ÅRSAK_TIL_SKIFTE_AV_BEHANDLING, "0..1");
    api.setOccurrences(ÅRSAKER, "0..5");
  }
}

exports.linjeKjemo2or3or4 = linjeKjemo2or3or4;

function validateCEA(api) {
  console.log("validateCEA running");
  var unknownCEA = api.getFieldValue(UKJENT_CEA);

  if (GlobalFunctions_1.ArenaVersionValueCheck(unknownCEA) && unknownCEA.value == true) {
    api.hideField(CEA);
    api.clearField(CEA);
    CheckAndSetOccurenceCEA(api, true, "validateCEA");
  } else {
    api.showField(CEA);
    CheckAndSetOccurenceCEA(api, true, "validateCEA");
  }
}

exports.validateCEA = validateCEA;

function validateReasonForChangeOftreatmentOther(api) {
  console.log("validateReasonForChangeOftreatmentOther running");
  var reasonForchange = api.getFields(ÅRSAKER);

  if (GlobalFunctions_1.searchForValue(reasonForchange, "Annet")) {
    api.showField(SPESIFISER_ÅRSAK);
  } else {
    api.hideField(SPESIFISER_ÅRSAK);
    api.clearField(SPESIFISER_ÅRSAK);
  }
}

exports.validateReasonForChangeOftreatmentOther = validateReasonForChangeOftreatmentOther;

function validateMedicationOther(api) {
  console.log("validateMedicationOther runnining");
  var medicationSelected = api.getFields(MEDIKAMENTER2);

  if (GlobalFunctions_1.searchForValue(medicationSelected, "Annet")) {
    api.showField(SPESIFISER_MEDIKAMENT);
  } else {
    api.hideField(SPESIFISER_MEDIKAMENT);
    api.clearField(SPESIFISER_MEDIKAMENT);
  }
}

exports.validateMedicationOther = validateMedicationOther;

function CheckAndSetOccurenceCEA(api, thisValueShouldBeTrue, runningfrom) {
  console.log("CheckAndSetOccurenceCEA running " + runningfrom);
  var CEASelected = api.getFieldValue(CEA);
  var unknownCEA = api.getFieldValue(UKJENT_CEA);
  console.log(CEA);
  console.log(UKJENT_CEA);
  console.log(thisValueShouldBeTrue);
  console.log(GlobalFunctions_1.ArenaVersionNullCheckValue(CEASelected));
  console.log(GlobalFunctions_1.ArenaVersionNullCheckValue(unknownCEA));

  if (thisValueShouldBeTrue && GlobalFunctions_1.ArenaVersionNullCheckMagnitude(CEASelected) && GlobalFunctions_1.ArenaVersionNullCheckValue(unknownCEA)) {
    console.log("Should set occurence on CEA to 1..1");
    api.setOccurrences(CEA, "1..1");
    api.setOccurrences(UKJENT_CEA, "1..1");
  } else {
    api.setOccurrences(CEA, "0..1");
    api.setOccurrences(UKJENT_CEA, "0..1");
  }
}

exports.CheckAndSetOccurenceCEA = CheckAndSetOccurenceCEA;
},{"./GlobalFunctions":3}],3:[function(require,module,exports){
"use strict";

exports.__esModule = true;

// Kommentert ut av byggescript = require("ehrcraft-form-api");

function HideAndClear(params, api, occurence) {
  if (!occurence || occurence.Value == null) for (var i = 0; i < params.length; i++) {
    api.hideField(params[i]);
    api.clearField(params[i]);
  }
  if (occurence) for (var i = 0; i < params.length; i++) {
    api.hideField(params[i]);
    api.clearField(params[i]);
    api.setOccurrences(params[i], occurence);
  }
}

exports.HideAndClear = HideAndClear;

function ShowAndSetOccurence(params, api, occurence) {
  for (var i = 0; i < params.length; i++) {
    api.showField(params[i]);
    api.setOccurrences(params[i], occurence);
  }
}

exports.ShowAndSetOccurence = ShowAndSetOccurence;

function searchForValue(array, searchValue, functionThatCallsMe) {
  var arrayToSearch = array;

  function testFunction(element) {
    if (!element || element.Value == null) {
      return "ERROR" === searchValue;
    } else {
      return element.value === searchValue;
    }
  }

  var retval = arrayToSearch.some(testFunction);
  console.log("Searched for " + searchValue + "Returned value is : " + retval);
  return retval;
}

exports.searchForValue = searchForValue;

function CheckNullSwitch(value) {
  var returnValue = false;

  if (!value) {
    returnValue = false;
  } else {
    returnValue = true;
  }

  return returnValue;
}

exports.CheckNullSwitch = CheckNullSwitch;

function countCertainElementsInArray(array) {
  var count = array.map(function (x) {
    return x.value;
  }).length;
  console.log(count + "THIS MANY VALUES");
  return count;
}

exports.countCertainElementsInArray = countCertainElementsInArray;

function ArenaVersionValueCheck(value) {
  if (value && value.Value != null) {
    return true;
  } else {
    return false;
  }
}

exports.ArenaVersionValueCheck = ArenaVersionValueCheck;

function ArenaVersionMagnitudeCheck(value) {
  if (value && value.Magnitude != 0.0) {
    return true;
  } else {
    return false;
  }
}

exports.ArenaVersionMagnitudeCheck = ArenaVersionMagnitudeCheck;

function ArenaVersionNullCheckValue(value) {
  if (!value || value.Value == null || value.Value == false) {
    return true;
  } else {
    return false;
  }
}

exports.ArenaVersionNullCheckValue = ArenaVersionNullCheckValue;

function ArenaVersionNullCheckMagnitude(value) {
  if (!value || value.Magnitude == null || value.Magnitude == false) {
    return true;
  } else {
    return false;
  }
}

exports.ArenaVersionNullCheckMagnitude = ArenaVersionNullCheckMagnitude;

function BMICalculate(weight, height) {
  var BMIcalc = weight / (height / 100 * height / 100);
  var BMI = new DvQuantity();
  console.log(BMI);
  BMI.Magnitude = BMIcalc;
  BMI.Units = "kg/m3";
  console.log(BMI);
  return BMI;
}

exports.BMICalculate = BMICalculate;
},{}],4:[function(require,module,exports){
"use strict";

exports.__esModule = true;

var GlobalFunctions_1 = require("./GlobalFunctions"); // DENNE METODEN VISER FELTER BASERT PÅ VALGT AV LOKALISASJON - må ha kal på denne både på lokalisasjon og på funn i utredning 


var FUNN_I_UTREDNING = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_kjemoterapi_dips/any_event/behandling_for/behandling_for";
var LOKALISASJON = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_kjemoterapi_dips/any_event/lokalisasjon_av_primaertumor/lokalisajon";
var SPESIFISER_LOKALISASJON_COLON = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_kjemoterapi_dips/any_event/lokalisasjon_av_primaertumor/spesifiser_lokalisajon_colon";
var AVSTAND_1 = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_kjemoterapi_dips/any_event/lokalisasjon_av_primaertumor/angir_avstand_fra_analåpning_til_nedre_kant_av_tumor_(målt_på_stivt_skop)";
var UKJENT_1 = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_kjemoterapi_dips/any_event/lokalisasjon_av_primaertumor/ukjent";
var AVSTAND_2 = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_kjemoterapi_dips/any_event/lokalisasjon_av_primaertumor/avstand_fra_øvre_kant_av_m.puborektalis_til_nedre_kant_av_tumor_(målt_ved_mr)";
var UKJENT_2 = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_kjemoterapi_dips/any_event/lokalisasjon_av_primaertumor/ukjent2";
var TUMOR_COLON = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/tumor_(t-sykdom)/tumor_colon";
var TUMOR_RECTUM = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/tumor_(t-sykdom)/tumor_rectum";
var TUMOR_COLON_FIELDSET = "generic-field-28253";
var TUMOR_RECTUM_FIELDSET = "generic-field-53898";

function tumorLocalisation(api) {
  var localisation = api.getFieldValue(LOKALISASJON);
  var findings = api.getFieldValue(FUNN_I_UTREDNING);
  console.log("tumor Lokalisasjon function runs");

  if (!findings || findings.Value == null) {
    console.log("ingen funn");
    GlobalFunctions_1.HideAndClear([TUMOR_COLON, TUMOR_RECTUM, AVSTAND_1, UKJENT_1, AVSTAND_2, UKJENT_2, SPESIFISER_LOKALISASJON_COLON], api);
  }

  if (GlobalFunctions_1.ArenaVersionValueCheck(findings)) {
    if (findings.Value == "Primærsykdom - lokal/lokalavansert inkludert spredning til regionale lymfeknuter") {
      console.log("primartumor er valgt , under ser du verdien av lokalisasjon");
      console.log(localisation);

      if (!localisation || localisation.Value == null) {
        console.log("Lokalisasjon ikke valgt");
        GlobalFunctions_1.HideAndClear([TUMOR_COLON, TUMOR_RECTUM, AVSTAND_1, UKJENT_1, AVSTAND_2, UKJENT_2, SPESIFISER_LOKALISASJON_COLON], api);
      }

      if (GlobalFunctions_1.ArenaVersionValueCheck(localisation)) {
        console.log("kommer du hit?");

        if (localisation.Value == "Colon (C18-C19)") {
          console.log("C18-19 valgt");
          api.showField(SPESIFISER_LOKALISASJON_COLON);
          api.setOccurrences(SPESIFISER_LOKALISASJON_COLON, "1..1");
          api.showField(TUMOR_COLON_FIELDSET);
          api.showField(TUMOR_COLON);
          api.setOccurrences(TUMOR_COLON, "1..-1");
          GlobalFunctions_1.HideAndClear([TUMOR_RECTUM_FIELDSET, UKJENT_2], api);
          GlobalFunctions_1.HideAndClear([TUMOR_RECTUM, AVSTAND_2], api, "0..1");
        }

        if (localisation.Value == "Rectum (C20)") {
          console.log("C20 valgt");
          GlobalFunctions_1.HideAndClear([TUMOR_COLON_FIELDSET, TUMOR_COLON, AVSTAND_1, UKJENT_1, SPESIFISER_LOKALISASJON_COLON], api);
          api.setOccurrences(SPESIFISER_LOKALISASJON_COLON, "0..1");
          api.showField(TUMOR_RECTUM_FIELDSET);
          api.showField(UKJENT_2);
          api.setOccurrences(TUMOR_RECTUM, "1..-1");
          GlobalFunctions_1.ShowAndSetOccurence([AVSTAND_1, AVSTAND_2], api, "1..1");
        }
      }
    }

    if (findings.Value == "Primærsykdom - avansert sykdom (fjernspredning)") {
      console.log("lokal residiv eller metastaser er valgt");
      api.hideField("generic-field-71553");

      if (GlobalFunctions_1.ArenaVersionValueCheck(localisation) && localisation.Value == "Colon (C18-C19)") {
        api.showField(SPESIFISER_LOKALISASJON_COLON);
        api.setOccurrences(SPESIFISER_LOKALISASJON_COLON, "1..1");
      }

      if (GlobalFunctions_1.ArenaVersionValueCheck(localisation) && localisation.Value == "Rectum (C20)") {
        GlobalFunctions_1.HideAndClear([SPESIFISER_LOKALISASJON_COLON], api, "0..1");
      }
    }
  }
}

exports.tumorLocalisation = tumorLocalisation; // DENNE METODEN DISABLER OG SETTER FOREKOMST TIL 0..1 dersom ukjent er valgt 

function enableAvstand(api) {
  var UKJENT_1_STATUS = api.getFieldValue(UKJENT_1);
  var UKJENT_2_STATUS = api.getFieldValue(UKJENT_2);

  if (GlobalFunctions_1.ArenaVersionValueCheck(UKJENT_1_STATUS)) {
    api.disableField(AVSTAND_1);
    api.setOccurrences(AVSTAND_1, "0..1");
  }

  if (!UKJENT_1_STATUS || UKJENT_1_STATUS.Value == null) {
    api.enableField(AVSTAND_1);
    api.setOccurrences(AVSTAND_1, "1..1");
  }

  if (GlobalFunctions_1.ArenaVersionValueCheck(UKJENT_2_STATUS)) {
    api.disableField(AVSTAND_2);
    api.setOccurrences(AVSTAND_2, "0..1");
  }

  if (!UKJENT_2_STATUS || UKJENT_2_STATUS.Value == null) {
    api.enableField(AVSTAND_2);
    api.setOccurrences(AVSTAND_2, "1..1");
  }
}

exports.enableAvstand = enableAvstand;
},{"./GlobalFunctions":3}]},{},[1])