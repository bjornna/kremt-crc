(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
"use strict";

exports.__esModule = true;

var whatToShowOnSTart_1 = require("./rules/whatToShowOnSTart");

var tumorLocalisation_1 = require("./rules/tumorLocalisation");

var nSykdomTumor_1 = require("./rules/nSykdomTumor");

var mSykdomTumor_1 = require("./rules/mSykdomTumor");

var setCTValue_1 = require("./rules/setCTValue");

var setCNValue_1 = require("./rules/setCNValue");

var setCMValue_1 = require("./rules/setCMValue");

var showFollowup_1 = require("./rules/showFollowup");

var showLab_1 = require("./rules/showLab");

var nSykdomLokalResidiv_1 = require("./rules/nSykdomLokalResidiv"); //import { handleOccurrencesTumor } from "./rules/handleOccurrencesTumor";


var showSpecifyTumorRelated_1 = require("./rules/showSpecifyTumorRelated");

var enableAvstand_1 = require("./rules/enableAvstand");

var disableCEA_1 = require("./rules/disableCEA");

var showSpecifyMetastaseRelated_1 = require("./rules/showSpecifyMetastaseRelated");

var mSykdomLokalResidiv_1 = require("./rules/mSykdomLokalResidiv");

var showSpecifyLokalResidivRelated_1 = require("./rules/showSpecifyLokalResidivRelated");

var checkArenaVersion_1 = require("./rules/checkArenaVersion");

var testFunction_1 = require("./rules/testFunction");

var FUNN_I_UTREDNING = "kreftmelding/kreftmelding_kolorektalkreft_utredning/any_event/funn_i_utredning";
var LOKALISASJON = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/lokalisasjon_av_primaertumor/lokalisajon";
var SPESIFISER_LOKALISASJON_COLON = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/lokalisasjon_av_primaertumor/spesifiser_lokalisajon_colon";
var AVSTAND_1 = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/lokalisasjon_av_primaertumor/angir_avstand_fra_analåpning_til_nedre_kant_av_tumor_(målt_på_stivt_skop)";
var UKJENT_1 = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/lokalisasjon_av_primaertumor/ukjent";
var AVSTAND_2 = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/lokalisasjon_av_primaertumor/avstand_fra_øvre_kant_av_m.puborektalis_til_nedre_kant_av_tumor_(målt_ved_mr)";
var UKJENT_2 = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/lokalisasjon_av_primaertumor/ukjent2"; //var AVSTAND_CLUSTER = "generic-field-71553"; 

var KLINISK_SIKKER_FORMID = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/lokalisasjon_av_primaertumor/klinisk_sikker_kreft";
var TUMOR_AND_METHOD_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/tumor_(t)";
var TUMOR_COLON = "kreftmelding/kreftmelding_kolorektalkreft_utredning/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/tumor_(t-sykdom)/tumor_colon";
var TUMOR_RECTUM = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/tumor_(t-sykdom)/tumor_rectum";
var UTREDNINGSMETODE_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/tumor_(t)/utredningsmetode";
var UTREDNINGSMETODE_TUMOR = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/tumor_(t-sykdom)/utredningsmetode/utredningsmetode";
var SPESIFISER_UTREDNINGSMETODE_TUMOR = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/tumor_(t)/utredningsmetode/spesifiser";
var DATO_TUMOR = "kreftmelding/kreftmelding_kolorektalkreft_utredning/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/tumor_(t-sykdom)/dato_sykdommen_ble_bekreftet";
var ANTATT_AVSTAND = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/antatt_avstand_fra_tumor_malignsuspekt_lymfeknute_tumordeposit_til_mesorectale_fascie,_unntatt_peritoneum_(mm)";
var ANTATT_AVSTAND_UKJENT = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/ukjent";
var N_SYKDOM_TUMOR = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/er_regionale_lymfeknutemetastaser_påvist_(n-sykdom)";
var N_SYKDOM_TUMOR_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/n-sykdom ";
var N_SYKDOM_STATUS_TUMOR = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/n-sykdom/n-status";
var ANTATT_MALIGNE = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/n-sykdom/antatt_maligne_lymfeknuter_på_bekkenvegg__utenfor_mrf(mesorectal_fascie)";
var EKSTRAMURAL = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/n-sykdom/ekstramural_karinnvekst";
var N_SYKDOM_UTREDNINGSMETODE_TUMOR_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/n-sykdom/utredningsmetode";
var N_SYKDOM_UTREDNINGSMETODE_TUMOR = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/n-sykdom/utredningsmetode/utredningsmetode";
var SPESIFISER_UTREDNINGSMETODE_TUMOR_N_SYKDOM = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/n-sykdom/utredningsmetode/spesifiser";
var N_STATUS_COLON_FORMID = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/n-sykdom/n-status_colon";
var N_STATUS_RECTUM_FORMID = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/n-sykdom/n-status_rectum";
var M_SYKDOM_TUMOR = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/er_fjernmetastaser_påvist,_inkludert_lymfeknutemetastaser_utenfor_regionalt_område_(m-sykdom)";
var FJERNMETASTASER_TUMOR_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/fjernmetastaser";
var M_SYKDOM_LOKALISASJON_TUMOR = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/fjernmetastaser/lokalisasjon_av_fjernmetastaser";
var M_SYKDOM_SPESIFISER_LOKALISASJON_TUMOR = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/fjernmetastaser/spesifiser";
var M_SYKDOM_UTREDNINGSMETODE_TUMOR_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/fjernmetastaser/utredsningsmetode_for_fjernmetastaser";
var M_SYKDOM_UTREDNINGSMETODE_TUMOR = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/fjernmetastaser/utredsningsmetode_for_fjernmetastaser/utredsningsmetode_for_fjernmetastaser";
var M_SYKDOM_UTREDNINGSMETODE_SPESIFISER_TUMOR = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/fjernmetastaser/utredsningsmetode_for_fjernmetastaser/spsesifiser";
var M_SYKDOM_DATO_TUMOR = "kreftmelding/kreftmelding_kolorektalkreft_utredning/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/fjernmetastaser/utredsningsmetode_for_fjernmetastaser/dato_for_utredning_av_metastaser";
var CEA_TUMOR = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/cea";
var IKKE_TATT_CEA = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/ikke_tatt";
var ECOG_TUMOR = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/ecog_funksjonsstatus";
var KLINISK_TNM_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/klinisk_tnm_etter_ferdig_primærutredning_og_før_primærbehandling";
var CT_SCORE = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/klinisk_tnm_etter_ferdig_primærutredning_og_før_primærbehandling/ct";
var CN_SCORE = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/klinisk_tnm_etter_ferdig_primærutredning_og_før_primærbehandling/cn";
var CM_SCORE = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/klinisk_tnm_etter_ferdig_primærutredning_og_før_primærbehandling/cm"; // LOKAL RESIDIV 

var LOKAL_RESIDIV_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv";
var I_ANASTOMOSEN = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/i_anastomosen";
var UTREDNINGSMETODE_LOKAL_RESIDIV_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/utredningsmetode";
var UTREDNINGSMETODE_LOKAL_REDISIV = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/utredningsmetode/utredningsmetode";
var UTREDNINGSMETODE_LOKAL_RESIDIV_SPESIFISER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/utredningsmetode/spesifiser";
var DATO_LOKALT_RESIDIV = "kreftmelding/kreftmelding_kolorektalkreft_utredning/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/dato_lokalt_residiv_progresjon_ble_bekreftet";
var N_SYKDOM_LOKAL_RESIDIV = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/er_regionale_lymfeknutemetastaser_påvist(n-sykdom)";
var N_SYKDOM_LOKAL_RESIDIV_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/n-sykdom";
var N_SYKDOM_STATUS_LOKAL_RESIDIV = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/n-sykdom/n-status";
var N_SYKDOM_STATUS_LOKAL_RESIDIV_UTREDNINGSMETODE_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/n-sykdom/utredningsmetode";
var N_SYKDOM_STATUS_LOKAL_RESIDIV_UTREDNINGSMETODE = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/n-sykdom/utredningsmetode/utredningsmetode";
var N_SYKDOM_STATUS_LOKAL_RESIDIV_UTREDNINGSMETODE_SPESIFISER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/n-sykdom/utredningsmetode/utredningsmetode";
var M_SYKDOM_LOKAL_RESIDIV = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/er_fjernmetastaser_påvist,_inkludert_lymfeknutemetastaser_utenfor_regionalt_område_(m-sykdom)";
var M_SYKDOM_LOKAL_RESIDIV_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/fjernmetastaser";
var M_SYKDOM_LOKALISASJON_LOKAL_RESIDIV = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/fjernmetastaser/lokalisasjon_av_fjernmetastaser";
var M_SYKDOM_LOKALISASJON_LOKAL_RESIDIV_SPESIFISER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/fjernmetastaser/spesifiser";
var M_SYKDOM_STATUS_LOKAL_RESIDIV_UTREDNINGSMETODE_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/fjernmetastaser/utredningsmetode_for_fjernmetastaser";
var M_SYKDOM_UTREDNINGSMETODE_LOKAL_RESIDIV = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/fjernmetastaser/utredningsmetode_for_fjernmetastaser/utredningsmetode_for_fjernmetastaser";
var M_SYKDOM_UTREDNINGSMETODE_LOKAL_RESIDIV_SPESIFISER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/fjernmetastaser/utredningsmetode_for_fjernmetastaser/spesifiser";
var M_SYKDOM_DATO_LOKAL_RESIDIV = "kreftmelding/kreftmelding_kolorektalkreft_utredning/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/fjernmetastaser/utredningsmetode_for_fjernmetastaser/dato_for_utredning_av_metastaser";
var CEA_LOKAL_RESIDIV = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/cea";
var CEA_IKKE_TATT_LOKAL_RESIDIV = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/ikke_tatt";
var ECOG_LOKAL_RESIDIDV = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/ecog_funksjonsstatus"; // METASTASER 

var METASTASER_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_metastase(r)";
var METASTASER_LOKALISASJON_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_metastase(r)/metastaser_lokalisasjon";
var METASTASER_LOKALISASJON = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_metastase(r)/metastaser_lokalisasjon/metastaser_lokalisasjon";
var METASTASER_LOKALISASJON_SPESIFISER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_metastase(r)/metastaser_lokalisasjon/spesifiser";
var METASTASER_UTREDNINGSMETODE_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_metastase(r)/utredningsmetode";
var METASTASER_UTREDNINGSMETODE = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_metastase(r)/utredningsmetode/utredningsmetode";
var METASTASER_UTREDNINGSMETODE_SPESIFISER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_metastase(r)/utredningsmetode/spesifiser";
var DATO_FOR_UTREDNING_AV_METASTASER = "kreftmelding/kreftmelding_kolorektalkreft_utredning/any_event/sykdomsutbredelse_ved_utredning_av_metastase(r)/dato_for_utredning_av_metastaser";
var CEA_METASTASER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_metastase(r)/cea";
var CEA_IKKE_TATT_METASTASER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_metastase(r)/ikke_tatt";
var ECOG_METASTASER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_metastase(r)/ecog_funksjonsstatus"; // CEA

var CEA_IKKE_TATT = "kreftmelding/kreftmelding_kolorektalkreft_utredning/any_event/cea/ikke_tatt"; // LABORATORIUM 

var PATOLOGILABORATORIUM_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/patologilaboratorium";
var LABORATORIUM = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/patologilaboratorium/laboratorium";
var IKKE_RELEVANT = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/patologilaboratorium/ikke_relevant";
var LABORATORIUM_SPESIFISER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/patologilaboratorium/spesifiser";
var PREPARATNUMMER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/patologilaboratorium/preparatnummer"; // OPPFØLGING 

var OPPFØLGING = "kreftmelding/kreftmelding_kolorektalkreft_utredning/any_event/oppfølging_tiltak/oppfølging_tiltak";
var NESTE_TRINN = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/hvor_skjer_neste_trinn_i_behandlingen";
var KOMMENTAR = "kreftmelding/context/kommentar";
var KLAR_TIL_SENDING = "kreftmelding_kolorektalkreft_dips/context/klar_til_sending";
var TUMOR_COLON_FORMID = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/tumor_(t-sykdom)/tumor_colon";

function main(api, ctx) {
  console.log(banner);
  console.log(checkArenaVersion_1.checkArenaVersion(api));
  console.log("script runs ");
  api.addListener(FUNN_I_UTREDNING, "OnFormInitialized", function () {
    console.log("whatToSHowOnSTart runs on initialized");
    whatToShowOnSTart_1.whatToShowOnStart(api);
    tumorLocalisation_1.tumorLocalisation(api);
  });
  api.addListener(FUNN_I_UTREDNING, "OnChanged", function () {
    console.log("Funn i utredning changed");
    whatToShowOnSTart_1.whatToShowOnStart(api);
    tumorLocalisation_1.tumorLocalisation(api);
  }); // kaller på nSykdom-Tumor siden N-status er avhengig av lokalisasjon 

  api.addListener(LOKALISASJON, "OnChanged", function () {
    console.log("Lokalisation changed - tumor localisation rule runs");
    tumorLocalisation_1.tumorLocalisation(api); //  handleOccurrencesTumor(api); 

    nSykdomTumor_1.nSykdomTumor(api);
    nSykdomLokalResidiv_1.nSykdomLokalResidiv(api);
  });
  api.addListener(UKJENT_1, "OnChanged", function () {
    console.log("Lokalisation changed - tumor localisation rule runs");
    enableAvstand_1.enableAvstand(api);
  });
  api.addListener(UKJENT_2, "OnChanged", function () {
    console.log("Lokalisation changed - tumor localisation rule runs");
    enableAvstand_1.enableAvstand(api);
  });
  /**
        // nSYkdom TUMOR on Initialized
      api.addListener(N_SYKDOM_TUMOR, "OnFormInitialized",() => {
          console.log("nSykdom runs on formInitialized ");
          nSykdomTumor(api);
        }
      );
  */

  /**
      // mSykdom on Initialized
  
      api.addListener(M_SYKDOM_TUMOR, "OnFormInitialized",() => {
          console.log("mSykdom runs on formInitialized ");
          mSykdomTumor(api);
  
   
        }
      );
  
  */
  // mSykodmOnChanged   - in addition, sets CM value

  api.addListener(M_SYKDOM_TUMOR, "OnChanged", function () {
    console.log("mSYkodmTumor changed - mSykdomTumor rule runs");
    mSykdomTumor_1.mSykdomTumor(api);
    setCMValue_1.setCMValue(api);
  }); // nSYkodm TUMOR on CHANGED 

  api.addListener(N_SYKDOM_TUMOR, "OnChanged", function () {
    console.log("NSYkodmTumor changed - nSykdomTumor rule runs");
    nSykdomTumor_1.nSykdomTumor(api);
    setCNValue_1.setCNValue(api);
  }); //showSpecifyExaminationMethodT  -- og kanskje den funksjon som skal sjekke om ukjent er valgt 

  api.addListener(UTREDNINGSMETODE_TUMOR, "OnChanged", function () {
    showSpecifyTumorRelated_1.showSpecifyExaminationMethodT(api);
    showSpecifyTumorRelated_1.ifExaminationMethodTIsUnkown(api);
  });
  api.addListener(UTREDNINGSMETODE_TUMOR, "OnChildRemoved", function () {
    showSpecifyTumorRelated_1.showSpecifyExaminationMethodT(api);
    showSpecifyTumorRelated_1.ifExaminationMethodTIsUnkown(api);
  }); // Nsykdom-Tumor utredningsmetode show Specify and deal with Unknown

  api.addListener(N_SYKDOM_UTREDNINGSMETODE_TUMOR, "OnChanged", function () {
    showSpecifyTumorRelated_1.showSpecifyExaminationMethodNTumor(api);
    showSpecifyTumorRelated_1.ifExaminationMethodNIsUnkown(api);
  });
  api.addListener(N_SYKDOM_UTREDNINGSMETODE_TUMOR, "OnChildRemoved", function () {
    showSpecifyTumorRelated_1.showSpecifyExaminationMethodNTumor(api);
    showSpecifyTumorRelated_1.ifExaminationMethodNIsUnkown(api);
  }); // Msykdom-Tumor utredningsmetode show Specify and deal with Unknown

  api.addListener(M_SYKDOM_UTREDNINGSMETODE_TUMOR, "OnChanged", function () {
    showSpecifyTumorRelated_1.showSpecifyExaminationMethodMTumor(api);
    showSpecifyTumorRelated_1.ifExaminationMethodMIsUnkown(api);
  });
  api.addListener(M_SYKDOM_UTREDNINGSMETODE_TUMOR, "OnChildRemoved", function () {
    showSpecifyTumorRelated_1.showSpecifyExaminationMethodMTumor(api);
    showSpecifyTumorRelated_1.ifExaminationMethodMIsUnkown(api);
  }); // M-Sykdom-tumor lokalisasjon show Specify

  api.addListener(M_SYKDOM_LOKALISASJON_TUMOR, "OnChanged", function () {
    showSpecifyTumorRelated_1.showSpecifyLokalisasjonMTumor(api);
  });
  api.addListener(M_SYKDOM_LOKALISASJON_TUMOR, "OnChildRemoved", function () {
    showSpecifyTumorRelated_1.showSpecifyLokalisasjonMTumor(api);
  }); // sets CT value - onChanged Rectum Tumor

  api.addListener(TUMOR_RECTUM, "OnChanged", function () {
    console.log("tumor T changed, rule setCTValue runs");
    setCTValue_1.setCTValue(api); //  handleOccurrencesTumor(api);   
  }); // sets CT value - Rectum Tumor; need one listener on Child removed as well 

  api.addListener(TUMOR_RECTUM, "OnChildRemoved", function () {
    console.log("tumor T child removed, rule setSTValue runs");
    setCTValue_1.setCTValue(api); //  handleOccurrencesTumor(api);  
  }); // sets CT value - onChanged Rectum Colon

  api.addListener(TUMOR_COLON, "OnChanged", function () {
    console.log("tumor T changed, rule setCTValue runs");
    setCTValue_1.setCTValue(api); //handleOccurrencesTumor(api);  
  }); // sets CT value - Rectum Colon; need one listener on Child removed as well 

  api.addListener(TUMOR_COLON, "OnChildRemoved", function () {
    console.log("tumor T child removed, rule setSTValue runs");
    setCTValue_1.setCTValue(api); // handleOccurrencesTumor(api);   
  }); // sets CN value- COLON 

  api.addListener(N_STATUS_COLON_FORMID, "OnChanged", function () {
    console.log("n status changed, rule setCNValue runs");
    setCNValue_1.setCNValue(api);
  }); // sets CN value - need one listener on Child removed as well - maybe i dont need this listeners here

  api.addListener(N_STATUS_COLON_FORMID, "OnChildRemoved", function () {
    console.log("n status child removed , rule setCNValue runs");
    setCNValue_1.setCNValue(api);
  });
  api.addListener(N_STATUS_RECTUM_FORMID, "OnChanged", function () {
    console.log("n status changed, rule setCNValue runs");
    setCNValue_1.setCNValue(api);
  }); // sets CN value - need one listener on Child removed as well - maybe i dont need this listeners here

  api.addListener(N_STATUS_RECTUM_FORMID, "OnChildRemoved", function () {
    console.log("n status child removed , rule setCNValue runs");
    setCNValue_1.setCNValue(api);
  }); // handles LOCATION OF NEXT STAGE OF TREATMENT field 

  api.addListener(OPPFØLGING, "OnFormInitialized", function () {
    console.log("followUp measures start on form initialized ");
    showFollowup_1.showFollowup(api);
  }); // handles LOCATION OF NEXT STAGE OF TREATMENT field

  api.addListener(OPPFØLGING, "OnChanged", function () {
    console.log("follow up field value has changed, showFollowUP rule runs");
    showFollowup_1.showFollowup(api);
  }); // handles Lab - on Form Initialized  

  api.addListener(IKKE_RELEVANT, "OnFormInitialized", function () {
    console.log("on form initialized ... ");
    showLab_1.showLab(api);
  }); // handles lab - onChanged - not relevant field  

  api.addListener(IKKE_RELEVANT, "OnChanged", function () {
    console.log("no relevant changed");
    showLab_1.showLab(api);
  }); // handles lab - onChanged - patologi lab 

  api.addListener(LABORATORIUM, "OnChanged", function () {
    console.log("patlogi lab changed");
    showLab_1.showLab(api);
  });
  /**
  api.addListener(TUMOR_FORMID, "OnChanged",() => {
    console.log("Tumor Changed");
    setCTValue(api);
    
  }
  );
  
  
  
  api.addListener(TUMOR_FORMID, "OnChildRemoved",() => {
    console.log("Tumor Changed");
    setCTValue(api);
    testT(api);
    
  }
  );
  
  
  api.addListener(TUMOR_FORMID, "OnChildAdded",() => {
    console.log("Tumor Changed");
    //setCTValue(api);
    testT(api);
      
  }
  );
  
  */

  api.addListener(CEA_IKKE_TATT, "OnChanged", function () {
    disableCEA_1.disableCEA(api);
  }); // LOKAL RESIDIV 
  // nSYkodm LOKAL RESIDIV on CHANGED 

  api.addListener(N_SYKDOM_LOKAL_RESIDIV, "OnChanged", function () {
    console.log("NSYkodm LOKAL changed - nSykdomTumor rule runs");
    nSykdomLokalResidiv_1.nSykdomLokalResidiv(api);
  }); // nSYkodm LOKAL RESIDIV on CHANGED 

  api.addListener(M_SYKDOM_LOKAL_RESIDIV, "OnChanged", function () {
    console.log("MSYkodm LOKAL changed - nSykdomTumor rule runs");
    mSykdomLokalResidiv_1.mSykdomLokalResidiv(api);
  }); //showSpecifyExaminationMethodLokalResidiv 

  api.addListener(UTREDNINGSMETODE_LOKAL_REDISIV, "OnChanged", function () {
    showSpecifyLokalResidivRelated_1.showSpecifyExaminationMethodLokalResidiv(api);
    showSpecifyLokalResidivRelated_1.ifExaminationMethodLokalResidivIsUnkown(api);
  });
  api.addListener(UTREDNINGSMETODE_LOKAL_REDISIV, "OnChildRemoved", function () {
    showSpecifyLokalResidivRelated_1.showSpecifyExaminationMethodLokalResidiv(api);
    showSpecifyLokalResidivRelated_1.ifExaminationMethodLokalResidivIsUnkown(api);
  }); // Nsykdom-LOKAL RESIDIV utredningsmetode show Specify and deal with Unknown

  api.addListener(N_SYKDOM_STATUS_LOKAL_RESIDIV_UTREDNINGSMETODE, "OnChanged", function () {
    showSpecifyLokalResidivRelated_1.showSpecifyExaminationMethodNLokalResidiv(api);
    showSpecifyLokalResidivRelated_1.ifExaminationMethodNIsUnkownLokalResidiv(api);
  });
  api.addListener(N_SYKDOM_STATUS_LOKAL_RESIDIV_UTREDNINGSMETODE, "OnChildRemoved", function () {
    showSpecifyLokalResidivRelated_1.showSpecifyExaminationMethodNLokalResidiv(api);
    showSpecifyLokalResidivRelated_1.ifExaminationMethodNIsUnkownLokalResidiv(api);
  }); // Msykdom-LOKAL RESIDIV utredningsmetode show Specify and deal with Unknown

  api.addListener(M_SYKDOM_UTREDNINGSMETODE_LOKAL_RESIDIV, "OnChanged", function () {
    showSpecifyLokalResidivRelated_1.showSpecifyExaminationMethodMLokalResidiv(api);
    showSpecifyLokalResidivRelated_1.ifExaminationMethodMIsUnkownLokalResidiv(api);
  });
  api.addListener(M_SYKDOM_UTREDNINGSMETODE_LOKAL_RESIDIV, "OnChildRemoved", function () {
    showSpecifyLokalResidivRelated_1.showSpecifyExaminationMethodMLokalResidiv(api);
    showSpecifyLokalResidivRelated_1.ifExaminationMethodMIsUnkownLokalResidiv(api);
  }); // M-Sykdom-tumor lokalisasjon show Specify

  api.addListener(M_SYKDOM_LOKALISASJON_LOKAL_RESIDIV, "OnChanged", function () {
    showSpecifyLokalResidivRelated_1.showSpecifyLokalisasjonMLokalResidiv(api);
  });
  api.addListener(M_SYKDOM_LOKALISASJON_LOKAL_RESIDIV, "OnChildRemoved", function () {
    showSpecifyLokalResidivRelated_1.showSpecifyLokalisasjonMLokalResidiv(api);
  });
  /**
  // disable/enable CEA Lokal RESIDIV
  api.addListener(CEA_IKKE_TATT_LOKAL_RESIDIV, "OnChanged", () => {
    disableCEALokalResidiv(api);
  });
  
  */
  // Metastaser 
  // Show Specify Localisation Metastase

  api.addListener(METASTASER_LOKALISASJON, "OnChanged", function () {
    showSpecifyMetastaseRelated_1.showSpecifyLokalisationMetastase(api);
  });
  api.addListener(METASTASER_LOKALISASJON, "OnChildRemoved", function () {
    showSpecifyMetastaseRelated_1.showSpecifyLokalisationMetastase(api);
  }); //showSpecifyExaminationMethodMetastaser  

  api.addListener(METASTASER_UTREDNINGSMETODE, "OnChanged", function () {
    showSpecifyMetastaseRelated_1.showSpecifyExaminationMethodMetastase(api);
    showSpecifyMetastaseRelated_1.ifExaminationMethodMetastaseIsUnkown(api);
  });
  api.addListener(METASTASER_UTREDNINGSMETODE, "OnChildRemoved", function () {
    showSpecifyMetastaseRelated_1.showSpecifyExaminationMethodMetastase(api);
    showSpecifyMetastaseRelated_1.ifExaminationMethodMetastaseIsUnkown(api);
  });
  api.addListener(KLAR_TIL_SENDING, "OnChanged", function () {
    console.log("runs test Function");

    if (testFunction_1.klarTilSending(api)) {
      testFunction_1.testFunction(api);
    }

    ;

    if (!testFunction_1.klarTilSending(api)) {
      testFunction_1.clearKommentar(api);
    }

    ;
  });
}

exports.main = main; //

var banner = "\n_______                              _       _   \n|__   __|                            (_)     | |  \n   | |_   _ _ __   ___  ___  ___ _ __ _ _ __ | |_ \n   | | | | | '_  / _ / __|/ __| '__| | '_ | __|\n   | | |_| | |_) |  __/__  (__| |  | | |_) | |_ \n   |_|__, | .__/ ___||___/___|_|  |_| .__/ __|\n       __/ | |                         | |        \n      |___/|_|                         |_|   \n";main(api);
},{"./rules/checkArenaVersion":2,"./rules/disableCEA":3,"./rules/enableAvstand":4,"./rules/mSykdomLokalResidiv":6,"./rules/mSykdomTumor":7,"./rules/nSykdomLokalResidiv":8,"./rules/nSykdomTumor":9,"./rules/setCMValue":10,"./rules/setCNValue":11,"./rules/setCTValue":12,"./rules/showFollowup":13,"./rules/showLab":18,"./rules/showSpecifyLokalResidivRelated":19,"./rules/showSpecifyMetastaseRelated":20,"./rules/showSpecifyTumorRelated":21,"./rules/testFunction":22,"./rules/tumorLocalisation":23,"./rules/whatToShowOnSTart":24}],2:[function(require,module,exports){
"use strict";

exports.__esModule = true;
var ARENAVERSSJON_FORMID = "generic-field-77887";

function checkArenaVersion(api) {
  var versjon = api.getFieldValue(ARENAVERSSJON_FORMID);
  var stringToReturn = "";
  console.log(versjon);

  if (versjon == null) {
    stringToReturn = "V_19";
  }

  if (versjon && versjon.Value == null) {
    stringToReturn = "V_18";
  }

  return stringToReturn;
}

exports.checkArenaVersion = checkArenaVersion;
},{}],3:[function(require,module,exports){
"use strict";

exports.__esModule = true;
var CEA = "kreftmelding/kreftmelding_kolorektalkreft_utredning/any_event/cea/cea";
var CEA_IKKE_TATT = "kreftmelding/kreftmelding_kolorektalkreft_utredning/any_event/cea/ikke_tatt";

function disableCEA(api) {
  var ikke_tatt = api.getFieldValue(CEA_IKKE_TATT);
  console.log("dette er boolsk i 18");
  console.log(ikke_tatt);

  if (!ikke_tatt || ikke_tatt.Value == false) {
    console.log("Not taken is not selected");
    api.enableField(CEA);
    api.setOccurrences(CEA, "1..1");
  }

  if (ikke_tatt && ikke_tatt.Value == true) {
    console.log("Not taken selected");
    api.clearField(CEA);
    api.disableField(CEA);
    api.setOccurrences(CEA, "0..1");
  }
}

exports.disableCEA = disableCEA;
},{}],4:[function(require,module,exports){
"use strict";

exports.__esModule = true;

var checkArenaVersion_1 = require("./checkArenaVersion");

var AVSTAND_1 = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/lokalisasjon_av_primaertumor/angir_avstand_fra_analåpning_til_nedre_kant_av_tumor_(målt_på_stivt_skop)";
var UKJENT_1 = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/lokalisasjon_av_primaertumor/ukjent";
var AVSTAND_2 = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/lokalisasjon_av_primaertumor/avstand_fra_øvre_kant_av_m.puborektalis_til_nedre_kant_av_tumor_(målt_ved_mr)";
var UKJENT_2 = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/lokalisasjon_av_primaertumor/ukjent2";

function enableAvstand(api) {
  var UKJENT_1_STATUS = api.getFieldValue(UKJENT_1);
  var UKJENT_2_STATUS = api.getFieldValue(UKJENT_2);
  var ArenaVersjon = checkArenaVersion_1.checkArenaVersion(api);

  if (ArenaVersjon == "V_19" && UKJENT_1_STATUS || ArenaVersjon == "V_18" && UKJENT_1_STATUS.Value == true) {
    api.clearField(AVSTAND_1);
    api.disableField(AVSTAND_1);
    api.setOccurrences(AVSTAND_1, "0..1");
  }

  if (ArenaVersjon == "V_19" && !UKJENT_1_STATUS || ArenaVersjon == "V_18" && UKJENT_1_STATUS.Value == false) {
    api.enableField(AVSTAND_1);
    api.setOccurrences(AVSTAND_1, "1..1");
  }

  if (ArenaVersjon == "V_19" && UKJENT_2_STATUS || ArenaVersjon == "V_18" && UKJENT_2_STATUS.Value == true) {
    api.clearField(AVSTAND_1);
    api.disableField(AVSTAND_2);
    api.setOccurrences(AVSTAND_2, "0..1");
  }

  if (ArenaVersjon == "V_19" && !UKJENT_2_STATUS || ArenaVersjon == "V_18" && UKJENT_2_STATUS.Value == false) {
    api.enableField(AVSTAND_2);
    api.setOccurrences(AVSTAND_2, "1..1");
  }
}

exports.enableAvstand = enableAvstand;
},{"./checkArenaVersion":2}],5:[function(require,module,exports){
"use strict";

exports.__esModule = true;
var TUMOR_AND_METHOD_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/tumor_(t)";
var TUMOR_COLON = "kreftmelding/kreftmelding_kolorektalkreft_utredning/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/tumor_(t-sykdom)/tumor_colon";
var TUMOR_RECTUM = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/tumor_(t-sykdom)/tumor_rectum";
var TUMOR_COLON_FIELDSET = "generic-field-30854";
var TUMOR_RECTUM_FIELDSET = "generic-field-95556";
var UTREDNINGSMETODE_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/tumor_(t)/utredningsmetode";
var UTREDNINGSMETODE_TUMOR = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/tumor_(t-sykdom)/utredningsmetode/utredningsmetode";
var SPESIFISER_UTREDNINGSMETODE_TUMOR = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/tumor_(t)/utredningsmetode/spesifiser";
var DATO_TUMOR = "kreftmelding/kreftmelding_kolorektalkreft_utredning/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/tumor_(t-sykdom)/dato_sykdommen_ble_bekreftet";
var ANTATT_AVSTAND = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/antatt_avstand_fra_tumor_malignsuspekt_lymfeknute_tumordeposit_til_mesorectale_fascie,_unntatt_peritoneum_(mm)";
var ANTATT_AVSTAND_UKJENT = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/ukjent";
var N_SYKDOM_TUMOR = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/er_regionale_lymfeknutemetastaser_påvist_(n-sykdom)";
var N_SYKDOM_TUMOR_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/n-sykdom ";
var N_SYKDOM_STATUS_TUMOR = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/n-sykdom/n-status";
var ANTATT_MALIGNE = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/n-sykdom/antatt_maligne_lymfeknuter_på_bekkenvegg__utenfor_mrf(mesorectal_fascie)";
var EKSTRAMURAL = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/n-sykdom/ekstramural_karinnvekst";
var N_SYKDOM_UTREDNINGSMETODE_TUMOR_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/n-sykdom/utredningsmetode";
var N_SYKDOM_UTREDNINGSMETODE_TUMOR = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/n-sykdom/utredningsmetode/utredningsmetode";
var SPESIFISER_UTREDNINGSMETODE_TUMOR_N_SYKDOM = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/n-sykdom/utredningsmetode/spesifiser";
var M_SYKDOM_TUMOR = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/er_fjernmetastaser_påvist,_inkludert_lymfeknutemetastaser_utenfor_regionalt_område_(m-sykdom)";
var FJERNMETASTASER_TUMOR_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/fjernmetastaser";
var M_SYKDOM_LOKALISASJON_TUMOR = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/fjernmetastaser/lokalisasjon_av_fjernmetastaser";
var M_SYKDOM_SPESIFISER_LOKALISASJON_TUMOR = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/fjernmetastaser/spesifiser";
var M_SYKDOM_UTREDNINGSMETODE_TUMOR_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/fjernmetastaser/utredsningsmetode_for_fjernmetastaser";
var M_SYKDOM_UTREDNINGSMETODE_TUMOR = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/fjernmetastaser/utredsningsmetode_for_fjernmetastaser/utredsningsmetode_for_fjernmetastaser";
var M_SYKDOM_UTREDNINGSMETODE_SPESIFISER_TUMOR = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/fjernmetastaser/utredsningsmetode_for_fjernmetastaser/spsesifiser";
var M_SYKDOM_DATO_TUMOR = "kreftmelding/kreftmelding_kolorektalkreft_utredning/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/fjernmetastaser/utredsningsmetode_for_fjernmetastaser/dato_for_utredning_av_metastaser";
var CEA_TUMOR = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/cea";
var IKKE_TATT_CEA = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/ikke_tatt";
var ECOG_TUMOR = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/ecog_funksjonsstatus";
var KLINISK_TNM_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/klinisk_tnm_etter_ferdig_primærutredning_og_før_primærbehandling";
var CT_SCORE = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/klinisk_tnm_etter_ferdig_primærutredning_og_før_primærbehandling/ct";
var CN_SCORE = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/klinisk_tnm_etter_ferdig_primærutredning_og_før_primærbehandling/cn";
var CM_SCORE = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/klinisk_tnm_etter_ferdig_primærutredning_og_før_primærbehandling/cm"; // LOKAL RESIDIV 

var LOKAL_RESIDIV_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv";
var I_ANASTOMOSEN = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/i_anastomosen";
var UTREDNINGSMETODE_LOKAL_RESIDIV_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/utredningsmetode";
var UTREDNINGSMETODE_LOKAL_REDISIV = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/utredningsmetode/utredningsmetode";
var UTREDNINGSMETODE_LOKAL_RESIDIV_SPESIFISER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/utredningsmetode/spesifiser";
var DATO_LOKALT_RESIDIV = "kreftmelding/kreftmelding_kolorektalkreft_utredning/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/dato_lokalt_residiv_progresjon_ble_bekreftet";
var N_SYKDOM_LOKAL_RESIDIV = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/er_regionale_lymfeknutemetastaser_påvist(n-sykdom)";
var N_SYKDOM_LOKAL_RESIDIV_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/n-sykdom";
var N_SYKDOM_STATUS_LOKAL_RESIDIV = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/n-sykdom/n-status";
var N_SYKDOM_STATUS_LOKAL_RESIDIV_UTREDNINGSMETODE_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/n-sykdom/utredningsmetode";
var N_SYKDOM_STATUS_LOKAL_RESIDIV_UTREDNINGSMETODE = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/n-sykdom/utredningsmetode/utredningsmetode";
var N_SYKDOM_STATUS_LOKAL_RESIDIV_UTREDNINGSMETODE_SPESIFISER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/n-sykdom/utredningsmetode/utredningsmetode";
var M_SYKDOM_LOKAL_RESIDIV = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/er_fjernmetastaser_påvist,_inkludert_lymfeknutemetastaser_utenfor_regionalt_område_(m-sykdom)";
var M_SYKDOM_LOKAL_RESIDIV_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/fjernmetastaser";
var M_SYKDOM_LOKALISASJON_LOKAL_RESIDIV = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/fjernmetastaser/lokalisasjon_av_fjernmetastaser";
var M_SYKDOM_LOKALISASJON_LOKAL_RESIDIV_SPESIFISER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/fjernmetastaser/spesifiser";
var M_SYKDOM_STATUS_LOKAL_RESIDIV_UTREDNINGSMETODE_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/fjernmetastaser/utredningsmetode_for_fjernmetastaser";
var M_SYKDOM_UTREDNINGSMETODE_LOKAL_RESIDIV = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/fjernmetastaser/utredningsmetode_for_fjernmetastaser/utredningsmetode_for_fjernmetastaser";
var M_SYKDOM_UTREDNINGSMETODE_LOKAL_RESIDIV_SPESIFISER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/fjernmetastaser/utredningsmetode_for_fjernmetastaser/spesifiser";
var M_SYKDOM_DATO_LOKAL_RESIDIV = "kreftmelding/kreftmelding_kolorektalkreft_utredning/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/fjernmetastaser/utredningsmetode_for_fjernmetastaser/dato_for_utredning_av_metastaser";
var CEA_LOKAL_RESIDIV = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/cea";
var CEA_IKKE_TATT_LOKAL_RESIDIV = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/ikke_tatt";
var ECOG_LOKAL_RESIDIDV = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/ecog_funksjonsstatus"; // METASTASER 

var METASTASER_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_metastase(r)";
var METASTASER_LOKALISASJON_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_metastase(r)/metastaser_lokalisasjon";
var METASTASER_LOKALISASJON = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_metastase(r)/metastaser_lokalisasjon/metastaser_lokalisasjon";
var METASTASER_LOKALISASJON_SPESIFISER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_metastase(r)/metastaser_lokalisasjon/spesifiser";
var METASTASER_UTREDNINGSMETODE_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_metastase(r)/utredningsmetode";
var METASTASER_UTREDNINGSMETODE = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_metastase(r)/utredningsmetode/utredningsmetode";
var METASTASER_UTREDNINGSMETODE_SPESIFISER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_metastase(r)/utredningsmetode/spesifiser";
var DATO_FOR_UTREDNING_AV_METASTASER = "kreftmelding/kreftmelding_kolorektalkreft_utredning/any_event/sykdomsutbredelse_ved_utredning_av_metastase(r)/dato_for_utredning_av_metastaser";
var CEA_METASTASER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_metastase(r)/cea";
var CEA_IKKE_TATT_METASTASER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_metastase(r)/ikke_tatt";
var ECOG_METASTASER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_metastase(r)/ecog_funksjonsstatus"; // felles 

var CEA_CLUSTER = "kreftmelding/kreftmelding_kolorektalkreft_utredning/any_event/cea";
var CEA = "kreftmelding/kreftmelding_kolorektalkreft_utredning/any_event/cea/cea";
var CEA_IKKE_TATT = "kreftmelding/kreftmelding_kolorektalkreft_utredning/any_event/cea/ikke_tatt";
var ECOG_CLUSTER = "kreftmelding/kreftmelding_kolorektalkreft_utredning/any_event/ecog_funksjonsstatus";
var ECOG = "kreftmelding/kreftmelding_kolorektalkreft_utredning/any_event/ecog_funksjonsstatus/ecog_funksjonsstatus"; // lokalisasjon 

var SPESIFISER_LOKALISASJON_COLON = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/lokalisasjon_av_primaertumor/spesifiser_lokalisajon_colon";
var AVSTAND_1 = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/lokalisasjon_av_primaertumor/angir_avstand_fra_analåpning_til_nedre_kant_av_tumor_(målt_på_stivt_skop)";
var AVSTAND_1_UKJENT = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/lokalisasjon_av_primaertumor/ukjent";
var AVSTAND_2 = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/lokalisasjon_av_primaertumor/avstand_fra_øvre_kant_av_m.puborektalis_til_nedre_kant_av_tumor_(målt_ved_mr)";
var AVSTAND_2_UKJENT = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/lokalisasjon_av_primaertumor/ukjent2";
var KLINISK_SIKKER_KREFT = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/lokalisasjon_av_primaertumor/klinisk_sikker_kreft";

function getPrimaryTumorIds(api) {
  var tumorIds;
  tumorIds = [TUMOR_AND_METHOD_CLUSTER, TUMOR_COLON_FIELDSET, TUMOR_RECTUM_FIELDSET, TUMOR_COLON, TUMOR_RECTUM, UTREDNINGSMETODE_CLUSTER, UTREDNINGSMETODE_TUMOR, N_SYKDOM_TUMOR, N_SYKDOM_TUMOR_CLUSTER, N_SYKDOM_STATUS_TUMOR, ANTATT_MALIGNE, EKSTRAMURAL, N_SYKDOM_UTREDNINGSMETODE_TUMOR_CLUSTER, N_SYKDOM_UTREDNINGSMETODE_TUMOR, M_SYKDOM_TUMOR, DATO_TUMOR, CEA_TUMOR, IKKE_TATT_CEA, ECOG_TUMOR, KLINISK_TNM_CLUSTER, CT_SCORE, CN_SCORE, CM_SCORE];
  return tumorIds;
}

exports.getPrimaryTumorIds = getPrimaryTumorIds;

function getPrimaryTumorIdsToSetOccurrences(api) {
  var tumorIds;
  tumorIds = [UTREDNINGSMETODE_TUMOR, N_SYKDOM_TUMOR, M_SYKDOM_TUMOR, DATO_TUMOR, CEA_TUMOR, ECOG_TUMOR];
  return tumorIds;
}

exports.getPrimaryTumorIdsToSetOccurrences = getPrimaryTumorIdsToSetOccurrences;

function getLocalresidivIds(api) {
  var localResidivIds;
  localResidivIds = [LOKAL_RESIDIV_CLUSTER, I_ANASTOMOSEN, UTREDNINGSMETODE_LOKAL_RESIDIV_CLUSTER, UTREDNINGSMETODE_LOKAL_REDISIV, DATO_LOKALT_RESIDIV, N_SYKDOM_LOKAL_RESIDIV, M_SYKDOM_LOKAL_RESIDIV, CEA_LOKAL_RESIDIV, CEA_IKKE_TATT_LOKAL_RESIDIV, ECOG_LOKAL_RESIDIDV];
  return localResidivIds;
}

exports.getLocalresidivIds = getLocalresidivIds;

function getLocalresidivIdsToSetOccurrences(api) {
  var localResidivIds;
  localResidivIds = [I_ANASTOMOSEN, UTREDNINGSMETODE_LOKAL_REDISIV, DATO_LOKALT_RESIDIV, N_SYKDOM_LOKAL_RESIDIV, M_SYKDOM_LOKAL_RESIDIV, CEA_LOKAL_RESIDIV, ECOG_LOKAL_RESIDIDV];
  return localResidivIds;
}

exports.getLocalresidivIdsToSetOccurrences = getLocalresidivIdsToSetOccurrences;

function getMetastaseIds(api) {
  var metastaseIds;
  metastaseIds = [METASTASER_CLUSTER, METASTASER_LOKALISASJON_CLUSTER, METASTASER_LOKALISASJON, METASTASER_UTREDNINGSMETODE_CLUSTER, METASTASER_UTREDNINGSMETODE, DATO_FOR_UTREDNING_AV_METASTASER, CEA_METASTASER, CEA_IKKE_TATT_METASTASER, ECOG_METASTASER];
  return metastaseIds;
}

exports.getMetastaseIds = getMetastaseIds;

function getMetastaseIdsToSetOccurrences(api) {
  var metastaseIds;
  metastaseIds = [METASTASER_LOKALISASJON, METASTASER_UTREDNINGSMETODE, DATO_FOR_UTREDNING_AV_METASTASER, CEA_METASTASER, ECOG_METASTASER];
  return metastaseIds;
}

exports.getMetastaseIdsToSetOccurrences = getMetastaseIdsToSetOccurrences;

function getFellesIds(api) {
  var fellesIds;
  fellesIds = [CEA_CLUSTER, CEA, CEA_IKKE_TATT, ECOG_CLUSTER, ECOG];
  return fellesIds;
}

exports.getFellesIds = getFellesIds;

function getFellesIdsToSettOccurrenes(api) {
  var fellesIds;
  fellesIds = [CEA, ECOG];
  return fellesIds;
}

exports.getFellesIdsToSettOccurrenes = getFellesIdsToSettOccurrenes;

function getLokalisationIds(api) {
  var LokalisationIds;
  LokalisationIds = [SPESIFISER_LOKALISASJON_COLON, AVSTAND_1, AVSTAND_1_UKJENT, AVSTAND_2, AVSTAND_2_UKJENT, KLINISK_SIKKER_KREFT];
  return LokalisationIds;
}

exports.getLokalisationIds = getLokalisationIds;
},{}],6:[function(require,module,exports){
"use strict";

exports.__esModule = true;
var M_SYKDOM_LOKAL_RESIDIV = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/er_fjernmetastaser_påvist,_inkludert_lymfeknutemetastaser_utenfor_regionalt_område_(m-sykdom)";
var FJERNMETASTASER_LOKAL_RESIDIV_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/fjernmetastaser";
var M_SYKDOM_LOKALISASJON_LOKAL_RESIDIV_FIELDSET = "generic-field-96614";
var M_SYKDOM_LOKALISASJON_LOKAL_RESIDIV = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/fjernmetastaser/lokalisasjon_av_fjernmetastaser";
var M_SYKDOM_SPESIFISER_LOKALISASJON_LOKAL_RESIDIV = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/fjernmetastaser/spesifiser";
var M_SYKDOM_UTREDNINGSMETODE_LOKAL_RESIDIV_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/fjernmetastaser/utredningsmetode_for_fjernmetastaser";
var M_SYKDOM_UTREDNINGSMETODE_LOKAL_RESIDIV = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/fjernmetastaser/utredningsmetode_for_fjernmetastaser/utredningsmetode_for_fjernmetastaser";
var M_SYKDOM_UTREDNINGSMETODE_SPESIFISER_LOKAL_RESIDIV = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/fjernmetastaser/utredningsmetode_for_fjernmetastaser/spesifiser";
var M_SYKDOM_DATO_LOKAL_RESIDIV = "kreftmelding/kreftmelding_kolorektalkreft_utredning/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/fjernmetastaser/utredningsmetode_for_fjernmetastaser/dato_for_utredning_av_metastaser";

function mSykdomLokalResidiv(api) {
  var m_sydkom_lokal_residiv_value = api.getFieldValue(M_SYKDOM_LOKAL_RESIDIV);

  if (m_sydkom_lokal_residiv_value == null || m_sydkom_lokal_residiv_value.Value == null) {
    api.hideField(M_SYKDOM_LOKALISASJON_LOKAL_RESIDIV_FIELDSET);
    api.clearField(M_SYKDOM_LOKALISASJON_LOKAL_RESIDIV);
    api.hideField(M_SYKDOM_LOKALISASJON_LOKAL_RESIDIV);
    api.setOccurrences(M_SYKDOM_LOKALISASJON_LOKAL_RESIDIV, "0..-1");
    api.clearField(M_SYKDOM_SPESIFISER_LOKALISASJON_LOKAL_RESIDIV);
    api.hideField(M_SYKDOM_SPESIFISER_LOKALISASJON_LOKAL_RESIDIV);
    api.hideField(M_SYKDOM_UTREDNINGSMETODE_LOKAL_RESIDIV_CLUSTER);
    api.clearField(M_SYKDOM_UTREDNINGSMETODE_LOKAL_RESIDIV);
    api.setOccurrences(M_SYKDOM_UTREDNINGSMETODE_LOKAL_RESIDIV, "0..-1");
    api.hideField(M_SYKDOM_UTREDNINGSMETODE_LOKAL_RESIDIV);
    api.clearField(M_SYKDOM_UTREDNINGSMETODE_SPESIFISER_LOKAL_RESIDIV);
    api.hideField(M_SYKDOM_UTREDNINGSMETODE_SPESIFISER_LOKAL_RESIDIV);
    api.clearField(M_SYKDOM_DATO_LOKAL_RESIDIV);
    api.setOccurrences(M_SYKDOM_DATO_LOKAL_RESIDIV, "0..-1");
    api.hideField(M_SYKDOM_DATO_LOKAL_RESIDIV);
  }

  if (m_sydkom_lokal_residiv_value && m_sydkom_lokal_residiv_value.Value != null) {
    if (m_sydkom_lokal_residiv_value.Value == "Ja") {
      console.log("M sykdom JA");
      api.showField(FJERNMETASTASER_LOKAL_RESIDIV_CLUSTER);
      api.showField(M_SYKDOM_LOKALISASJON_LOKAL_RESIDIV_FIELDSET);
      api.showField(M_SYKDOM_LOKALISASJON_LOKAL_RESIDIV);
      api.setOccurrences(M_SYKDOM_LOKALISASJON_LOKAL_RESIDIV, "1..-1");
      api.showField(M_SYKDOM_UTREDNINGSMETODE_LOKAL_RESIDIV_CLUSTER);
      api.showField(M_SYKDOM_UTREDNINGSMETODE_LOKAL_RESIDIV);
      api.setOccurrences(M_SYKDOM_UTREDNINGSMETODE_LOKAL_RESIDIV, "1..-1");
      api.showField(M_SYKDOM_DATO_LOKAL_RESIDIV);
      api.setOccurrences(M_SYKDOM_DATO_LOKAL_RESIDIV, "1..1");
    }

    if (m_sydkom_lokal_residiv_value.Value == "Nei") {
      api.showField(FJERNMETASTASER_LOKAL_RESIDIV_CLUSTER);
      api.clearField(M_SYKDOM_LOKALISASJON_LOKAL_RESIDIV);
      api.hideField(M_SYKDOM_LOKALISASJON_LOKAL_RESIDIV);
      api.hideField(M_SYKDOM_LOKALISASJON_LOKAL_RESIDIV_FIELDSET);
      api.setOccurrences(M_SYKDOM_LOKALISASJON_LOKAL_RESIDIV, "0..-1");
      api.showField(M_SYKDOM_UTREDNINGSMETODE_LOKAL_RESIDIV_CLUSTER);
      api.showField(M_SYKDOM_UTREDNINGSMETODE_LOKAL_RESIDIV);
      api.setOccurrences(M_SYKDOM_UTREDNINGSMETODE_LOKAL_RESIDIV, "1..-1");
      api.showField(M_SYKDOM_DATO_LOKAL_RESIDIV);
      api.setOccurrences(M_SYKDOM_DATO_LOKAL_RESIDIV, "1..1");
    }

    if (m_sydkom_lokal_residiv_value.Value == "Ikke undersøkt") {
      api.clearField(M_SYKDOM_LOKALISASJON_LOKAL_RESIDIV);
      api.hideField(M_SYKDOM_LOKALISASJON_LOKAL_RESIDIV);
      api.hideField(M_SYKDOM_LOKALISASJON_LOKAL_RESIDIV_FIELDSET);
      api.setOccurrences(M_SYKDOM_LOKALISASJON_LOKAL_RESIDIV, "0..-1");
      api.clearField(M_SYKDOM_SPESIFISER_LOKALISASJON_LOKAL_RESIDIV);
      api.hideField(M_SYKDOM_SPESIFISER_LOKALISASJON_LOKAL_RESIDIV);
      api.hideField(M_SYKDOM_UTREDNINGSMETODE_LOKAL_RESIDIV_CLUSTER);
      api.clearField(M_SYKDOM_UTREDNINGSMETODE_LOKAL_RESIDIV);
      api.setOccurrences(M_SYKDOM_UTREDNINGSMETODE_LOKAL_RESIDIV, "0..-1");
      api.hideField(M_SYKDOM_UTREDNINGSMETODE_LOKAL_RESIDIV);
      api.clearField(M_SYKDOM_UTREDNINGSMETODE_SPESIFISER_LOKAL_RESIDIV);
      api.hideField(M_SYKDOM_UTREDNINGSMETODE_SPESIFISER_LOKAL_RESIDIV);
      api.clearField(M_SYKDOM_DATO_LOKAL_RESIDIV);
      api.setOccurrences(M_SYKDOM_DATO_LOKAL_RESIDIV, "0..-1");
      api.hideField(M_SYKDOM_DATO_LOKAL_RESIDIV);
    }
  }
}

exports.mSykdomLokalResidiv = mSykdomLokalResidiv;
},{}],7:[function(require,module,exports){
"use strict";

exports.__esModule = true;
var M_SYKDOM_TUMOR = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/er_fjernmetastaser_påvist,_inkludert_lymfeknutemetastaser_utenfor_regionalt_område_(m-sykdom)";
var FJERNMETASTASER_TUMOR_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/fjernmetastaser";
var M_SYKDOM_LOKALISASJON_TUMOR_FIELDSET = "generic-field-26125";
var M_SYKDOM_LOKALISASJON_TUMOR = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/fjernmetastaser/lokalisasjon_av_fjernmetastaser";
var M_SYKDOM_SPESIFISER_LOKALISASJON_TUMOR = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/fjernmetastaser/spesifiser";
var M_SYKDOM_UTREDNINGSMETODE_TUMOR_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/fjernmetastaser/utredsningsmetode_for_fjernmetastaser";
var M_SYKDOM_UTREDNINGSMETODE_TUMOR = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/fjernmetastaser/utredsningsmetode_for_fjernmetastaser/utredsningsmetode_for_fjernmetastaser";
var M_SYKDOM_UTREDNINGSMETODE_SPESIFISER_TUMOR = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/fjernmetastaser/utredsningsmetode_for_fjernmetastaser/spsesifiser";
var M_SYKDOM_DATO_TUMOR = "kreftmelding/kreftmelding_kolorektalkreft_utredning/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/fjernmetastaser/utredsningsmetode_for_fjernmetastaser/dato_for_utredning_av_metastaser";

function mSykdomTumor(api) {
  var m_sykdom_tumor_value = api.getFieldValue(M_SYKDOM_TUMOR);

  if (!m_sykdom_tumor_value || m_sykdom_tumor_value.Value == null) {
    console.log("M sykdom not choosen");
    api.hideField(FJERNMETASTASER_TUMOR_CLUSTER);
    api.hideField(M_SYKDOM_LOKALISASJON_TUMOR_FIELDSET);
    api.clearField(M_SYKDOM_LOKALISASJON_TUMOR);
    api.hideField(M_SYKDOM_LOKALISASJON_TUMOR);
    api.setOccurrences(M_SYKDOM_LOKALISASJON_TUMOR, "0..-1");
    api.clearField(M_SYKDOM_SPESIFISER_LOKALISASJON_TUMOR);
    api.hideField(M_SYKDOM_SPESIFISER_LOKALISASJON_TUMOR);
    api.hideField(M_SYKDOM_UTREDNINGSMETODE_TUMOR_CLUSTER);
    api.clearField(M_SYKDOM_UTREDNINGSMETODE_TUMOR);
    api.setOccurrences(M_SYKDOM_UTREDNINGSMETODE_TUMOR, "0..-1");
    api.hideField(M_SYKDOM_UTREDNINGSMETODE_TUMOR);
    api.clearField(M_SYKDOM_UTREDNINGSMETODE_SPESIFISER_TUMOR);
    api.hideField(M_SYKDOM_UTREDNINGSMETODE_SPESIFISER_TUMOR);
    api.clearField(M_SYKDOM_DATO_TUMOR);
    api.setOccurrences(M_SYKDOM_DATO_TUMOR, "0..-1");
    api.hideField(M_SYKDOM_DATO_TUMOR);
  }

  if (m_sykdom_tumor_value && m_sykdom_tumor_value.Value != null) {
    if (m_sykdom_tumor_value.Value == "Ja") {
      console.log("M sykdom JA");
      api.showField(FJERNMETASTASER_TUMOR_CLUSTER);
      api.showField(M_SYKDOM_LOKALISASJON_TUMOR_FIELDSET);
      api.showField(M_SYKDOM_LOKALISASJON_TUMOR);
      api.setOccurrences(M_SYKDOM_LOKALISASJON_TUMOR, "1..-1");
      api.showField(M_SYKDOM_UTREDNINGSMETODE_TUMOR_CLUSTER);
      api.showField(M_SYKDOM_UTREDNINGSMETODE_TUMOR);
      api.setOccurrences(M_SYKDOM_UTREDNINGSMETODE_TUMOR, "1..-1");
      api.showField(M_SYKDOM_DATO_TUMOR);
      api.setOccurrences(M_SYKDOM_DATO_TUMOR, "1..1");
    }

    if (m_sykdom_tumor_value.Value == "Nei") {
      console.log("M sykdom NEI");
      api.showField(FJERNMETASTASER_TUMOR_CLUSTER);
      api.clearField(M_SYKDOM_LOKALISASJON_TUMOR);
      api.hideField(M_SYKDOM_LOKALISASJON_TUMOR);
      api.hideField(M_SYKDOM_LOKALISASJON_TUMOR_FIELDSET);
      api.setOccurrences(M_SYKDOM_LOKALISASJON_TUMOR, "0..-1");
      api.showField(M_SYKDOM_UTREDNINGSMETODE_TUMOR_CLUSTER);
      api.showField(M_SYKDOM_UTREDNINGSMETODE_TUMOR);
      api.setOccurrences(M_SYKDOM_UTREDNINGSMETODE_TUMOR, "1..-1");
      api.showField(M_SYKDOM_DATO_TUMOR);
      api.setOccurrences(M_SYKDOM_DATO_TUMOR, "1..1");
    }

    if (m_sykdom_tumor_value.Value == "Ikke undersøkt") {
      console.log("M sykdom IKKE UNDERSØKT");
      api.clearField(M_SYKDOM_LOKALISASJON_TUMOR);
      api.hideField(M_SYKDOM_LOKALISASJON_TUMOR);
      api.hideField(M_SYKDOM_LOKALISASJON_TUMOR_FIELDSET);
      api.setOccurrences(M_SYKDOM_LOKALISASJON_TUMOR, "0..-1");
      api.clearField(M_SYKDOM_SPESIFISER_LOKALISASJON_TUMOR);
      api.hideField(M_SYKDOM_SPESIFISER_LOKALISASJON_TUMOR);
      api.hideField(M_SYKDOM_UTREDNINGSMETODE_TUMOR_CLUSTER);
      api.clearField(M_SYKDOM_UTREDNINGSMETODE_TUMOR);
      api.setOccurrences(M_SYKDOM_UTREDNINGSMETODE_TUMOR, "0..-1");
      api.hideField(M_SYKDOM_UTREDNINGSMETODE_TUMOR);
      api.clearField(M_SYKDOM_UTREDNINGSMETODE_SPESIFISER_TUMOR);
      api.hideField(M_SYKDOM_UTREDNINGSMETODE_SPESIFISER_TUMOR);
      api.clearField(M_SYKDOM_DATO_TUMOR);
      api.setOccurrences(M_SYKDOM_DATO_TUMOR, "0..-1");
      api.hideField(M_SYKDOM_DATO_TUMOR);
    }
  }
}

exports.mSykdomTumor = mSykdomTumor;
},{}],8:[function(require,module,exports){
"use strict";

exports.__esModule = true;
var LOKALISASJON = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/lokalisasjon_av_primaertumor/lokalisajon";
var N_SYKDOM_LOKAL_RESIDIV = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/er_regionale_lymfeknutemetastaser_påvist(n-sykdom)";
var N_STATUS_COLON_FIELDSET = "generic-field-13687";
var N_STATUS_COLON = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/n-sykdom/n-status_colon";
var N_STATUS_RECTUM_FIELDSET = "generic-field-82073";
var N_STATUS_RECTUM = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/n-sykdom/n-status_rectum";
var N_SYKDOM_LOKAL_RESIDIV_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/n-sykdom";
var N_SYKDOM_STATUS_LOKAL_RESIDIV = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/n-sykdom/n-status";
var N_SYKDOM_STATUS_LOKAL_RESIDIV_UTREDNINGSMETODE_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/n-sykdom/utredningsmetode";
var N_SYKDOM_STATUS_LOKAL_RESIDIV_UTREDNINGSMETODE = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/n-sykdom/utredningsmetode/utredningsmetode";
var N_SYKDOM_STATUS_LOKAL_RESIDIV_UTREDNINGSMETODE_SPESIFISER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/n-sykdom/utredningsmetode/utredningsmetode";

function nSykdomLokalResidiv(api) {
  var nSykdomIds;
  nSykdomIds = [N_STATUS_COLON_FIELDSET, N_STATUS_RECTUM_FIELDSET, N_STATUS_COLON, N_STATUS_RECTUM, N_SYKDOM_LOKAL_RESIDIV_CLUSTER, N_SYKDOM_STATUS_LOKAL_RESIDIV_UTREDNINGSMETODE_CLUSTER, N_SYKDOM_STATUS_LOKAL_RESIDIV_UTREDNINGSMETODE, N_SYKDOM_STATUS_LOKAL_RESIDIV_UTREDNINGSMETODE_SPESIFISER];
  var n_sykdom_lokal_residiv_value = api.getFieldValue(N_SYKDOM_LOKAL_RESIDIV);
  var lokalisasjon_value = api.getFieldValue(LOKALISASJON);

  if (!n_sykdom_lokal_residiv_value || n_sykdom_lokal_residiv_value.Value == null) {
    console.log("n sykdom tumor ikke valgt");

    for (var i = 0; i < nSykdomIds.length; i++) {
      api.hideField(nSykdomIds[i]);
      api.clearField(nSykdomIds[i]);
    }

    api.setOccurrences(N_STATUS_COLON, "0..-1");
    api.setOccurrences(N_STATUS_RECTUM, "0..-1");
    api.setOccurrences(N_SYKDOM_STATUS_LOKAL_RESIDIV_UTREDNINGSMETODE, "0..-1");
  }

  if (n_sykdom_lokal_residiv_value && n_sykdom_lokal_residiv_value != null) {
    if (n_sykdom_lokal_residiv_value.Value == "Ja") {
      console.log("n sykdom ja ");

      if (lokalisasjon_value && lokalisasjon_value.Value == "Colon (C18-C19)") {
        console.log("n sykdom er valgt i kombinasjon med colon");

        for (var i = 0; i < nSykdomIds.length; i++) {
          api.showField(nSykdomIds[i]);
        }

        api.hideField(N_STATUS_RECTUM_FIELDSET);
        api.clearField(N_STATUS_RECTUM);
        api.setOccurrences(N_STATUS_RECTUM, "0..-1");
        api.hideField(N_SYKDOM_STATUS_LOKAL_RESIDIV_UTREDNINGSMETODE_SPESIFISER);
        api.setOccurrences(N_STATUS_COLON, "1..-1");
        api.setOccurrences(N_SYKDOM_STATUS_LOKAL_RESIDIV_UTREDNINGSMETODE, "1..-1");
      }

      if (lokalisasjon_value && lokalisasjon_value.Value == "Rectum (C20)") {
        console.log("n sykdom er valgt i kombinasjon med rectum");

        for (var i = 0; i < nSykdomIds.length; i++) {
          api.showField(nSykdomIds[i]);
        }

        api.hideField(N_STATUS_COLON_FIELDSET);
        api.clearField(N_STATUS_COLON);
        api.setOccurrences(N_STATUS_COLON, "0..-1");
        api.hideField(N_SYKDOM_STATUS_LOKAL_RESIDIV_UTREDNINGSMETODE_SPESIFISER);
        api.setOccurrences(N_STATUS_RECTUM, "1..-1");
        api.setOccurrences(N_SYKDOM_STATUS_LOKAL_RESIDIV_UTREDNINGSMETODE, "1..-1");
      }
    }

    if (n_sykdom_lokal_residiv_value.Value == "Nei") {
      console.log("n sykdom NEI ");
      api.showField(N_SYKDOM_LOKAL_RESIDIV_CLUSTER);
      api.showField(N_SYKDOM_STATUS_LOKAL_RESIDIV_UTREDNINGSMETODE_CLUSTER);
      api.showField(N_SYKDOM_STATUS_LOKAL_RESIDIV_UTREDNINGSMETODE);
      api.setOccurrences(N_SYKDOM_STATUS_LOKAL_RESIDIV_UTREDNINGSMETODE, "1..-1");
      api.clearField(N_STATUS_COLON);
      api.hideField(N_STATUS_COLON_FIELDSET);
      api.setOccurrences(N_STATUS_COLON, "0..-1");
      api.clearField(N_STATUS_RECTUM);
      api.hideField(N_STATUS_RECTUM_FIELDSET);
      api.setOccurrences(N_STATUS_RECTUM, "0..-1");
    }

    if (n_sykdom_lokal_residiv_value.Value == "Ikke undersøkt") {
      console.log("n sykdom IKKE UNDERSØKT ");

      for (var i = 0; i < nSykdomIds.length; i++) {
        api.clearField(nSykdomIds[i]);
        api.hideField(nSykdomIds[i]);
        api.setOccurrences(N_STATUS_COLON, "0..-1");
        api.setOccurrences(N_STATUS_RECTUM, "0..-1");
        api.setOccurrences(N_SYKDOM_STATUS_LOKAL_RESIDIV_UTREDNINGSMETODE, "0..-1");
      }
    }
  }
}

exports.nSykdomLokalResidiv = nSykdomLokalResidiv;
},{}],9:[function(require,module,exports){
"use strict";

exports.__esModule = true;
var LOKALISASJON = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/lokalisasjon_av_primaertumor/lokalisajon";
var N_SYKDOM_TUMOR = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/er_regionale_lymfeknutemetastaser_påvist_(n-sykdom)";
var N_STATUS_COLON_FIELDSET = "generic-field-19038"; // grunnen til at det finnes en filedset er pga vanskeligheter med å skjule dvd coded text

var N_STATUS_COLON = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/n-sykdom/n-status_colon";
var N_STATUS_RECTUM_FIELDSET = "generic-field-86764";
var N_STATUS_RECTUM = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/n-sykdom/n-status_rectum";
var N_SYKDOM_TUMOR_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/n-sykdom";
var ANTATT_MALIGNE = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/n-sykdom/antatt_maligne_lymfeknuter_på_bekkenvegg__utenfor_mrf(mesorectal_fascie)";
var EKSTRAMURAL = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/n-sykdom/ekstramural_karinnvekst";
var N_SYKDOM_UTREDNINGSMETODE_TUMOR_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/n-sykdom/utredningsmetode";
var N_SYKDOM_UTREDNINGSMETODE_TUMOR = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/n-sykdom/utredningsmetode/utredningsmetode";
var SPESIFISER_UTREDNINGSMETODE_TUMOR_N_SYKDOM = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/n-sykdom/utredningsmetode/spesifiser";

function nSykdomTumor(api) {
  var nSykdomIds;
  nSykdomIds = [N_STATUS_COLON_FIELDSET, N_STATUS_RECTUM_FIELDSET, N_STATUS_COLON, N_STATUS_RECTUM, N_SYKDOM_TUMOR_CLUSTER, ANTATT_MALIGNE, EKSTRAMURAL, N_SYKDOM_UTREDNINGSMETODE_TUMOR_CLUSTER, N_SYKDOM_UTREDNINGSMETODE_TUMOR, SPESIFISER_UTREDNINGSMETODE_TUMOR_N_SYKDOM];
  var n_sykdom_tumor_value = api.getFieldValue(N_SYKDOM_TUMOR);
  var lokalisasjon_value = api.getFieldValue(LOKALISASJON);

  if (!n_sykdom_tumor_value || n_sykdom_tumor_value.Value == null) {
    console.log("n sykdom tumor not choosen");

    for (var i = 0; i < nSykdomIds.length; i++) {
      api.hideField(nSykdomIds[i]);
      api.clearField(nSykdomIds[i]);
    }

    api.setOccurrences(N_STATUS_COLON, "0..-1");
    api.setOccurrences(N_STATUS_RECTUM, "0..-1");
    api.setOccurrences(N_SYKDOM_UTREDNINGSMETODE_TUMOR, "0..-1");
  }

  if (n_sykdom_tumor_value && n_sykdom_tumor_value.Value != null) {
    if (n_sykdom_tumor_value.Value == "Ja") {
      console.log("n sykdom JA ");

      if (lokalisasjon_value && lokalisasjon_value.Value == "Colon (C18-C19)") {
        for (var i = 0; i < nSykdomIds.length; i++) {
          api.showField(nSykdomIds[i]);
        }

        api.hideField(N_STATUS_RECTUM_FIELDSET);
        api.clearField(N_STATUS_RECTUM);
        api.setOccurrences(N_STATUS_RECTUM, "0..-1");
        api.hideField(SPESIFISER_UTREDNINGSMETODE_TUMOR_N_SYKDOM);
        api.setOccurrences(N_STATUS_COLON, "1..-1");
        api.setOccurrences(ANTATT_MALIGNE, "1..1");
        api.setOccurrences(EKSTRAMURAL, "1..1");
        api.setOccurrences(N_SYKDOM_UTREDNINGSMETODE_TUMOR, "1..-1");
      }

      if (lokalisasjon_value && lokalisasjon_value.Value == "Rectum (C20)") {
        for (var i = 0; i < nSykdomIds.length; i++) {
          api.showField(nSykdomIds[i]);
        }

        api.hideField(N_STATUS_COLON_FIELDSET);
        api.clearField(N_STATUS_COLON);
        api.setOccurrences(N_STATUS_COLON, "0..-1");
        api.hideField(SPESIFISER_UTREDNINGSMETODE_TUMOR_N_SYKDOM);
        api.setOccurrences(N_STATUS_RECTUM, "1..-1");
        api.setOccurrences(ANTATT_MALIGNE, "1..1");
        api.setOccurrences(EKSTRAMURAL, "1..1");
        api.setOccurrences(N_SYKDOM_UTREDNINGSMETODE_TUMOR, "1..-1");
      }
    }

    if (n_sykdom_tumor_value.Value == "Nei") {
      console.log("n sykdom NEI ");
      api.showField(N_SYKDOM_TUMOR_CLUSTER);
      api.showField(N_SYKDOM_UTREDNINGSMETODE_TUMOR_CLUSTER);
      api.showField(N_SYKDOM_UTREDNINGSMETODE_TUMOR);
      api.setOccurrences(N_SYKDOM_UTREDNINGSMETODE_TUMOR, "1..-1");
      api.clearField(N_STATUS_COLON);
      api.hideField(N_STATUS_COLON_FIELDSET);
      api.setOccurrences(N_STATUS_COLON, "0..-1");
      api.clearField(N_STATUS_RECTUM);
      api.hideField(N_STATUS_RECTUM_FIELDSET);
      api.setOccurrences(N_STATUS_RECTUM, "0..-1");
      api.hideField(ANTATT_MALIGNE);
      api.hideField(EKSTRAMURAL);
      api.clearField(ANTATT_MALIGNE);
      api.clearField(EKSTRAMURAL);
      api.setOccurrences(EKSTRAMURAL, "0..-1");
      api.setOccurrences(ANTATT_MALIGNE, "0..-1");
    }

    if (n_sykdom_tumor_value.Value == "Ikke undersøkt") {
      console.log("n sykdom IKKE UNDERSØKT ");

      for (var i = 0; i < nSykdomIds.length; i++) {
        api.clearField(nSykdomIds[i]);
        api.hideField(nSykdomIds[i]);
      }

      api.setOccurrences(N_STATUS_COLON, "0..-1");
      api.setOccurrences(N_STATUS_RECTUM, "0..-1");
      api.setOccurrences(N_SYKDOM_UTREDNINGSMETODE_TUMOR, "0..-1");
    }
  }
}

exports.nSykdomTumor = nSykdomTumor;
},{}],10:[function(require,module,exports){
"use strict";

exports.__esModule = true;

// Kommentert ut av byggescript = require("ehrcraft-form-api");

var M_SYKDOM_TUMOR = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/er_fjernmetastaser_påvist,_inkludert_lymfeknutemetastaser_utenfor_regionalt_område_(m-sykdom)";
var CM_SCORE = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/klinisk_tnm_etter_ferdig_primærutredning_og_før_primærbehandling/cm";

function setCMValue(api) {
  var mStatusToSet = "";
  var mStatus = api.getFieldValue(M_SYKDOM_TUMOR);

  if (mStatus) {
    if (mStatus.Value == "Ja") {
      mStatusToSet = "1b";
    }

    if (mStatus.Value == "Nei") {
      mStatusToSet = "0";
    }

    if (mStatus.Value == "Ikke undersøkt") {
      mStatusToSet = "X";
    }

    var ny = new DvText(mStatusToSet);
    api.setFieldValue(CM_SCORE, ny);
  }

  if (!mStatus) {
    api.clearField(CM_SCORE);
  }
}

exports.setCMValue = setCMValue;
},{}],11:[function(require,module,exports){
"use strict";

exports.__esModule = true;

// Kommentert ut av byggescript = require("ehrcraft-form-api");

var LOKALISASJON_TUMOR_FORMID = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/lokalisasjon_av_primaertumor/lokalisajon";
var N_STATUS_COLON_FORMID = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/n-sykdom/n-status_colon";
var N_STATUS_RECTUM_FORMID = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/n-sykdom/n-status_rectum";
var N_SYKDOM_STATUS_FORMID = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/er_regionale_lymfeknutemetastaser_påvist_(n-sykdom)";
var CN_SCORE_FORMID = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/klinisk_tnm_etter_ferdig_primærutredning_og_før_primærbehandling/cn";

function setCNValue(api) {
  console.log("Set Cn value rule runs");
  var n_sykdom_status = api.getFieldValue(N_SYKDOM_STATUS_FORMID);
  var nStatusToSet = "";

  if (api.getFieldValue(LOKALISASJON_TUMOR_FORMID)) {
    // based on LOCATION, "hentet" gets its value
    if (api.getFieldValue(LOKALISASJON_TUMOR_FORMID).Value == "Colon (C18-C19)") {
      console.log("choosen localisation is Colon");
      var hentet = api.getFields(N_STATUS_COLON_FORMID);
    }

    if (api.getFieldValue(LOKALISASJON_TUMOR_FORMID).Value == "Rectum (C20)") {
      console.log("choosen localisation is Rectum");
      hentet = api.getFields(N_STATUS_RECTUM_FORMID);
    }
  }

  if (n_sykdom_status && n_sykdom_status.Value == "Nei") {
    nStatusToSet = "0";
  }

  if (n_sykdom_status && n_sykdom_status.Value == "Ikke undersøkt") {
    nStatusToSet = "X";
  }

  if (searchForValue(hentet, "N1 - Metastase til 1-3 regionale lymfeknuter")) {
    console.log("N1 valgt");
    nStatusToSet = "1";
  }

  ;

  if (searchForValue(hentet, "N1a - Metastase til 1 regional lymfeknute")) {
    console.log("N1a valgt");
    nStatusToSet = "1a";
  }

  ;

  if (searchForValue(hentet, "N1b - Metastase til 2-3 regionale lymfeknuter")) {
    console.log("N1b valgt");
    nStatusToSet = "1b";
  }

  ;

  if (searchForValue(hentet, "N1c - Tumorknute(r) (satelitt(er)) i subserosa eller i ikke-peritonealisert pericolisk bløtvev uten regional(e) lymfeknutemetastase(r)")) {
    console.log("N1c valgt");
    nStatusToSet = "1c";
  }

  ;

  if (searchForValue(hentet, "N2 - Metastase til 4 eller flere regionale lymfeknuter")) {
    console.log("N2 valgt");
    nStatusToSet = "2";
  }

  ;
  var ny = new DvText(nStatusToSet);
  console.log(ny);
  api.setFieldValue(CN_SCORE_FORMID, ny);
}

exports.setCNValue = setCNValue; //  

function searchForValue(array, searchValue, functionThatCallsMe) {
  var arrayToSearch = array;

  function testFunction(element) {
    if (!element) {
      return "ERROR" === searchValue;
    } else {
      return element.value === searchValue;
    }
  }

  var retval = arrayToSearch.some(testFunction);
  console.log("Searched for " + searchValue + "Returned value is : " + retval);
  return retval;
}

exports.searchForValue = searchForValue;
},{}],12:[function(require,module,exports){
"use strict";

exports.__esModule = true;

// Kommentert ut av byggescript = require("ehrcraft-form-api");

var LOKALISASJON = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/lokalisasjon_av_primaertumor/lokalisajon";
var TUMOR_COLON = "kreftmelding/kreftmelding_kolorektalkreft_utredning/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/tumor_(t-sykdom)/tumor_colon";
var TUMOR_RECTUM = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/tumor_(t-sykdom)/tumor_rectum";
var CT_SCORE = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/klinisk_tnm_etter_ferdig_primærutredning_og_før_primærbehandling/ct";

function setCTValue(api) {
  var toSett = "";
  var lokalisasjon = api.getFieldValue(LOKALISASJON);

  if (lokalisasjon) {
    // based on LOCATION, "hentet" gets its value 
    if (lokalisasjon.Value == "Colon (C18-C19)") {
      console.log("choosen localisation is Colon");
      var hentet = api.getFields(TUMOR_COLON);
    }

    if (lokalisasjon.Value == "Rectum (C20)") {
      console.log("choosen localisation is Rectum");
      hentet = api.getFields(TUMOR_RECTUM);
    }
  } // converts hentet to string


  var stringValue = hentet.toString(); // search through string 

  if (stringValue.search("TX - Ingen informasjon") > 0) {
    console.log("Tx valgt");
    toSett = "X";
  }

  ;

  if (stringValue.search("T0 - Tumor ikke påvist") > 0) {
    console.log("T0 valgt");
    toSett = "0";
  }

  ;

  if (stringValue.search("Tis - Carsinoma in situ") > 0) {
    console.log("Tis valgt");
    toSett = "is";
  }

  ;

  if (stringValue.search("T1 - Tumor vokser inn i submucosa") > 0) {
    console.log("T1 valgt");
    toSett = "1";
  }

  ;

  if (stringValue.search("T2 - Tumor vokser inn i muscularis propria") > 0) {
    console.log("T2 valgt");
    toSett = "2";
  }

  ;

  if (stringValue.search("T1-T2 -Tumor vokser inn i submucosa eller muscularis propria") > 0) {
    console.log("T1 -T2 valgt");
    toSett = "2";
  }

  ;

  if (stringValue.search("T3 - Tumor vokser inn i subserosa eller ikke-peritonealisert pericolisk vev") > 0) {
    console.log("T3 valgt");
    toSett = "3";
  }

  ;

  if (stringValue.search("T4 - Tumor vokser direkte inn i andre organer eller strukturer") > 0) {
    console.log("T4 valgt");
    toSett = "4";
  }

  ;

  if (stringValue.search("T4a - Tumor perforerer viscerale peritoneum") > 0) {
    console.log("T4a valgt");
    toSett = "T4a";
  }

  ;

  if (stringValue.search("T4b - Tumor vokser direkte inn i andre organer eller strukturer") > 0) {
    console.log("T4b valgt");
    toSett = "T4b";
  }

  ;
  var ny = new DvText(toSett);
  api.setFieldValue(CT_SCORE, ny);
}

exports.setCTValue = setCTValue;
},{}],13:[function(require,module,exports){
"use strict";

exports.__esModule = true;
var OPPFØLGING = "kreftmelding/kreftmelding_kolorektalkreft_utredning/any_event/oppfølging_tiltak/oppfølging_tiltak";
var NESTE_TRINN = "kreftmelding/kreftmelding_kolorektalkreft_utredning/any_event/oppfølging_tiltak/hvor_skjer_neste_trinn_i_behandlingen";

function showFollowup(api) {
  var follow_up = api.getFieldValue(OPPFØLGING);

  if (follow_up) {
    if (follow_up.Value == "Direkte til reseksjon" || follow_up.Value == "Forbehandling før planlagt reseksjon" || follow_up.Value == "Palliativ, tumorrettet behandling (onkolog)" || follow_up.Value == "Palliativ, kirurgisk behandling (eksklusiv reseksjon)") {
      api.showField(NESTE_TRINN);
      api.setOccurrences(NESTE_TRINN, "1..1");
    }

    if (follow_up.Value == "Kun symptomlindrende behandling/Ingen tumorrettet behandling" || follow_up.Value == "Ikke avklart" || follow_up.Value == "Ukjent") {
      api.clearField(NESTE_TRINN);
      api.hideField(NESTE_TRINN);
      api.setOccurrences(NESTE_TRINN, "0..1");
    }
  }

  if (!follow_up) {
    api.clearField(NESTE_TRINN);
    api.hideField(NESTE_TRINN);
    api.setOccurrences(NESTE_TRINN, "0..1");
  }
}

exports.showFollowup = showFollowup;
},{}],14:[function(require,module,exports){
"use strict";

exports.__esModule = true;

var getIds_1 = require("./getIds");

var TUMOR_COLON = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/tumor_(t-sykdom)/tumor_colon";
var TUMOR_RECTUM = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/tumor_(t-sykdom)/tumor_rectum";

function showIfLocalRes(api) {
  console.log("show if Lokal resisiv function runs"); //gets relevant arraylists med ids  

  var localResidivIds = getIds_1.getLocalresidivIds(api);
  var localResidivIdsToSetOccurrences = getIds_1.getLocalresidivIdsToSetOccurrences(api);
  var tumorIds = getIds_1.getPrimaryTumorIds(api);
  var metastaseIds = getIds_1.getMetastaseIds(api);
  var fellesIds = getIds_1.getFellesIds(api);
  var fellesIdsToSetOccurrences = getIds_1.getFellesIdsToSettOccurrenes(api); //shows and sets occurrences to Local Residiv  related ids  

  for (var i = 0; i < localResidivIds.length; i++) {
    api.showField(localResidivIds[i]);
  }

  for (var i = 0; i < localResidivIdsToSetOccurrences.length; i++) {
    api.setOccurrences(localResidivIdsToSetOccurrences[i], "1..-1");
  } //shows and sets occurrences to CEA and ECOG  


  for (var i = 0; i < fellesIds.length; i++) {
    api.showField(fellesIds[i]);
  }

  for (var i = 0; i < fellesIdsToSetOccurrences.length; i++) {
    api.setOccurrences(fellesIdsToSetOccurrences[i], "1..1");
  } // hides, clears and sets occurrences to Tumor related fields


  for (var i = 0; i < tumorIds.length; i++) {
    api.clearField(tumorIds[i]);
    api.hideField(tumorIds[i]);
    api.setOccurrences(tumorIds[i], "0..-1");
  } // hides, clears and sets occurrences to Metastase related fields


  for (var i = 0; i < metastaseIds.length; i++) {
    api.clearField(metastaseIds[i]);
    api.hideField(metastaseIds[i]);
    api.setOccurrences(metastaseIds[i], "0..-1");
  }
}

exports.showIfLocalRes = showIfLocalRes;
},{"./getIds":5}],15:[function(require,module,exports){
"use strict";

exports.__esModule = true;

var getIds_1 = require("./getIds"); // This function runs when LOKALISATION and FINDINGS is not choosen  


function showIfNothingChoosen(api) {
  console.log("IF NOTHING CHOOSEN function runs"); //contains arraylists with ids 

  var tumorIds = getIds_1.getPrimaryTumorIds(api);
  var localResidivIds = getIds_1.getLocalresidivIds(api);
  var metastaseIds = getIds_1.getMetastaseIds(api);
  var fellesIds = getIds_1.getFellesIds(api);
  var lokalisjasjonIDs = getIds_1.getLokalisationIds(api); // // hides, clears and sets occurrences to Tumor,Local residiv and Metastase related fields

  for (var i = 0; i < metastaseIds.length; i++) {
    api.hideField(metastaseIds[i]);
    api.clearField(metastaseIds[i]);
    api.setOccurrences(metastaseIds[i], "0..1");
  }

  for (var i = 0; i < tumorIds.length; i++) {
    api.hideField(tumorIds[i]);
    api.clearField(tumorIds[i]);
    api.setOccurrences(tumorIds[i], "0..1");
  }

  for (var i = 0; i < localResidivIds.length; i++) {
    api.hideField(localResidivIds[i]);
    api.clearField(localResidivIds[i]);
    api.setOccurrences(localResidivIds[i], "0..1");
  }

  for (var i = 0; i < fellesIds.length; i++) {
    api.hideField(fellesIds[i]);
    api.clearField(fellesIds[i]);
    api.setOccurrences(fellesIds[i], "0..1");
  }

  for (var i = 0; i < lokalisjasjonIDs.length; i++) {
    api.hideField(lokalisjasjonIDs[i]);
    api.setOccurrences(lokalisjasjonIDs[i], "0..-1");
    api.clearField(lokalisjasjonIDs[i]);
  }
}

exports.showIfNothingChoosen = showIfNothingChoosen;
},{"./getIds":5}],16:[function(require,module,exports){
"use strict";

exports.__esModule = true;

var getIds_1 = require("./getIds");

function showIfOnlyMeta(api) {
  console.log("show if onlyMeta function runs"); //  gets relevant arraylists med ids 

  var metastaseIds = getIds_1.getMetastaseIds(api);
  var metastaseIdsToSetOccurrences = getIds_1.getMetastaseIdsToSetOccurrences(api);
  var tumorIds = getIds_1.getPrimaryTumorIds(api);
  var localResidivIds = getIds_1.getLocalresidivIds(api);
  var fellesIds = getIds_1.getFellesIds(api);
  var fellesIdsToSetOccurrences = getIds_1.getFellesIdsToSettOccurrenes(api); //shows and sets occurrences to metastase related ids 

  for (var i = 0; i < metastaseIds.length; i++) {
    api.showField(metastaseIds[i]);
  }

  for (var i = 0; i < metastaseIdsToSetOccurrences.length; i++) {
    api.setOccurrences(metastaseIdsToSetOccurrences[i], "1..-1");
  } //shows and sets occurrences to CEA and ECOG 


  for (var i = 0; i < fellesIds.length; i++) {
    api.showField(fellesIds[i]);
  }

  for (var i = 0; i < fellesIdsToSetOccurrences.length; i++) {
    api.setOccurrences(fellesIdsToSetOccurrences[i], "1..1");
  } // hides, clears and sets occurrences to Tumor related fields


  for (var i = 0; i < tumorIds.length; i++) {
    api.hideField(tumorIds[i]);
    api.setOccurrences(tumorIds[i], "0..1");
    api.clearField(tumorIds[i]);
  } // hides, clears and sets occurrences to Local Residiv related fields


  for (var i = 0; i < localResidivIds.length; i++) {
    api.hideField(localResidivIds[i]);
    api.setOccurrences(localResidivIds[i], "0..1");
    api.clearField(localResidivIds[i]);
  }
}

exports.showIfOnlyMeta = showIfOnlyMeta;
},{"./getIds":5}],17:[function(require,module,exports){
"use strict";

exports.__esModule = true;

var getIds_1 = require("./getIds");

var CT_SCORE = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/klinisk_tnm_etter_ferdig_primærutredning_og_før_primærbehandling/ct";
var CN_SCORE = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/klinisk_tnm_etter_ferdig_primærutredning_og_før_primærbehandling/cn";
var CM_SCORE = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/klinisk_tnm_etter_ferdig_primærutredning_og_før_primærbehandling/cm";

function showIfPrimaryTumor(api) {
  console.log("show if primary function runs"); //   gets relevant arraylists med ids 

  var tumorIds = getIds_1.getPrimaryTumorIds(api);
  var tumorIdsToSetOccurences = getIds_1.getPrimaryTumorIdsToSetOccurrences(api);
  var localResidivIds = getIds_1.getLocalresidivIds(api);
  var metastaseIds = getIds_1.getMetastaseIds(api);
  var fellesIds = getIds_1.getFellesIds(api);
  var fellesIdsToSetOccurrences = getIds_1.getFellesIdsToSettOccurrenes(api); // this loop runs to check if there is something registred from before, and clears tumor fields;;
  // maybe I should explain this a bit better 

  for (var i = 0; i < tumorIds.length; i++) {
    api.clearField(tumorIds[i]);
    api.hideField(tumorIds[i]);
    api.setOccurrences(tumorIds[i], "0..-1");
  } //shows and sets occurrences to the tumor related fileds  


  for (var i = 0; i < tumorIds.length; i++) {
    api.showField(tumorIds[i]);
  }

  for (var i = 0; i < tumorIdsToSetOccurences.length; i++) {
    api.setOccurrences(tumorIdsToSetOccurences[i], "1..-1");
  }
  /**
      // disable clinical TNM fields
  
      api.disableField(CT_SCORE);
      api.disableField(CN_SCORE);
      api.disableField(CM_SCORE);
  */
  // shows ands sets occurrences to CEA and ECOG 


  for (var i = 0; i < fellesIds.length; i++) {
    api.showField(fellesIds[i]);
  }

  for (var i = 0; i < fellesIdsToSetOccurrences.length; i++) {
    api.setOccurrences(fellesIdsToSetOccurrences[i], "1..1");
  } // hides, clears and sets occurrences to Local Residiv related fields 


  for (var i = 0; i < localResidivIds.length; i++) {
    api.hideField(localResidivIds[i]);
    api.setOccurrences(localResidivIds[i], "0..-1");
    api.clearField(localResidivIds[i]);
  } // hides, clears and sets occurrences to Local Residiv related fields


  for (var i = 0; i < metastaseIds.length; i++) {
    api.hideField(metastaseIds[i]);
    api.setOccurrences(metastaseIds[i], "0..-1");
    api.clearField(metastaseIds[i]);
  }
}

exports.showIfPrimaryTumor = showIfPrimaryTumor;
},{"./getIds":5}],18:[function(require,module,exports){
"use strict";

exports.__esModule = true; // I need "SPECIFY" field - den har jeg i den nye cluster arketypen;  
// I need value "Annet laboratorium" - den har jeg i den nye cluster arketypen; 

var PATOLOGILABORATORIUM_CLUSTER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/patologilaboratorium";
var LABORATORIUM = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/patologilaboratorium/laboratorium";
var IKKE_RELEVANT = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/patologilaboratorium/ikke_relevant";
var LABORATORIUM_SPESIFISER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/patologilaboratorium/spesifiser";
var PREPARATNUMMER = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/patologilaboratorium/preparatnummer";

function showLab(api) {
  var lab = api.getFieldValue(LABORATORIUM);
  var not_relevant = api.getFieldValue(IKKE_RELEVANT);
  var preparat_number = api.getFieldValue(PREPARATNUMMER);

  if (!not_relevant || not_relevant.Value == false) {
    api.enableField(LABORATORIUM);

    if (lab && lab.Value != null) {
      api.showField(PREPARATNUMMER);

      if (lab.Value == "Annet laboratorium") {
        console.log("her skal jeg vise SPESIFISER FELT");
        api.showField(LABORATORIUM_SPESIFISER);
        api.disableField(PREPARATNUMMER);
      }

      if (lab.Value == "Ukjent") {
        console.log("her skal jeg skjule spesifiser felt");
        api.hideField(LABORATORIUM_SPESIFISER);
        api.disableField(PREPARATNUMMER);
      }
    }

    if (!lab || lab.Value == null) {
      api.hideField(PREPARATNUMMER);
      console.log("her skal jeg skjule spesifiser");
      api.hideField(LABORATORIUM_SPESIFISER);
    }
  }

  if (not_relevant && not_relevant.Value == true) {
    console.log("Not relevant choosen");
    api.clearField(LABORATORIUM);
    api.disableField(LABORATORIUM);
    api.clearField(PREPARATNUMMER);
    api.hideField(PREPARATNUMMER);
  }
}

exports.showLab = showLab;
},{}],19:[function(require,module,exports){
"use strict";

exports.__esModule = true;
var UTREDNINGSMETODE_FORMID = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/utredningsmetode/utredningsmetode";
var SPESIFISER_UTREDNINGSMETODE_LOKAL_RESIDIV_FORMID = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/utredningsmetode/spesifiser"; // 

var UTREDNINGSMETODE_N_SYKDOM_FORMID = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/n-sykdom/utredningsmetode/utredningsmetode";
var SPESIFISER_UTREDNINGSMETODE_N_SYKDOM_FORMID = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/n-sykdom/utredningsmetode/spesifiser";
var UTREDNINGSMETODE_FJERNMETASTSER_FORMID = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/fjernmetastaser/utredningsmetode_for_fjernmetastaser/utredningsmetode_for_fjernmetastaser";
var SPESIFISER_UTREDNINGSMETODE_FJERNMETASTSER_FORMID = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/fjernmetastaser/utredningsmetode_for_fjernmetastaser/spesifiser";
var LOKALISASJON_FJERNMETASTASER_FORMID = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/fjernmetastaser/lokalisasjon_av_fjernmetastaser";
var SPESIFISER_LOKALISASJON_FJERNMETASTASER_FORMID = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/fjernmetastaser/spesifiser"; // Lokal residiv utredningsmetode 

function showSpecifyExaminationMethodLokalResidiv(api) {
  console.log("showSpecifyExaminationMethodLokalResidiv runs");
  var utredningsmetode = api.getFields(UTREDNINGSMETODE_FORMID);

  if (!utredningsmetode) {
    console.log("nothing choosen");
    api.hideField(SPESIFISER_UTREDNINGSMETODE_LOKAL_RESIDIV_FORMID);
    api.clearField(SPESIFISER_UTREDNINGSMETODE_LOKAL_RESIDIV_FORMID);
  } else {
    var utredningsmetodeString = utredningsmetode.toString();
    console.log(utredningsmetodeString);

    if (utredningsmetodeString.search("Annet") > 0) {
      console.log("Annet valgt");
      api.showField(SPESIFISER_UTREDNINGSMETODE_LOKAL_RESIDIV_FORMID);
    }

    ;

    if (utredningsmetodeString.search("Annet") < 0) {
      console.log("Annet ikke valgt");
      api.hideField(SPESIFISER_UTREDNINGSMETODE_LOKAL_RESIDIV_FORMID);
      api.clearField(SPESIFISER_UTREDNINGSMETODE_LOKAL_RESIDIV_FORMID);
    }

    ;
  }
}

exports.showSpecifyExaminationMethodLokalResidiv = showSpecifyExaminationMethodLokalResidiv;

function ifExaminationMethodLokalResidivIsUnkown(api) {
  console.log("ifExaminationMethodLokalResidivIsUnkown runs");
  var utredningsmetode = api.getFields(UTREDNINGSMETODE_FORMID);

  if (!api.getFields(UTREDNINGSMETODE_FORMID)) {
    console.log("nothing choosen");
    api.setOccurrences(UTREDNINGSMETODE_FORMID, "1..-1");
  } else {
    var utredningsmetodeString = utredningsmetode.toString();
    console.log(utredningsmetodeString);

    if (utredningsmetodeString.search("Ukjent") > 0) {
      console.log("Ukjent valgt");
      api.setOccurrences(UTREDNINGSMETODE_FORMID, "1..1");
      api.hideField(SPESIFISER_UTREDNINGSMETODE_LOKAL_RESIDIV_FORMID);
      api.clearField(SPESIFISER_UTREDNINGSMETODE_LOKAL_RESIDIV_FORMID);
    }

    ;

    if (utredningsmetodeString.search("Ukjent") < 0) {
      console.log("Ukjent ikke valgt");
      api.setOccurrences(UTREDNINGSMETODE_FORMID, "1..-1");
    }

    ;
  }
}

exports.ifExaminationMethodLokalResidivIsUnkown = ifExaminationMethodLokalResidivIsUnkown; // N_SYKDOM  Lokal residiv

function showSpecifyExaminationMethodNLokalResidiv(api) {
  console.log("showSpecifyExaminationMethodNLokalResidiv");
  var utredningsmetode = api.getFields(UTREDNINGSMETODE_N_SYKDOM_FORMID);

  if (!utredningsmetode) {
    console.log("nothing choosen");
    api.setOccurrences(UTREDNINGSMETODE_FORMID, "1..-1");
    api.hideField(SPESIFISER_UTREDNINGSMETODE_N_SYKDOM_FORMID);
    api.clearField(SPESIFISER_UTREDNINGSMETODE_N_SYKDOM_FORMID);
  } else {
    var utredningsmetodeString = utredningsmetode.toString();
    console.log(utredningsmetodeString);

    if (utredningsmetodeString.search("Annet") > 0) {
      console.log("Annet valgt");
      api.showField(SPESIFISER_UTREDNINGSMETODE_N_SYKDOM_FORMID);
    }

    ;

    if (utredningsmetodeString.search("Annet") < 0) {
      console.log("Annet ikke valgt");
      api.hideField(SPESIFISER_UTREDNINGSMETODE_N_SYKDOM_FORMID);
      api.clearField(SPESIFISER_UTREDNINGSMETODE_N_SYKDOM_FORMID);
    }

    ;
  }
}

exports.showSpecifyExaminationMethodNLokalResidiv = showSpecifyExaminationMethodNLokalResidiv;

function ifExaminationMethodNIsUnkownLokalResidiv(api) {
  console.log("ifExaminationMethodNIsUnkownLokalResidiv runs");
  var utredningsmetode = api.getFields(UTREDNINGSMETODE_N_SYKDOM_FORMID);

  if (!utredningsmetode) {
    console.log("nothing choosen");
    api.setOccurrences(UTREDNINGSMETODE_FORMID, "1..-1");
    api.hideField(SPESIFISER_UTREDNINGSMETODE_N_SYKDOM_FORMID);
    api.clearField(SPESIFISER_UTREDNINGSMETODE_N_SYKDOM_FORMID);
  } else {
    var utredningsmetodeString = utredningsmetode.toString();
    console.log(utredningsmetodeString);

    if (utredningsmetodeString.search("Ukjent") > 0) {
      console.log("Ukjent valgt");
      api.setOccurrences(UTREDNINGSMETODE_N_SYKDOM_FORMID, "1..1");
      api.hideField(SPESIFISER_UTREDNINGSMETODE_N_SYKDOM_FORMID);
      api.clearField(SPESIFISER_UTREDNINGSMETODE_N_SYKDOM_FORMID);
    }

    ;

    if (utredningsmetodeString.search("Ukjent") < 0) {
      console.log("Ukjent ikke valgt");
      api.setOccurrences(UTREDNINGSMETODE_N_SYKDOM_FORMID, "1..-1");
    }

    ;
  }
}

exports.ifExaminationMethodNIsUnkownLokalResidiv = ifExaminationMethodNIsUnkownLokalResidiv; // M_SYKDOM

function showSpecifyExaminationMethodMLokalResidiv(api) {
  console.log("showSpecifyExaminationMethodMLokalResidiv");
  var utredningsmetode = api.getFields(UTREDNINGSMETODE_FJERNMETASTSER_FORMID);

  if (!utredningsmetode) {
    console.log("nothing choosen");
    api.hideField(SPESIFISER_UTREDNINGSMETODE_FJERNMETASTSER_FORMID);
    api.clearField(SPESIFISER_UTREDNINGSMETODE_FJERNMETASTSER_FORMID);
  } else {
    var utredningsmetodeString = utredningsmetode.toString();
    console.log(utredningsmetodeString);

    if (utredningsmetodeString.search("Annet") > 0) {
      console.log("Annet valgt");
      api.showField(SPESIFISER_UTREDNINGSMETODE_FJERNMETASTSER_FORMID);
    }

    ;

    if (utredningsmetodeString.search("Annet") < 0) {
      console.log("Annet ikke valgt");
      api.hideField(SPESIFISER_UTREDNINGSMETODE_FJERNMETASTSER_FORMID);
      api.clearField(SPESIFISER_UTREDNINGSMETODE_FJERNMETASTSER_FORMID);
    }

    ;
  }
}

exports.showSpecifyExaminationMethodMLokalResidiv = showSpecifyExaminationMethodMLokalResidiv;

function ifExaminationMethodMIsUnkownLokalResidiv(api) {
  console.log("ifExaminationMethodMIsUnkownLokalResidiv runs");
  var utredningsmetode = api.getFields(UTREDNINGSMETODE_FJERNMETASTSER_FORMID);

  if (!utredningsmetode) {
    console.log("nothing choosen");
    api.setOccurrences(UTREDNINGSMETODE_FORMID, "1..-1");
    api.hideField(SPESIFISER_UTREDNINGSMETODE_FJERNMETASTSER_FORMID);
    api.clearField(SPESIFISER_UTREDNINGSMETODE_FJERNMETASTSER_FORMID);
  } else {
    var nStatusString = utredningsmetode.toString();
    console.log(nStatusString);

    if (nStatusString.search("Ukjent") > 0) {
      console.log("Ukjent valgt");
      api.setOccurrences(UTREDNINGSMETODE_FJERNMETASTSER_FORMID, "1..1");
      api.hideField(SPESIFISER_UTREDNINGSMETODE_FJERNMETASTSER_FORMID);
      api.clearField(SPESIFISER_UTREDNINGSMETODE_FJERNMETASTSER_FORMID);
    }

    ;

    if (nStatusString.search("Ukjent") < 0) {
      console.log("Ukjent ikke valgt");
      api.setOccurrences(UTREDNINGSMETODE_FJERNMETASTSER_FORMID, "1..-1");
    }

    ;
  }
}

exports.ifExaminationMethodMIsUnkownLokalResidiv = ifExaminationMethodMIsUnkownLokalResidiv; // Lokalisasjon 

function showSpecifyLokalisasjonMLokalResidiv(api) {
  console.log("showSpecifyLokalisasjonMLokalResidiv runs");
  var lokalisasjon = api.getFields(LOKALISASJON_FJERNMETASTASER_FORMID);

  if (!lokalisasjon) {
    console.log("nothing choosen");
    api.hideField(SPESIFISER_LOKALISASJON_FJERNMETASTASER_FORMID);
    api.clearField(SPESIFISER_LOKALISASJON_FJERNMETASTASER_FORMID);
  } else {
    var lokalisasjonString = lokalisasjon.toString();
    console.log(lokalisasjonString);

    if (lokalisasjonString.search("Annen lokalisasjon") > 0) {
      console.log("Annen lokalisasjon valgt");
      api.showField(SPESIFISER_LOKALISASJON_FJERNMETASTASER_FORMID);
    }

    ;

    if (lokalisasjonString.search("Annen lokalisasjon") < 0) {
      console.log("Annen lokalisasjon ikke valgt");
      api.hideField(SPESIFISER_LOKALISASJON_FJERNMETASTASER_FORMID);
      api.clearField(SPESIFISER_LOKALISASJON_FJERNMETASTASER_FORMID);
    }

    ;
  }
}

exports.showSpecifyLokalisasjonMLokalResidiv = showSpecifyLokalisasjonMLokalResidiv;
},{}],20:[function(require,module,exports){
"use strict";

exports.__esModule = true;
var METASTASER_LOKALISASJON_FORMID = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_metastase(r)/metastaser_lokalisasjon/metastaser_lokalisasjon";
var SPESIFISER_METASTASER_LOKALISASJON_FORMID = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_metastase(r)/metastaser_lokalisasjon/spesifiser";
var UTREDNINGSMETODE_METASTASER_FORMID = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_metastase(r)/utredningsmetode/utredningsmetode";
var SPESIFISER_UTREDNINGSMETODE_METASTASER_FORMID = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_metastase(r)/utredningsmetode/spesifiser"; // Lokalisasjon

function showSpecifyLokalisationMetastase(api) {
  console.log("showSpecifyLokalisationMetastase runs");
  var lokalisasjon = api.getFields(METASTASER_LOKALISASJON_FORMID);

  if (!lokalisasjon) {
    console.log("nothing choosen");
    api.hideField(SPESIFISER_METASTASER_LOKALISASJON_FORMID);
    api.clearField(SPESIFISER_METASTASER_LOKALISASJON_FORMID);
  } else {
    var lokalisasjonString = lokalisasjon.toString();
    console.log(lokalisasjonString);

    if (lokalisasjonString.search("Annen lokalisasjon") > 0) {
      console.log("Annen lokalisasjon valgt");
      api.showField(SPESIFISER_METASTASER_LOKALISASJON_FORMID);
    }

    ;

    if (lokalisasjonString.search("Annen lokalisasjon") < 0) {
      console.log("Annen lokalisasjon ikke valgt");
      api.hideField(SPESIFISER_METASTASER_LOKALISASJON_FORMID);
      api.clearField(SPESIFISER_METASTASER_LOKALISASJON_FORMID);
    }

    ;
  }
}

exports.showSpecifyLokalisationMetastase = showSpecifyLokalisationMetastase; // Utredningsmetode 

function showSpecifyExaminationMethodMetastase(api) {
  console.log("showSpecifyExaminationMethodMetastase runs");
  var utredningsmetode = api.getFields(UTREDNINGSMETODE_METASTASER_FORMID);

  if (!utredningsmetode) {
    console.log("nothing choosen");
    api.hideField(SPESIFISER_UTREDNINGSMETODE_METASTASER_FORMID);
    api.clearField(SPESIFISER_UTREDNINGSMETODE_METASTASER_FORMID);
  } else {
    var utredningsmetodeString = utredningsmetode.toString();
    console.log(utredningsmetodeString);

    if (utredningsmetodeString.search("Annet") > 0) {
      console.log("Annet valgt");
      api.showField(SPESIFISER_UTREDNINGSMETODE_METASTASER_FORMID);
    }

    ;

    if (utredningsmetodeString.search("Annet") < 0) {
      console.log("Annet ikke valgt");
      api.hideField(SPESIFISER_UTREDNINGSMETODE_METASTASER_FORMID);
      api.clearField(SPESIFISER_UTREDNINGSMETODE_METASTASER_FORMID);
    }

    ;
  }
}

exports.showSpecifyExaminationMethodMetastase = showSpecifyExaminationMethodMetastase;

function ifExaminationMethodMetastaseIsUnkown(api) {
  console.log("ifExaminationMethodMetastaseIsUnkown");
  var utredningsmetode = api.getFields(UTREDNINGSMETODE_METASTASER_FORMID);

  if (!api.getFields(UTREDNINGSMETODE_METASTASER_FORMID)) {
    console.log("nothing choosen");
    api.setOccurrences(UTREDNINGSMETODE_METASTASER_FORMID, "1..-1");
    api.hideField(SPESIFISER_UTREDNINGSMETODE_METASTASER_FORMID);
    api.clearField(SPESIFISER_UTREDNINGSMETODE_METASTASER_FORMID);
  } else {
    var utredningsmetodeString = utredningsmetode.toString();
    console.log(utredningsmetodeString);

    if (utredningsmetodeString.search("Ukjent") > 0) {
      console.log("Ukjent valgt");
      api.setOccurrences(UTREDNINGSMETODE_METASTASER_FORMID, "1..1");
      api.hideField(SPESIFISER_UTREDNINGSMETODE_METASTASER_FORMID);
      api.clearField(SPESIFISER_UTREDNINGSMETODE_METASTASER_FORMID);
    }

    ;

    if (utredningsmetodeString.search("Ukjent") < 0) {
      console.log("Ukjent ikke valgt");
      api.setOccurrences(UTREDNINGSMETODE_METASTASER_FORMID, "1..-1");
    }

    ;
  }
}

exports.ifExaminationMethodMetastaseIsUnkown = ifExaminationMethodMetastaseIsUnkown;
},{}],21:[function(require,module,exports){
"use strict";

exports.__esModule = true;
var UTREDNINGSMETODE_FORMID = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/tumor_(t-sykdom)/utredningsmetode/utredningsmetode";
var SPESIFISER_UTREDNINGSMETODE_T_FORMID = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/tumor_(t)/utredningsmetode/spesifiser";
var UTREDNINGSMETODE_N_SYKDOM_FORMID = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/n-sykdom/utredningsmetode/utredningsmetode";
var SPESIFISER_UTREDNINGSMETODE_N_SYKDOM_FORMID = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/n-sykdom/utredningsmetode/spesifiser";
var UTREDNINGSMETODE_FJERNMETASTSER_FORMID = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/fjernmetastaser/utredsningsmetode_for_fjernmetastaser/utredsningsmetode_for_fjernmetastaser";
var SPESIFISER_UTREDNINGSMETODE_FJERNMETASTSER_FORMID = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/fjernmetastaser/utredsningsmetode_for_fjernmetastaser/spsesifiser";
var LOKALISASJON_FJERNMETASTASER_FORMID = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/fjernmetastaser/lokalisasjon_av_fjernmetastaser";
var SPESIFISER_LOKALISASJON_FJERNMETASTASER_FORMID = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/fjernmetastaser/spesifiser"; // T_SYKDOM 

function showSpecifyExaminationMethodT(api) {
  console.log("show specify examination t runs");
  var utredningsmetode = api.getFields(UTREDNINGSMETODE_FORMID);

  if (!utredningsmetode) {
    console.log("nothing choosen");
    api.clearField(SPESIFISER_UTREDNINGSMETODE_T_FORMID);
    api.hideField(SPESIFISER_UTREDNINGSMETODE_T_FORMID);
  } else {
    var utredningsmetodeString = utredningsmetode.toString();
    console.log(utredningsmetodeString);

    if (utredningsmetodeString.search("Annet") > 0) {
      console.log("Annet valgt");
      api.showField(SPESIFISER_UTREDNINGSMETODE_T_FORMID);
    }

    if (utredningsmetodeString.search("Annet") < 0) {
      console.log("Annet ikke valgt");
      api.hideField(SPESIFISER_UTREDNINGSMETODE_T_FORMID);
      api.clearField(SPESIFISER_UTREDNINGSMETODE_T_FORMID);
    }
  }
}

exports.showSpecifyExaminationMethodT = showSpecifyExaminationMethodT;

function ifExaminationMethodTIsUnkown(api) {
  console.log("show ifExaminationMethodTIsUnkown runs");
  var utredningsmetode = api.getFields(UTREDNINGSMETODE_FORMID);

  if (utredningsmetode) {
    var utredningsmetodeString = utredningsmetode.toString();
    console.log(utredningsmetodeString);

    if (utredningsmetodeString.search("Ukjent") > 0) {
      console.log("Ukjent valgt");
      api.setOccurrences(UTREDNINGSMETODE_FORMID, "1..1");
      api.clearField(SPESIFISER_UTREDNINGSMETODE_T_FORMID);
      api.hideField(SPESIFISER_UTREDNINGSMETODE_T_FORMID);
    }

    ;

    if (utredningsmetodeString.search("Ukjent") < 0) {
      console.log("Ukjent ikke valgt");
      api.setOccurrences(UTREDNINGSMETODE_FORMID, "1..-1");
    }

    ;
  }
}

exports.ifExaminationMethodTIsUnkown = ifExaminationMethodTIsUnkown; // N_SYKDOM

function showSpecifyExaminationMethodNTumor(api) {
  console.log("showSpecifyExaminationMethodNTumor");
  var utredningsmetode = api.getFields(UTREDNINGSMETODE_N_SYKDOM_FORMID);

  if (!utredningsmetode) {
    console.log("nothing choosen");
    api.hideField(SPESIFISER_UTREDNINGSMETODE_N_SYKDOM_FORMID);
    api.clearField(SPESIFISER_UTREDNINGSMETODE_N_SYKDOM_FORMID);
    console.log("spesifiser burde bli skujlt nå");
  } else {
    var utredningsmetodeString = utredningsmetode.toString();
    console.log(utredningsmetodeString);

    if (utredningsmetodeString.search("Annet") > 0) {
      console.log("Annet valgt");
      api.showField(SPESIFISER_UTREDNINGSMETODE_N_SYKDOM_FORMID);
    }

    ;

    if (utredningsmetodeString.search("Annet") < 0) {
      console.log("Annet ikke valgt");
      api.hideField(SPESIFISER_UTREDNINGSMETODE_N_SYKDOM_FORMID);
      api.clearField(SPESIFISER_UTREDNINGSMETODE_N_SYKDOM_FORMID);
    }

    ;
  }
}

exports.showSpecifyExaminationMethodNTumor = showSpecifyExaminationMethodNTumor;

function ifExaminationMethodNIsUnkown(api) {
  console.log("ifExaminationMethodNIsUnkown runs");
  var utredningsmetode = api.getFields(UTREDNINGSMETODE_N_SYKDOM_FORMID);

  if (utredningsmetode) {
    var utredningsmetodeString = utredningsmetode.toString();
    console.log(utredningsmetodeString);

    if (utredningsmetodeString.search("Ukjent") > 0) {
      console.log("Ukjent valgt");
      api.setOccurrences(UTREDNINGSMETODE_N_SYKDOM_FORMID, "1..1");
      api.clearField(SPESIFISER_UTREDNINGSMETODE_N_SYKDOM_FORMID);
      api.hideField(SPESIFISER_UTREDNINGSMETODE_N_SYKDOM_FORMID);
    }

    ;

    if (utredningsmetodeString.search("Ukjent") < 0) {
      console.log("Ukjent ikke valgt");
      api.setOccurrences(UTREDNINGSMETODE_N_SYKDOM_FORMID, "1..-1");
    }

    ;
  }
}

exports.ifExaminationMethodNIsUnkown = ifExaminationMethodNIsUnkown; // M_SYKDOM
// Lokalisasjon Fjernmetastaser 

function showSpecifyLokalisasjonMTumor(api) {
  console.log("show specify examination t runs");
  var lokalisasjon = api.getFields(LOKALISASJON_FJERNMETASTASER_FORMID);

  if (!lokalisasjon) {
    console.log("nothing choosen");
    api.hideField(SPESIFISER_LOKALISASJON_FJERNMETASTASER_FORMID);
    console.log("spesifiser burde bli skujlt nå");
  } else {
    var lokalisasjonString = lokalisasjon.toString();
    console.log(lokalisasjonString);

    if (lokalisasjonString.search("Annen lokalisasjon") > 0) {
      console.log("Annen lokalisasjon valgt");
      api.showField(SPESIFISER_LOKALISASJON_FJERNMETASTASER_FORMID);
    }

    ;

    if (lokalisasjonString.search("Annen lokalisasjon") < 0) {
      console.log("Annen lokalisasjon ikke valgt");
      api.hideField(SPESIFISER_LOKALISASJON_FJERNMETASTASER_FORMID);
    }

    ;
  }
}

exports.showSpecifyLokalisasjonMTumor = showSpecifyLokalisasjonMTumor; // M_SYKDOM  Utredningsmetode 

function showSpecifyExaminationMethodMTumor(api) {
  console.log("showSpecifyExaminationMethodMTumor runs");
  var utredningsmetode = api.getFields(UTREDNINGSMETODE_FJERNMETASTSER_FORMID);

  if (!utredningsmetode) {
    console.log("nothing choosen");
    api.hideField(SPESIFISER_UTREDNINGSMETODE_FJERNMETASTSER_FORMID);
  } else {
    var utredningsmetodeString = utredningsmetode.toString();
    console.log(utredningsmetodeString);

    if (utredningsmetodeString.search("Annet") > 0) {
      console.log("Annet valgt");
      api.showField(SPESIFISER_UTREDNINGSMETODE_FJERNMETASTSER_FORMID);
    }

    ;

    if (utredningsmetodeString.search("Annet") < 0) {
      console.log("Annet ikke valgt");
      api.hideField(SPESIFISER_UTREDNINGSMETODE_FJERNMETASTSER_FORMID);
      api.clearField(SPESIFISER_UTREDNINGSMETODE_FJERNMETASTSER_FORMID);
    }

    ;
  }
}

exports.showSpecifyExaminationMethodMTumor = showSpecifyExaminationMethodMTumor;

function ifExaminationMethodMIsUnkown(api) {
  console.log("show specify examination t runs");
  var utredningsmetode = api.getFields(UTREDNINGSMETODE_FJERNMETASTSER_FORMID);

  if (utredningsmetode) {
    var utredningsmetodeString = utredningsmetode.toString();
    console.log(utredningsmetodeString);

    if (utredningsmetodeString.search("Ukjent") > 0) {
      console.log("Ukjent valgt");
      api.setOccurrences(UTREDNINGSMETODE_FJERNMETASTSER_FORMID, "1..1");
      api.hideField(SPESIFISER_UTREDNINGSMETODE_FJERNMETASTSER_FORMID);
      api.clearField(SPESIFISER_UTREDNINGSMETODE_FJERNMETASTSER_FORMID);
    }

    ;

    if (utredningsmetodeString.search("Ukjent") < 0) {
      console.log("Ukjent ikke valgt");
      api.setOccurrences(UTREDNINGSMETODE_FJERNMETASTSER_FORMID, "1..10");
    }

    ;
  }
}

exports.ifExaminationMethodMIsUnkown = ifExaminationMethodMIsUnkown;
},{}],22:[function(require,module,exports){
"use strict";

exports.__esModule = true;

// Kommentert ut av byggescript = require("ehrcraft-form-api");

var FUNN_I_UTREDNING_FORMID = "kreftmelding/kreftmelding_kolorektalkreft_utredning/any_event/funn_i_utredning";
var LOKALISAJON = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/lokalisasjon_av_primaertumor/lokalisajon";
var KLINISK_SIKKER_KREFT = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/lokalisasjon_av_primaertumor/klinisk_sikker_kreft";
var N_SYKODM_TUMOR = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/er_regionale_lymfeknutemetastaser_påvist_(n-sykdom)";
var N_SYKDOM_LOKAL = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/er_regionale_lymfeknutemetastaser_påvist(n-sykdom)";
var M_SYKDOM_TUMOR = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/er_fjernmetastaser_påvist,_inkludert_lymfeknutemetastaser_utenfor_regionalt_område_(m-sykdom)";
var M_SYKDOM_LOKAL = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_ved_utredning_av_lokalt_residiv/er_fjernmetastaser_påvist,_inkludert_lymfeknutemetastaser_utenfor_regionalt_område_(m-sykdom)";
var CEA = "kreftmelding/kreftmelding_kolorektalkreft_utredning/any_event/cea/cea";
var CEA_IKKE_TATT = "kreftmelding/kreftmelding_kolorektalkreft_utredning/any_event/cea/ikke_tatt";
var KOMMENTAR = "kreftmelding/context/kommentar";
var KLAR_TIL_SENDING = "kreftmelding_kolorektalkreft_dips/context/klar_til_sending";
var stringToSend = "";
var objekt = new DvText();

function testFunction(api) {
  console.log("test function runs");
  var funn_i_utredning = api.getFieldValue(FUNN_I_UTREDNING_FORMID);
  var lokalisajon = api.getFieldValue(LOKALISAJON);
  var klinisk_sikker = api.getFieldValue(KLINISK_SIKKER_KREFT);
  var n_sykdom_tumor = api.getFieldValue(N_SYKODM_TUMOR);
  var n_sykdom_lokal = api.getFieldValue(N_SYKDOM_LOKAL);
  var m_sykdom_tumor = api.getFieldValue(M_SYKDOM_TUMOR);
  var m_sykdom_lokal = api.getFieldValue(M_SYKDOM_LOKAL);
  var cea = api.getFieldValue(CEA);
  var cea_ikke_tatt = api.getFieldValue(CEA_IKKE_TATT);

  if (funn_i_utredning) {
    var funn_i_utredning_tekst = "Ved utredning ble det bekreftet at pasienten har ";
    var utredning = funn_i_utredning.Value;
    var res = funn_i_utredning_tekst.concat(utredning);
    stringToSend = res;
  }

  if (lokalisajon) {
    var lokalisjasjon_teskt = " med lokalisasjon på  ";
    var lokalisasjon = lokalisajon.Value;
    lokalisasjon.split("|"); // måtte spilte fordi at valuen var bode code og value ; kanskje bare Value.Value 

    var res = lokalisjasjon_teskt.concat(lokalisasjon);
    stringToSend = stringToSend.concat(res);
  }

  if (klinisk_sikker) {
    if (klinisk_sikker.Value == "Ja") {
      var klinisk_sikker_tekst = "\n  \nDette er en klinisk sikker kreft. ";
      stringToSend = stringToSend.concat(klinisk_sikker_tekst);
    }

    if (klinisk_sikker.Value == "Usikker") {
      var klinisk_sikker_tekst = "\n  \nDette er en klinisk usikker kreft. ";
      stringToSend = stringToSend.concat(klinisk_sikker_tekst);
    }
  }

  if (n_sykdom_tumor) {
    if (n_sykdom_tumor.Value == "Ja") {
      var n_sykodm_tumor_tekst = "\n  \nRegionale lymfeknutemetastaser er påvist. ";
      stringToSend = stringToSend.concat(n_sykodm_tumor_tekst);
    }

    if (n_sykdom_tumor.Value == "Nei") {
      var n_sykodm_tumor_tekst = "\n  \nRegionale lymfeknutemetastaser er ikke påvist. ";
      stringToSend = stringToSend.concat(n_sykodm_tumor_tekst);
    }

    if (n_sykdom_tumor.Value == "Ikke undersøkt") {
      var n_sykodm_tumor_tekst = "\n  \nRegionale lymfeknutemetastaser er ikke undersøkt. ";
      stringToSend = stringToSend.concat(n_sykodm_tumor_tekst);
    }
  }

  if (n_sykdom_lokal) {
    if (n_sykdom_lokal.Value == "Ja") {
      var n_sykodm_lokal_tekst = "\n  \nRegionale lymfeknutemetastaser er påvist. ";
      stringToSend = stringToSend.concat(n_sykodm_lokal_tekst);
    }

    if (n_sykdom_lokal.Value == "Nei") {
      var n_sykodm_lokal_tekst = "\n  \nRegionale lymfeknutemetastaser er ikke påvist. ";
      stringToSend = stringToSend.concat(n_sykodm_lokal_tekst);
    }

    if (n_sykdom_lokal.Value == "Ikke undersøkt") {
      var n_sykodm_lokal_tekst = "\n  \nRegionale lymfeknutemetastaser er ikke undersøkt. ";
      stringToSend = stringToSend.concat(n_sykodm_lokal_tekst);
    }
  }

  if (m_sykdom_tumor) {
    if (m_sykdom_tumor.Value == "Ja") {
      var m_sykodm_tumor_tekst = "Fjernmetastaser er påvist, inkludert lymfeknutemetastaser utenfor regionalt område (M-sykdom).";
      stringToSend = stringToSend.concat(m_sykodm_tumor_tekst);
    }

    if (m_sykdom_tumor.Value == "Nei") {
      var m_sykodm_tumor_tekst = "Fjernmetastaser er ikke påvist, inkludert lymfeknutemetastaser utenfor regionalt område (M-sykdom).";
      stringToSend = stringToSend.concat(m_sykodm_tumor_tekst);
    }

    if (m_sykdom_tumor.Value == "Ikke undersøkt") {
      var m_sykodm_tumor_tekst = "Fjernmetastaser er ikke undersøkt.";
      stringToSend = stringToSend.concat(m_sykodm_tumor_tekst);
    }
  }

  if (m_sykdom_lokal) {
    if (m_sykdom_lokal.Value == "Ja") {
      var m_sykodm_lokal_tekst = "Fjernmetastaser er påvist, inkludert lymfeknutemetastaser utenfor regionalt område (M-sykdom).";
      stringToSend = stringToSend.concat(m_sykodm_lokal_tekst);
    }

    if (m_sykdom_lokal.Value == "Nei") {
      var m_sykodm_lokal_tekst = "Fjernmetastaser er ikke påvist, inkludert lymfeknutemetastaser utenfor regionalt område (M-sykdom).";
      stringToSend = stringToSend.concat(m_sykodm_lokal_tekst);
    }

    if (m_sykdom_lokal.Value == "Ikke undersøkt") {
      var m_sykodm_lokal_tekst = "fjernmetastaser er ikke undersøkt.";
      stringToSend = stringToSend.concat(m_sykodm_lokal_tekst);
    }
  }

  if (cea) {
    var cea_tekst = "\n \nCEA er tatt og score er ";
    var cea_value = cea;
    cea_tekst = cea_tekst.concat(cea_value);
    stringToSend = stringToSend.concat(cea_tekst);
  }

  if (cea_ikke_tatt && cea_ikke_tatt.Value == true) {
    var cea_tekst = "\n \nCEA har ikke blitt tatt.";
    stringToSend = stringToSend.concat(cea_tekst);
  }

  objekt.Value = stringToSend;
  api.setFieldValue(KOMMENTAR, objekt);
}

exports.testFunction = testFunction;

function klarTilSending(api) {
  var klar = api.getFieldValue(KLAR_TIL_SENDING);
  var klarBoolsk = false;

  if (klar) {
    if (klar.Value == true) {
      klarBoolsk = true;
    }

    if (klar.Value == false) {
      klarBoolsk = false;
    }
  }

  return klarBoolsk;
}

exports.klarTilSending = klarTilSending;

function clearKommentar(api) {
  api.clearField(KOMMENTAR);
}

exports.clearKommentar = clearKommentar;
},{}],23:[function(require,module,exports){
"use strict";

exports.__esModule = true;

var showIfNothingChoosen_1 = require("./showIfNothingChoosen");

var whatToShowOnSTart_1 = require("./whatToShowOnSTart");

var FUNN_I_UTREDNING_FORMID = "kreftmelding/kreftmelding_kolorektalkreft_utredning/any_event/funn_i_utredning";
var LOKALISASJON_FORMID = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/lokalisasjon_av_primaertumor/lokalisajon";
var SPESIFISER_LOKALISASJON_COLON = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/lokalisasjon_av_primaertumor/spesifiser_lokalisajon_colon";
var AVSTAND_1 = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/lokalisasjon_av_primaertumor/angir_avstand_fra_analåpning_til_nedre_kant_av_tumor_(målt_på_stivt_skop)";
var UKJENT_1 = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/lokalisasjon_av_primaertumor/ukjent";
var AVSTAND_2 = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/lokalisasjon_av_primaertumor/avstand_fra_øvre_kant_av_m.puborektalis_til_nedre_kant_av_tumor_(målt_ved_mr)";
var UKJENT_2 = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/lokalisasjon_av_primaertumor/ukjent2";
var KLINISK_SIKKER_FORMID = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/lokalisasjon_av_primaertumor/klinisk_sikker_kreft";
var TUMOR_COLON = "kreftmelding/kreftmelding_kolorektalkreft_utredning/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/tumor_(t-sykdom)/tumor_colon";
var TUMOR_RECTUM = "kreftmelding_kolorektalkreft_dips/kreftmelding_kolorektalkreft_dips/any_event/sykdomsutbredelse_etter_ferdig_primærutredning_og__før_primærbehandling/tumor_(t-sykdom)/tumor_rectum";
var TUMOR_COLON_FIELDSET = "generic-field-30854";
var TUMOR_RECTUM_FIELDSET = "generic-field-95556";

function tumorLocalisation(api) {
  console.log("tumor Lokalisasjon function runs");
  var funnIUtredning = api.getFieldValue(FUNN_I_UTREDNING_FORMID);
  var lokalisasjon = api.getFieldValue(LOKALISASJON_FORMID); //if none of the findings is selected  

  if (!funnIUtredning || funnIUtredning.Value == null) {
    console.log("no finding is selected");
    showIfNothingChoosen_1.showIfNothingChoosen(api);
  } // if primary tumor is selected in findings   


  if (funnIUtredning && funnIUtredning.Value == "Primærtumor (med eller uten metastase(r))") {
    console.log("Primary tumor is choosen. Runs from tumor localisation function");

    if (!lokalisasjon || lokalisasjon.Value == null) {
      console.log("Localisation is not selected");
      showIfNothingChoosen_1.showIfNothingChoosen(api);
    }

    if (lokalisasjon && lokalisasjon.Value != null) {
      console.log("localisation is choosen. from tumor localisation. ");
      whatToShowOnSTart_1.whatToShowOnStart(api);

      if (lokalisasjon.Value == "Colon (C18-C19)") {
        console.log("C18-19 selected");
        showIfTumorLocalisationIsColon(api);
      }

      if (lokalisasjon.Value == "Rectum (C20)") {
        console.log("C20 selected");
        showIfTumorLocalisationIsRectum(api);
      }
    }
  } //if local residiv or metastatis is selected as finding, hide and clear KLINISK SIKKER KREFT and TUMOR RECTUM 


  if (funnIUtredning && (funnIUtredning.Value == "Lokal residiv (med eller uten metastase(r))" || funnIUtredning.Value == "Kun metastase(r)")) {
    console.log("local residiv or metastatis is selected");
    api.hideField(KLINISK_SIKKER_FORMID);
    api.clearField(KLINISK_SIKKER_FORMID);
    api.setOccurrences(KLINISK_SIKKER_FORMID, "0..-1");
    api.hideField(TUMOR_RECTUM_FIELDSET);
    api.clearField(TUMOR_RECTUM_FIELDSET);
    api.setOccurrences(TUMOR_RECTUM, "0..-1");
    api.hideField(TUMOR_RECTUM);
    api.hideField(AVSTAND_1);
    api.clearField(AVSTAND_1);
    api.setOccurrences(AVSTAND_1, "0..-1");
    api.hideField(AVSTAND_2);
    api.clearField(AVSTAND_2);
    api.setOccurrences(AVSTAND_2, "0..-1");
    api.hideField(UKJENT_1);
    api.clearField(UKJENT_1);
    api.hideField(UKJENT_2);
    api.clearField(UKJENT_2); // if no localisation is selcted OR selected value is C20, specify loclisation is cleared and hidden 

    if (!lokalisasjon || lokalisasjon.Value == "Rectum (C20)") {
      console.log("Localisation is not selected/Selected localisation is C20");
      api.setOccurrences(SPESIFISER_LOKALISASJON_COLON, "0..-1");
      api.hideField(SPESIFISER_LOKALISASJON_COLON);
      api.clearField(SPESIFISER_LOKALISASJON_COLON);
    } // if selcted value is C18-C20, show specify localisation  


    if (lokalisasjon && lokalisasjon.Value == "Colon (C18-C19)") {
      console.log("Selected localisation is C18-C19");
      api.showField(SPESIFISER_LOKALISASJON_COLON);
      api.setOccurrences(SPESIFISER_LOKALISASJON_COLON, "1..1");
    }
  }
}

exports.tumorLocalisation = tumorLocalisation; // what to show if primary tumor is selected with C18-C19 

function showIfTumorLocalisationIsColon(api) {
  console.log("C18-19 choosen/no localisation choosen");
  api.showField(SPESIFISER_LOKALISASJON_COLON);
  api.setOccurrences(SPESIFISER_LOKALISASJON_COLON, "1..1");
  api.showField(TUMOR_COLON_FIELDSET);
  api.showField(TUMOR_COLON);
  api.setOccurrences(TUMOR_COLON, "1..-1");
  api.showField(KLINISK_SIKKER_FORMID);
  api.setOccurrences(KLINISK_SIKKER_FORMID, "1..1");
  api.hideField(TUMOR_RECTUM_FIELDSET);
  api.clearField(TUMOR_RECTUM_FIELDSET);
  api.setOccurrences(TUMOR_RECTUM, "0..-1"); //  api.hideField(TUMOR_RECTUM); 

  api.hideField(AVSTAND_1);
  api.clearField(AVSTAND_1);
  api.setOccurrences(AVSTAND_1, "0..-1");
  api.hideField(AVSTAND_2);
  api.clearField(AVSTAND_2);
  api.setOccurrences(AVSTAND_2, "0..-1");
  api.hideField(UKJENT_1);
  api.clearField(UKJENT_1);
  api.hideField(UKJENT_2);
  api.clearField(UKJENT_2);
}

exports.showIfTumorLocalisationIsColon = showIfTumorLocalisationIsColon; // what to show if primary tumor is selected with C20

function showIfTumorLocalisationIsRectum(api) {
  console.log("C20 choosen");
  api.hideField(TUMOR_COLON_FIELDSET);
  api.clearField(TUMOR_COLON_FIELDSET);
  api.setOccurrences(TUMOR_COLON, "0..-1");
  api.hideField(SPESIFISER_LOKALISASJON_COLON);
  api.clearField(SPESIFISER_LOKALISASJON_COLON);
  api.setOccurrences(SPESIFISER_LOKALISASJON_COLON, "0..1");
  api.showField(TUMOR_RECTUM_FIELDSET);
  api.showField(TUMOR_RECTUM);
  api.setOccurrences(TUMOR_RECTUM, "1..-1");
  api.showField(AVSTAND_1);
  api.setOccurrences(AVSTAND_1, "1..1");
  api.showField(AVSTAND_2);
  api.setOccurrences(AVSTAND_2, "1..1");
  api.showField(UKJENT_1);
  api.showField(UKJENT_2);
  api.showField(KLINISK_SIKKER_FORMID);
  api.setOccurrences(KLINISK_SIKKER_FORMID, "1..1");
}

exports.showIfTumorLocalisationIsRectum = showIfTumorLocalisationIsRectum;
},{"./showIfNothingChoosen":15,"./whatToShowOnSTart":24}],24:[function(require,module,exports){
"use strict";

exports.__esModule = true;

var showIfPrimatyTumor_1 = require("./showIfPrimatyTumor");

var showIfLocalRes_1 = require("./showIfLocalRes");

var showIfOnlyMeta_1 = require("./showIfOnlyMeta");

var showIfNothingChoosen_1 = require("./showIfNothingChoosen");

var FUNN_I_UTREDNING_FORMID = "kreftmelding/kreftmelding_kolorektalkreft_utredning/any_event/funn_i_utredning";

function whatToShowOnStart(api) {
  console.log("WHATTOSHOWONSTART function runs");
  var funnIUtredning = api.getFieldValue(FUNN_I_UTREDNING_FORMID);

  if (funnIUtredning) {
    if (funnIUtredning.Value == "Primærtumor (med eller uten metastase(r))") {
      console.log("primary tumor is choosen");
      showIfPrimatyTumor_1.showIfPrimaryTumor(api);
    } else if (funnIUtredning.Value == "Lokal residiv (med eller uten metastase(r))") {
      console.log("local residiv is choosen");
      showIfLocalRes_1.showIfLocalRes(api);
    } else if (funnIUtredning.Value == "Kun metastase(r)") {
      console.log("only metastasis is choosen");
      showIfOnlyMeta_1.showIfOnlyMeta(api);
    }
  }

  if (!funnIUtredning || funnIUtredning.Value == null) {
    console.log("nothing choosen");
    showIfNothingChoosen_1.showIfNothingChoosen(api);
  }
}

exports.whatToShowOnStart = whatToShowOnStart;
},{"./showIfLocalRes":14,"./showIfNothingChoosen":15,"./showIfOnlyMeta":16,"./showIfPrimatyTumor":17}]},{},[1])